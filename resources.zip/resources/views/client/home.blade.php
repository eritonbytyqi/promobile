@extends('client.layout')

@section('title', 'ShopZone — Kryefaqja')

@push('styles')
<style>
:root {
    --pm-bg: #f5f5f7;
    --pm-surface: #ffffff;
    --pm-surface2: #f5f5f7;
    --pm-border: rgba(0,0,0,0.08);
    --pm-text: #1d1d1f;
    --pm-secondary: #6e6e73;
    --pm-blue: #0071e3;
}

/* ── CATEGORIES ── */
.pm-cats-section { padding: 0 5%; margin-bottom: 80px; }
.pm-section-label { font-size: 11px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: var(--pm-secondary); margin-bottom: 6px; }
.pm-section-title { font-family: -apple-system, 'SF Pro Display', sans-serif; font-size: 32px; font-weight: 800; letter-spacing: -1px; color: var(--pm-text); margin-bottom: 24px; }
.pm-cats-grid { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 4px; scrollbar-width: none; }
.pm-cats-grid::-webkit-scrollbar { display: none; }
.pm-cat-card { flex-shrink: 0; width: 160px; height: 160px; border-radius: 24px; background: var(--pm-surface); border: 1px solid var(--pm-border); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; text-decoration: none; color: var(--pm-text); transition: all 0.25s; cursor: pointer; }
.pm-cat-card:hover { background: var(--pm-blue); border-color: var(--pm-blue); color: white; transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,113,227,0.25); }
.pm-cat-icon {
    width: 52px; height: 52px; border-radius: 14px;
    background: rgba(0,188,212,0.1);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; color: #00bcd4; transition: all 0.25s;
}
.pm-cat-card:hover { background: #00bcd4; border-color: #00bcd4; color: white; transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,188,212,0.3); }
.pm-cat-card:hover .pm-cat-icon { background: rgba(255,255,255,0.2); color: white; }
.pm-cat-name { font-size: 13px; font-weight: 600; }

/* ── PRODUCTS ── */
.pm-products-section { padding: 0 5%; margin-bottom: 80px; }
.pm-section-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 28px; }
.pm-see-all { color: var(--pm-blue); text-decoration: none; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 5px; transition: gap 0.2s; }
.pm-see-all:hover { gap: 8px; }
.pm-products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
.pm-product-card { background: var(--pm-surface); border-radius: 24px; overflow: hidden; text-decoration: none; color: var(--pm-text); border: 1px solid var(--pm-border); transition: all 0.3s; display: flex; flex-direction: column; }
.pm-product-card:hover { transform: translateY(-6px); box-shadow: 0 20px 48px rgba(0,0,0,0.12); border-color: transparent; }
.pm-product-img { aspect-ratio: 1;  overflow: hidden; background: var(--pm-surface2); position: relative; }
.pm-product-img img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s cubic-bezier(.4,0,.2,1); }
.pm-product-card:hover .pm-product-img img { transform: scale(1.06); }
.pm-product-img-ph { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #ccc; font-size: 48px; }
.pm-product-badge { position: absolute; top: 12px; left: 12px; padding: 4px 10px; border-radius: 20px; font-size: 10px; font-weight: 700; }
.pm-badge-featured { background: #1d1d1f; color: white; }
.pm-badge-sale { background: rgba(52,199,89,0.15); border: 1px solid rgba(52,199,89,0.3); color: #1a7a1a; }
.pm-product-info { padding: 16px; flex: 1; display: flex; flex-direction: column; }
.pm-product-cat { font-size: 11px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; color: var(--pm-blue); margin-bottom: 5px; }
.pm-product-name { font-size: 15px; font-weight: 700; color: var(--pm-text); margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pm-product-brand { font-size: 12px; color: var(--pm-secondary); margin-bottom: 14px; flex: 1; }
.pm-product-footer { display: flex; align-items: center; justify-content: space-between; margin-top: auto; }
.pm-product-price { font-size: 18px; font-weight: 800; color: var(--pm-text); }
.pm-product-old { font-size: 12px; color: var(--pm-secondary); text-decoration: line-through; display: block; font-weight: 400; line-height: 1; }
.pm-add-btn { width: 36px; height: 36px; border-radius: 980px; background: var(--pm-blue); border: none; color: white; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; flex-shrink: 0; }
.pm-add-btn:hover { background: #0077ed; transform: scale(1.08); }

/* ── NEW RELEASES ── */
/* ── NEW RELEASES 4×2 ── */
.pm-releases { padding: 0 5%; margin-bottom: 80px; }

.pm-releases-header { margin-bottom: 24px; }
.pm-releases-label {
    font-size: 24px;
    font-weight: 800;
    letter-spacing: -0.6px;
    color: #1d1d1f;
    margin-bottom: 3px;
}
.pm-releases-sub { font-size: 13px; color: #6e6e73; }

.pm-releases-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-template-rows: repeat(2, auto);
    gap: 12px;
}

/* Card */
.pm-nr-card {
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    text-decoration: none;
    color: #1d1d1f;
    border: 1px solid rgba(0,0,0,.07);
    display: flex;
    flex-direction: column;
    transition: transform .25s ease, box-shadow .25s ease, border-color .25s;
}
.pm-nr-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 16px 40px rgba(0,0,0,.10);
    border-color: transparent;
}

/* Image — più piccola */
.pm-nr-img {
    position: relative;
    aspect-ratio: 1 / 1;       /* quadrato, più compatto */
    overflow: hidden;
    background: #f5f5f7;
}
.pm-nr-img img {
    width: 100%; height: 100%;
    object-fit: cover;
    transition: transform .45s cubic-bezier(.4,0,.2,1);
}
.pm-nr-card:hover .pm-nr-img img { transform: scale(1.06); }
.pm-nr-img-ph {
    width: 100%; height: 100%;
    display: flex; align-items: center; justify-content: center;
    color: #ccc; font-size: 36px;
}

/* Badges */
.pm-nr-badge-new {
    position: absolute; top: 8px; left: 8px;
    padding: 3px 8px;
    background: #1d1d1f; color: #fff;
    border-radius: 999px;
    font-size: 8px; font-weight: 800; letter-spacing: 1px;
}
.pm-nr-badge-discount {
    position: absolute; top: 8px; right: 8px;
    padding: 3px 8px;
    background: #ff3b30; color: #fff;
    border-radius: 999px;
    font-size: 9px; font-weight: 800;
}

/* Overlay */
.pm-nr-overlay {
    position: absolute; inset: 0;
    background: rgba(0,0,0,.32);
    display: flex; align-items: flex-end;
    justify-content: center;
    padding-bottom: 12px;
    opacity: 0;
    transition: opacity .25s ease;
}
.pm-nr-card:hover .pm-nr-overlay { opacity: 1; }
.pm-nr-quick-add {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 8px 14px;
    background: #fff; color: #1d1d1f;
    border: none; border-radius: 999px;
    font-size: 11px; font-weight: 700;
    cursor: pointer; font-family: inherit;
    transform: translateY(6px);
    transition: transform .25s ease;
}
.pm-nr-card:hover .pm-nr-quick-add { transform: translateY(0); }
.pm-nr-quick-add:hover { background: #f0f0f0; }

/* Info — kompakte */
.pm-nr-info {
    padding: 10px 12px 12px;
    display: flex; flex-direction: column; flex: 1;
}
.pm-nr-cat {
    font-size: 9px; font-weight: 700;
    letter-spacing: 1px; text-transform: uppercase;
    color: #0071e3; margin-bottom: 3px;
}
.pm-nr-name {
    font-size: 12px; font-weight: 700;
    color: #1d1d1f; margin-bottom: 8px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.pm-nr-footer {
    display: flex; align-items: center;
    justify-content: space-between;
    margin-top: auto;
}
.pm-nr-prices { display: flex; flex-direction: column; gap: 1px; }
.pm-nr-old {
    font-size: 10px; color: #aeaeb2;
    text-decoration: line-through; font-weight: 400; line-height: 1;
}
.pm-nr-price { font-size: 14px; font-weight: 800; color: #1d1d1f; }
.pm-nr-price.sale { color: #ff3b30; }

.pm-nr-add-btn {
    width: 28px; height: 28px;
    border-radius: 50%;
    background: #0071e3; border: none;
    color: #fff; font-size: 11px;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background .2s, transform .2s;
    flex-shrink: 0;
}
.pm-nr-add-btn:hover { background: #005bbf; transform: scale(1.1); }

/* Responsive */
@media (max-width: 900px) {
    .pm-releases-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
    .pm-releases-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
}

/* ── BENTO ── */
.pm-bento { padding: 0 5%; margin-bottom: 56px; }
.pm-bento-grid { display: grid; grid-template-columns: 1.2fr 1fr; grid-template-rows: auto auto; gap: 14px; }
.pm-bento-hero { grid-row: 1 / 3; border-radius: 24px; overflow: hidden; position: relative; min-height: 340px; text-decoration: none; display: block; background: #1d1d1f; }
.pm-bento-hero-img { position: absolute; inset: 0; background-size: cover; background-position: center; }
.pm-bento-hero-img::after { content: ''; position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.75) 0%, transparent 60%); }
.pm-bento-hero-content { position: absolute; bottom: 0; left: 0; right: 0; padding: 24px 28px; color: white; z-index: 1; }
.pm-bento-hero-badge { font-size: 10px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; opacity: 0.75; margin-bottom: 8px; }
.pm-bento-hero-title { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; line-height: 1.2; margin-bottom: 12px; }
.pm-bento-hero-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 18px; border-radius: 980px; background: white; color: #1d1d1f; font-size: 12px; font-weight: 700; text-decoration: none; }
.pm-bento-card { border-radius: 20px; padding: 24px; display: flex; flex-direction: column; justify-content: space-between; text-decoration: none; min-height: 160px; transition: opacity 0.2s; }
.pm-bento-card:hover { opacity: 0.9; }
.pm-bento-card.blue { background: #0071e3; color: white; }
.pm-bento-card-title { font-size: 17px; font-weight: 800; letter-spacing: -0.3px; line-height: 1.2; margin-bottom: 6px; }
.pm-bento-card-sub { font-size: 13px; opacity: 0.75; line-height: 1.4; margin-bottom: 14px; }
.pm-bento-card-link { font-size: 13px; font-weight: 600; color: inherit; text-decoration: underline; opacity: 0.85; }
.pm-bento-info-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.pm-bento-info { background: #f5f5f7; border-radius: 20px; padding: 20px; display: flex; flex-direction: column; gap: 8px; }
.pm-bento-info-icon { font-size: 22px; color: #0071e3; }
.pm-bento-info-title { font-size: 13px; font-weight: 700; color: #1d1d1f; }
.pm-bento-info-sub { font-size: 12px; color: #6e6e73; }

/* ── ACCESSORIES ── */
.pm-accessories { padding: 0 5%; margin-bottom: 64px; }
.pm-acc-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 20px; }
.pm-acc-title { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; color: #1d1d1f; }
.pm-acc-see-all { font-size: 13px; font-weight: 600; color: #0071e3; text-decoration: none; display: flex; align-items: center; gap: 4px; }
.pm-acc-see-all:hover { opacity: 0.75; }
.pm-acc-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.pm-acc-card { text-decoration: none; color: inherit; transition: transform 0.2s; }
.pm-acc-card:hover { transform: translateY(-3px); }
.pm-acc-img { width: 100%; aspect-ratio: 1; background: #f5f5f7; border-radius: 16px; overflow: hidden; margin-bottom: 10px; }
.pm-acc-img img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s; }
.pm-acc-card:hover .pm-acc-img img { transform: scale(1.05); }
.pm-acc-img-ph { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #c7c7cc; font-size: 32px; }
.pm-acc-name { font-size: 13px; font-weight: 600; color: #1d1d1f; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pm-acc-cat { font-size: 11px; color: #6e6e73; margin-bottom: 4px; }
.pm-acc-price { font-size: 13px; font-weight: 700; color: #1d1d1f; }

@media (max-width: 768px) {
    .pm-bento-grid { grid-template-columns: 1fr; }
    .pm-bento-hero { grid-row: auto; min-height: 260px; }
    .pm-release-card { flex: 0 0 170px; }
    .pm-acc-grid { grid-template-columns: repeat(2, 1fr); }
    .pm-products-grid { grid-template-columns: repeat(2, 1fr); }
}

/* ── WISHLIST ── */
.pm-wish-btn {
    position: absolute;
    top: 10px; right: 10px;
    width: 32px; height: 32px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.18);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.30);
    display: flex; align-items: center; justify-content: center;
    font-size: 13px;
    color: white;
    cursor: pointer;
    transition: all 0.22s cubic-bezier(.4,0,.2,1);
    z-index: 3;
    text-shadow: 0 1px 3px rgba(0,0,0,0.35);
}

.pm-wish-btn:hover {
    background: rgba(255, 255, 255, 0.30);
    border-color: rgba(255, 255, 255, 0.50);
    transform: scale(1.10);
}

.pm-wish-btn.saved {
    background: #ff3b30;
    border-color: #ff3b30;
    color: white;
    text-shadow: none;
}

.pm-wish-btn.saved:hover {
    background: #e02d22;
    border-color: #e02d22;
    transform: scale(1.10);
}

@keyframes heartPop {
    0%   { transform: scale(1); }
    40%  { transform: scale(1.40); }
    70%  { transform: scale(0.88); }
    100% { transform: scale(1); }
}
.pm-wish-btn.pop { animation: heartPop 0.32s cubic-bezier(.4,0,.2,1) forwards; }

.pm-see-all {
    color: var(--pm-blue);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
    opacity: 0.7;
    transition: opacity 0.2s;
}
.pm-see-all:hover { opacity: 1; }
.pm-releases-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    margin-bottom: 24px;
}
</style>
@endpush

@section('content')

{{-- CAROUSEL --}}
@include('client.partials.hero-carousel', ['banners' => $banners])

{{-- KATEGORITË --}}
@if($categories->count() > 0)
<div class="pm-cats-section">
    <div class="pm-section-label">Shfleto sipas kategorisë</div>
 <div class="pm-section-header">
    <h2 class="pm-section-title" style="margin-bottom:0;">Kategoritë</h2>
    <a href="{{ url('/shop') }}" class="pm-see-all">
        Shiko të gjitha <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
    </a>
</div>
    <div class="pm-cats-grid">
        @foreach($categories as $cat)
        <a href="{{ url('/shop?category='.$cat->id) }}" class="pm-cat-card">
            <div class="pm-cat-icon">
                <i class="fa-solid {{ $cat->icon ?? 'fa-tag' }}"></i>
            </div>
            <span class="pm-cat-name">{{ $cat->name }}</span>
        </a>
        @endforeach
    </div>
</div>
@endif

{{-- FEATURED --}}
@if($featured->count() > 0)
<div class="pm-products-section">
    <div class="pm-section-header">
        <div>
            <div class="pm-section-label">Të Zgjedhura</div>
            <h2 class="pm-section-title" style="margin-bottom:0;">Produktet e Featuara</h2>
        </div>
        <a href="{{ url('/shop?featured=1') }}" class="pm-see-all">
            Shiko të gjitha <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>
       <div id="wishlistSection" style="display:none; margin-bottom:40px;">
    <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#6e6e73;margin-bottom:6px;">Lista jote</div>
    <h2 style="font-size:24px;font-weight:800;letter-spacing:-0.5px;margin-bottom:20px;">
        <i class="fa-solid fa-heart" style="color:#ff3b30;font-size:20px;margin-right:8px;"></i>
        Të preferuarat
    </h2>
    <div class="products-grid" id="wishlistGrid" style="grid-template-columns: repeat(auto-fill, minmax(180px, 220px));"></div>
    <hr style="border:none;border-top:1px solid rgba(0,0,0,0.07);margin:32px 0;">
</div>
    <div class="pm-products-grid">
        @foreach($featured as $product)
   @php
    $firstVariant = $product->variants?->first();

   $pImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $pSrc = $pImg ? asset('storage/' . $pImg->image_path) : null;

    $pHasSale = $product->sale_price && $product->sale_price < $product->price;
    $pPrice   = $pHasSale ? $product->sale_price : $product->price;
    $pOldPrice = $pHasSale ? $product->price : null;

    $colors = $product->variants
        ? $product->variants->filter(fn($v) => $v->color_name)->unique('color_name')->values()
        : collect();
@endphp
        <a href="{{ url('/shop/'.$product->id) }}" class="pm-product-card">
            <div class="pm-product-img">
              
                @if($pSrc)
                    <img src="{{ $pSrc }}" alt="{{ $product->name }}" loading="lazy">
                @else
                    <div class="pm-product-img-ph"><i class="fa-solid fa-box"></i></div>
                @endif
                  <button class="pm-wish-btn"
        data-id="{{ $product->id }}"
        data-name="{{ addslashes($product->name) }}"
        data-price="{{ $pHasSale ? number_format($product->sale_price,2) : number_format($product->price,2) }}"
        data-img="{{ $pSrc ?? '' }}"
        data-url="{{ url('/shop/'.$product->id) }}"
        data-cat="{{ $product->category->name ?? '' }}"
        onclick="event.preventDefault(); toggleWish(this)">
    <i class="fa-solid fa-heart"></i>
</button>
                @if($product->featured)
                    <span class="pm-product-badge pm-badge-featured">
                        <i class="fa-solid fa-star" style="font-size:9px;"></i> Top
                    </span>
                @endif
                @if($pHasSale)
                    <span class="pm-product-badge pm-badge-sale" style="left:auto;right:12px;">SALE</span>
                @endif
            </div>
            <div class="pm-product-info">
                <div class="pm-product-cat">{{ $product->category->name ?? '—' }}</div>
                <div class="pm-product-name">{{ $product->name }}</div>
                <div class="pm-product-brand">{{ $product->brand->name ?? '' }}</div>

@if($colors->count() > 0)
    <div class="pm-card-colors">
        @foreach($colors as $color)
            <span class="pm-card-color"
                  title="{{ $color->color_name }}"
                  style="background: {{ $color->color_hex ?? '#ccc' }};"></span>
        @endforeach
    </div>
@endif
                <div class="pm-product-footer">
                    <div>
                        @if($pHasSale)
                            <span class="pm-product-old">{{ number_format($product->price, 2) }} €</span>
                        @endif
                      <span class="pm-product-price">
    @if($product->variants && $product->variants->count() > 0)
        <span style="font-size:11px;font-weight:500;color:#6e6e73;">nga</span>
    @endif
    {{ number_format($pPrice, 2) }} €
</span>
                    </div>
                    <button class="pm-add-btn"
                            onclick="event.preventDefault(); addToCart({{ $product->id }}, this)">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </a>
        @endforeach
    </div>
</div>
@endif
{{-- NEW RELEASES --}}
@if($latest->count() > 0)
<div class="pm-releases">
<div class="pm-releases-header">
    <div>
        <div class="pm-section-label">Koleksioni i Ri</div>
        <div class="pm-releases-label">New Releases</div>
        <div class="pm-releases-sub">Të fundit nga koleksioni ynë.</div>
    </div>
    <a href="{{ url('/shop') }}" class="pm-see-all">
        Shiko të gjitha <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
    </a>
</div>
    <div class="pm-releases-grid">
            @foreach($latest->take(8) as $product)
       @php
    $pImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $pSrc = $pImg ? asset('storage/' . $pImg->image_path) : null;

    $pHasSale = $product->sale_price && $product->sale_price < $product->price;
    $pPrice   = $pHasSale ? $product->sale_price : $product->price;
    $pOldPrice = $pHasSale ? $product->price : null;

    $discount = $pOldPrice ? round((($pOldPrice - $pPrice) / $pOldPrice) * 100) : 0;

    $firstVariant = $product->variants?->first();

    $colors = $product->variants
        ? $product->variants->filter(fn($v) => $v->color_name)->unique('color_name')->values()
        : collect();
@endphp
       <a href="{{ url('/shop/'.$product->id) }}" class="pm-nr-card">
    <div class="pm-nr-img">
        <button class="pm-wish-btn"
        data-id="{{ $product->id }}"
        data-name="{{ addslashes($product->name) }}"
        data-price="{{ $pHasSale ? number_format($product->sale_price,2) : number_format($product->price,2) }}"
        data-img="{{ $pSrc ?? '' }}"
        data-url="{{ url('/shop/'.$product->id) }}"
        data-cat="{{ $product->category->name ?? '' }}"
        onclick="event.preventDefault(); toggleWish(this)">
  <i class="fa-regular fa-heart"></i>

</button>
        @if($pSrc)
            <img src="{{ $pSrc }}" alt="{{ $product->name }}" loading="lazy">
        @else
            <div class="pm-nr-img-ph"><i class="fa-solid fa-box"></i></div>
        @endif
        <div class="pm-nr-badge-new">NEW</div>
        @if($discount > 0)
            <span class="pm-nr-badge-discount">-{{ $discount }}%</span>
        @endif
        <div class="pm-nr-overlay">
            <button class="pm-nr-quick-add"
                    onclick="event.preventDefault(); addToCart({{ $product->id }}, this, {{ $firstVariant?->id ?? 'null' }})">
                <i class="fa-solid fa-bag-shopping"></i>
                Shto në shportë
            </button>
        </div>
    </div>
            <div class="pm-nr-info">
                <div class="pm-nr-cat">{{ $product->category->name ?? '—' }}</div>
                <div class="pm-nr-name">{{ $product->name }}</div>
                @if($colors->count() > 0)
    <div class="pm-card-colors pm-card-colors--small">
        @foreach($colors as $color)
            <span class="pm-card-color pm-card-color--small"
                  title="{{ $color->color_name }}"
                  style="background: {{ $color->color_hex ?? '#ccc' }};"></span>
        @endforeach
    </div>
@endif
                <div class="pm-nr-footer">
                    <div class="pm-nr-prices">
                        @if($pHasSale)
                            <span class="pm-nr-old">{{ number_format($product->price, 2) }} €</span>
                        @endif
                        <span class="pm-product-price">
    @if($product->variants && $product->variants->count() > 0 && $colors->count() > 0)
        <span style="font-size:11px;font-weight:500;color:#6e6e73;">nga</span>
    @endif
    {{ number_format($pPrice, 2) }} €
</span>
                    </div>
                    <button class="pm-nr-add-btn"
                            onclick="event.preventDefault(); addToCart({{ $product->id }}, this, {{ $product->variants?->first()?->id ?? 'null' }})">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </a>
        @endforeach
    </div>
</div>
@endif

{{-- BENTO GRID --}}
{{-- BENTO GRID --}}
<div class="pm-bento">
    <div class="pm-bento-grid">

      @php
    $bentoProduct = $featured->first();
    $bentoImg = $bentoProduct?->images?->firstWhere('is_primary', true)
             ?? $bentoProduct?->images?->first();
    $bentoSrc = $bentoImg ? asset('storage/'.$bentoImg->image_path) : null;

    // Merre bannerin e parë aktiv për bento
    $bentoBanner = $banners->first();
@endphp 


        <a href="{{ $bentoProduct ? url('/shop/'.$bentoProduct->id) : url('/shop') }}"
           class="pm-bento-hero">
            <div class="pm-bento-hero-img"
                 style="{{ $bentoSrc ? 'background-image:url('.$bentoSrc.')' : 'background:#1d1d1f;' }}">
            </div>
            <div class="pm-bento-hero-content">
                <div class="pm-bento-hero-badge">Produkt i Featuar</div>
                <div class="pm-bento-hero-title">
                    {{ $bentoProduct?->name ?? 'Zbulo koleksionin' }}
                </div>
                <span class="pm-bento-hero-btn">
                    Eksploro <i class="fa-solid fa-arrow-right" style="font-size:10px;"></i>
                </span>
            </div>
        </a>

        {{-- Karta Oferta — dinamike nga banneri i parë --}}
        @if($bentoBanner)
        <a href="{{ $bentoBanner->btn_primary_url ?? url('/shop?featured=1') }}" class="pm-bento-card blue">
            <div>
                <div class="pm-bento-card-title">
                    {{ $bentoBanner->badge_text ?? 'Oferta Speciale' }}
                </div>
                <div class="pm-bento-card-sub">
                    {{ $bentoBanner->subtitle ?? 'Zbulo produktet me zbritje.' }}
                </div>
                @if($bentoBanner->price)
                <div style="font-size:1.6rem;font-weight:800;color:#fff;margin-top:4px;">
                    {{ number_format($bentoBanner->price, 2) }} €
                </div>
                @endif
            </div>
            <span class="pm-bento-card-link">
                {{ $bentoBanner->btn_primary_text ?? 'Shiko ofertat' }} →
            </span>
        </a>
        @else
        <a href="{{ url('/shop?featured=1') }}" class="pm-bento-card blue">
            <div>
                <div class="pm-bento-card-title">Oferta Speciale</div>
                <div class="pm-bento-card-sub">Zbulo produktet me zbritje dhe oferta ekskluzive.</div>
            </div>
            <span class="pm-bento-card-link">Shiko ofertat →</span>
        </a>
        @endif

        <div class="pm-bento-info-row">
            {{-- ... info kartat mbeten njëlloj --}}
        </div>
    </div>
</div>

{{-- ACCESSORIES --}}
@php
    $keywords = [
    'accessor',
    'accessories',
    'accesor',
    'aksesor',
    'aksesorë',
];

$accessoriesCategory = \App\Models\Category::where(function ($query) use ($keywords) {
    foreach ($keywords as $word) {
        $query->orWhereRaw('LOWER(name) LIKE ?', ['%' . strtolower($word) . '%']);
    }
})->first();
@endphp

@if($accessories->count() > 0)
<div class="pm-accessories">
    <div class="pm-acc-header">
        <div class="pm-acc-title">Essential Accessories</div>
        <a href="{{ url('/shop?category='.($accessoriesCategory->id ?? '')) }}"
           class="pm-acc-see-all">
            View all <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
        </a>
    </div>
    <div class="pm-acc-grid">
        @foreach($accessories as $acc)
        @php
            $aImg = $acc->images?->firstWhere('is_primary', true) ?? $acc->images?->first();
            $aSrc = $aImg ? asset('storage/'.$aImg->image_path) : null;
            $aHasSale = $acc->sale_price && $acc->sale_price < $acc->price;
            $aPrice   = $aHasSale ? $acc->sale_price : $acc->price;
        @endphp
        <a href="{{ url('/shop/'.$acc->id) }}" class="pm-acc-card">
            <div class="pm-acc-img">
                @if($aSrc)
                    <img src="{{ $aSrc }}" alt="{{ $acc->name }}" loading="lazy">
                @else
                    <div class="pm-acc-img-ph"><i class="fa-solid fa-plug"></i></div>
                @endif
            </div>
            <div class="pm-acc-name">{{ $acc->name }}</div>
            <div class="pm-acc-cat">{{ $acc->category->name ?? '' }}</div>
            <div class="pm-acc-price">{{ number_format($aPrice, 2) }} €</div>
        </a>
        @endforeach
    </div>
</div>
@endif
@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', () => {
    renderWishlist();
});
</script>
@endpush
@endsection
