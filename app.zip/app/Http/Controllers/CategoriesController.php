<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoriesController extends Controller
{
    public function index()
    {
        $categories = Category::withCount(['products', 'brands'])->latest()->get();
        $brands = Brand::orderBy('name')->get();

        return view('categories.index', compact('categories', 'brands'));
    }

    public function create()
    {
        return view('categories.index');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'slug'        => 'nullable|string|max:255|unique:categories,slug',
            'description' => 'nullable|string',
            'brand_ids'   => 'nullable|array',
            'brand_ids.*' => 'exists:brands,id',
        ]);

        $icon = 'fa-' . ltrim($request->icon ?? 'tag', 'fa-');

        $category = Category::create([
            'name'        => $request->name,
            'slug'        => $request->slug ?: Str::slug($request->name),
            'icon'        => $icon,
            'description' => $request->description,
        ]);

        if ($request->filled('brand_ids')) {
            $category->brands()->sync($request->brand_ids);
        }

        return redirect()->route('admin.categories.index')->with('success', 'Kategoria u shtua!');
    }

    public function show($id)
    {
        $category = Category::with('products')->findOrFail($id);

        return view('admin.categories.show', compact('category'));
    }

    public function edit($id)
    {
        $categories    = Category::withCount(['products', 'brands'])->latest()->get();
        $brands        = Brand::orderBy('name')->get();
        $editCategory  = Category::with('brands')->findOrFail($id);

        return view('categories.index', compact('categories', 'brands', 'editCategory'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'slug'        => 'nullable|string|max:255|unique:categories,slug,' . $id . ',id',
            'description' => 'nullable|string',
            'brand_ids'   => 'nullable|array',
            'brand_ids.*' => 'exists:brands,id',
        ]);

        $category = Category::findOrFail($id);

        $icon = 'fa-' . ltrim($request->icon ?? ltrim($category->icon ?? 'tag', 'fa-'), 'fa-');

        $category->update([
            'name'        => $request->name,
            'slug'        => $request->slug ?: Str::slug($request->name),
            'icon'        => $icon,
            'description' => $request->description,
        ]);

        $category->brands()->sync($request->brand_ids ?? []);

        return redirect()->route('admin.categories.index')->with('success', 'Kategoria u përditësua!');
    }

  public function destroy($id)
{
    $category = Category::withCount('products')->findOrFail($id);

    if ($category->products_count > 0) {
        return redirect()->route('admin.categories.index')
                         ->with('error', 'Nuk mund të fshish — ka ' . $category->products_count . ' produkte të lidhura! Hiq produktet së pari.');
    }

    $category->brands()->detach();
    $category->delete();

    return redirect()->route('admin.categories.index')
                     ->with('success', 'Kategoria u fshi!');
}
}