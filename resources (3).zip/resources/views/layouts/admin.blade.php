<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin') — MobiShop</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="{{ asset('css/admin/layout.css') }}">
    @stack('styles')
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

    <aside class="sidebar">
        <div class="sidebar-logo">
            <div class="sidebar-logo-icon"><i class="fa-solid fa-mobile-screen"></i></div>
            <div class="sidebar-logo-text">Mobi<span>Shop</span></div>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Kryesore</div>
            <ul class="sidebar-nav">
                <li><a href="{{ url('/admin') }}" class="{{ request()->is('admin') ? 'active' : '' }}"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
                <li><a href="{{ url('/admin/products') }}" class="{{ request()->is('admin/products*') ? 'active' : '' }}"><i class="fa-solid fa-box"></i> Produktet</a></li>
                <li><a href="{{ url('/admin/stock') }}" class="{{ request()->is('admin/stock*') ? 'active' : '' }}"><i class="fa-solid fa-warehouse"></i> Stoku</a></li>
                <li><a href="{{ url('/admin/banners/create') }}" class="{{ request()->is('admin/banners*') ? 'active' : '' }}"><i class="fa-solid fa-rectangle-ad"></i> Bannerat</a></li>
                <li><a href="{{ url('/admin/orders') }}" class="{{ request()->is('admin/orders*') ? 'active' : '' }}"><i class="fa-solid fa-bag-shopping"></i> Porositë</a></li>
                <li><a href="{{ route('admin.customers.index') }}" class="{{ request()->is('admin/customers*') ? 'active' : '' }}"><i class="fa-solid fa-users"></i> Klientët</a></li>
            </ul>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Katalog</div>
            <ul class="sidebar-nav">
                <li><a href="{{ url('/admin/categories') }}" class="{{ request()->is('admin/categories*') ? 'active' : '' }}"><i class="fa-solid fa-folder"></i> Kategoritë</a></li>
                <li><a href="{{ url('/admin/brands') }}" class="{{ request()->is('admin/brands*') ? 'active' : '' }}"><i class="fa-solid fa-tag"></i> Brendet</a></li>
            </ul>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Sistemi</div>
            <ul class="sidebar-nav">
                <li><a href="{{ url('/admin/settings') }}" class="{{ request()->is('admin/settings*') ? 'active' : '' }}"><i class="fa-solid fa-gear"></i> Cilësimet</a></li>
                <li><a href="{{ url('/') }}" target="_blank"><i class="fa-solid fa-store"></i> Shiko Dyqanin</a></li>
            </ul>
        </div>

        <div class="sidebar-footer">
            <a href="{{ url('/logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Dil
            </a>
            <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display:none;">@csrf</form>
        </div>
    </aside>

    <div class="main">
        <header class="topbar">
            <button class="topbar-hamburger" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></button>
            <div class="topbar-breadcrumb">@yield('breadcrumb')</div>
            <div class="topbar-page-title">@yield('page-title')</div>
            <div class="topbar-actions">
                <a href="{{ url('/') }}" class="topbar-icon-btn" title="Shiko Dyqanin" target="_blank">
                    <i class="fa-solid fa-store"></i>
                </a>
            </div>
        </header>

        <div class="page-content">
            @if(session('success'))
                <div class="flash flash-success"><i class="fa-solid fa-circle-check"></i> {{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="flash flash-error"><i class="fa-solid fa-circle-exclamation"></i> {{ session('error') }}</div>
            @endif
            @if(session('warning'))
                <div class="flash flash-warning"><i class="fa-solid fa-triangle-exclamation"></i> {{ session('warning') }}</div>
            @endif

            @yield('content')
        </div>
    </div>

    <script src="{{ asset('js/admin/layout.js') }}"></script>
    @stack('scripts')
</body>
</html>