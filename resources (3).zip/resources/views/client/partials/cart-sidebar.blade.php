{{-- CART SIDEBAR --}}
<div class="cs-overlay" id="cartOverlay" onclick="closeCart()"></div>

<div class="cs-sidebar" id="cartSidebar">

    <div class="cs-header">
        <div class="cs-title">
            <i class="fa-solid fa-bag-shopping"></i>
            Shporta ime
            <span class="cs-count-badge" id="csCountBadge"
                  style="{{ count(session('cart', [])) === 0 ? 'display:none' : '' }}">
                {{ count(session('cart', [])) }}
            </span>
        </div>
        <button class="cs-close" onclick="closeCart()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <div class="cs-body" id="csBody">
        @php $cart = session('cart', []); @endphp
        @include('client.partials.cart-sidebar-items', ['cart' => $cart])
    </div>

    <div class="cs-footer" id="csFooter" style="{{ count($cart) === 0 ? 'display:none' : '' }}">
        <div class="cs-subtotal">
            <span>Nëntotali</span>
            <span class="cs-subtotal-val" id="csTotal">
                {{ number_format(collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']), 2) }} €
            </span>
        </div>

        <div class="cs-shipping">
            <i class="fa-solid fa-truck" style="color:#34c759;font-size:12px;"></i>
           {{ cache('delivery_kosovo', 'Dërgesa Falas') }}
        </div>

        <a href="{{ route('checkout') }}" class="cs-checkout-btn">
            Përfundo porosinë
            <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>

</div>
@push('scripts')
    <script src="{{ asset('js/shop/pages.js') }}"></script>
@endpush