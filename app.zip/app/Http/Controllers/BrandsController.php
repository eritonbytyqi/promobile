<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
class BrandsController extends Controller
{
public function index()
{
$brands = Brand::with(['categories'])->withCount(['products', 'categories'])->latest()->get();
    $categories = Category::orderBy('name')->get();

    return view('brands.index', compact('brands', 'categories'));
}

public function edit($id)
{
    $brands = Brand::withCount(['products', 'categories'])->latest()->get();
    $categories = Category::orderBy('name')->get();
    $editBrand = Brand::with('categories')->findOrFail($id);

    return view('brands.index', compact('brands', 'categories', 'editBrand'));
}
    public function create()
    {
        return view('admin.brands.index');
    }

 public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'slug' => 'nullable|string|max:255|unique:brands,slug',
        'description' => 'nullable|string',
        'category_ids' => 'nullable|array',
        'category_ids.*' => 'exists:categories,id',
    ]);

    $brand = Brand::create([
        'name' => $request->name,
        'slug' => $request->filled('slug')
            ? Str::slug($request->slug)
            : Str::slug($request->name),
        'description' => $request->description,
        'is_active' => 1,
    ]);

    $brand->categories()->sync($request->category_ids ?? []);

    return redirect()
        ->to('/admin/brands')
        ->with('success', 'Brendi u shtua me sukses.');
}

    public function show($id)
    {
        $brand = Brand::with('products')->findOrFail($id);

        return view('admin.brands.show', compact('brand'));
    }

  
public function update(Request $request, $id)
{
    $brand = Brand::findOrFail($id);

    $request->validate([
        'name' => 'required|string|max:255',
        'slug' => 'nullable|string|max:255|unique:brands,slug,' . $brand->id,
        'description' => 'nullable|string',
        'category_ids' => 'nullable|array',
        'category_ids.*' => 'exists:categories,id',
    ]);

    $brand->update([
        'name' => $request->name,
        'slug' => $request->filled('slug')
            ? Str::slug($request->slug)
            : Str::slug($request->name),
        'description' => $request->description,
    ]);

    $brand->categories()->sync($request->category_ids ?? []);

    return redirect()
        ->to('/admin/brands')
        ->with('success', 'Brendi u përditësua me sukses.');
}

    public function destroy($id)
    {
        Brand::destroy($id);

        return redirect()->route('admin.brands.index')->with('success', 'Brendi u fshi!');
    }
}