<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porosia u konfirmua</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Helvetica Neue', Arial, sans-serif; background: #f5f5f7; color: #1d1d1f; }
        .wrapper { max-width: 600px; margin: 40px auto; background: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .header { background: #1d1d1f; padding: 32px 40px; text-align: center; }
        .header .logo { font-size: 24px; font-weight: 800; color: white; letter-spacing: -0.5px; }
        .header .logo span { color: #0071e3; }
        .hero { background: linear-gradient(135deg, #0059b5, #0071e3); padding: 40px; text-align: center; }
        .hero-icon { width: 64px; height: 64px; background: rgba(255,255,255,0.15); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px; font-size: 28px; }
        .hero h1 { font-size: 26px; font-weight: 800; color: white; margin-bottom: 8px; letter-spacing: -0.5px; }
        .hero p { font-size: 15px; color: rgba(255,255,255,0.85); line-height: 1.6; }
        .body { padding: 40px; }
        .greeting { font-size: 16px; color: #1d1d1f; margin-bottom: 20px; line-height: 1.6; }
        .order-box { background: #f5f5f7; border-radius: 14px; padding: 24px; margin-bottom: 24px; }
        .order-box-title { font-size: 11px; font-weight: 700; color: #6e6e73; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 16px; }
        .order-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e8e8ed; font-size: 14px; }
        .order-row:last-child { border-bottom: none; }
        .order-row .label { color: #6e6e73; }
        .order-row .value { font-weight: 600; color: #1d1d1f; }
        .items-title { font-size: 11px; font-weight: 700; color: #6e6e73; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 12px; }
        .item-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f0f0f0; font-size: 14px; }
        .item-row:last-child { border-bottom: none; }
        .item-name { color: #1d1d1f; font-weight: 500; }
        .item-price { color: #0071e3; font-weight: 700; }
        .total-row { display: flex; justify-content: space-between; padding: 16px 0 0; font-size: 17px; font-weight: 800; border-top: 2px solid #e8e8ed; margin-top: 8px; }
        .total-row .total-label { color: #1d1d1f; }
        .total-row .total-value { color: #0071e3; }
        .payment-badge { display: inline-block; padding: 6px 14px; border-radius: 999px; font-size: 12px; font-weight: 700; margin-top: 16px; }
        .payment-cash { background: #d6f5e3; color: #1a7a4a; }
        .payment-stripe { background: #d7e2ff; color: #0059b5; }
        .cta { text-align: center; margin: 32px 0; }
        .cta a { display: inline-block; padding: 14px 32px; background: #1d1d1f; color: white; text-decoration: none; border-radius: 999px; font-size: 14px; font-weight: 700; }
        .info-box { background: #fff3cd; border-radius: 12px; padding: 16px 20px; margin-bottom: 24px; }
        .info-box p { font-size: 13px; color: #856404; line-height: 1.6; }
        .footer { background: #f5f5f7; padding: 28px 40px; text-align: center; border-top: 1px solid #e8e8ed; }
        .footer p { font-size: 12px; color: #6e6e73; line-height: 1.8; }
        .footer .brand { font-size: 14px; font-weight: 700; color: #1d1d1f; margin-bottom: 8px; }
    </style>
</head>
<body>
<div class="wrapper">

    <!-- Header -->
    <div class="header">
        <div class="logo">Pro<span>Mobile</span></div>
    </div>

    <!-- Hero -->
    <div class="hero">
        <div class="hero-icon">✓</div>
        <h1>Porosia u konfirmua!</h1>
        <p>Faleminderit për blerjen tuaj. Porosia juaj është pranuar dhe po procesohet.</p>
    </div>

    <!-- Body -->
    <div class="body">
        <p class="greeting">
            Përshëndetje <strong>{{ $order->customer_name }}</strong>,<br><br>
            Porosia juaj me numër <strong>#{{ $order->order_number }}</strong> u konfirmua me sukses.
            Do t'ju kontaktojmë së shpejti për detajet e dorëzimit.
        </p>

        <!-- Order details -->
        <div class="order-box">
            <div class="order-box-title">Detajet e porosisë</div>
            <div class="order-row">
                <span class="label">Numri i porosisë</span>
                <span class="value">#{{ $order->order_number }}</span>
            </div>
            <div class="order-row">
                <span class="label">Data</span>
                <span class="value">{{ $order->created_at->format('d M Y, H:i') }}</span>
            </div>
            <div class="order-row">
                <span class="label">Adresa</span>
                <span class="value">{{ $order->shipping_address }}, {{ $order->city }}</span>
            </div>
            <div class="order-row">
                <span class="label">Telefoni</span>
                <span class="value">{{ $order->customer_phone ?? '—' }}</span>
            </div>
        </div>

        <!-- Items -->
        <div class="items-title">Produktet e porositura</div>
        @foreach($order->items as $item)
        <div class="item-row">
            <span class="item-name">{{ optional($item->product)->name ?? 'Produkt' }} × {{ $item->quantity }}</span>
            <span class="item-price">{{ number_format($item->subtotal, 2) }} €</span>
        </div>
        @endforeach
        <div class="total-row">
            <span class="total-label">Totali</span>
            <span class="total-value">{{ number_format($order->total_amount, 2) }} €</span>
        </div>

        <!-- Payment method -->
        @if($order->payment_method === 'bank')
            <div style="text-align:center;">
                <span class="payment-badge payment-stripe">✓ Paguar me kartë (Stripe)</span>
            </div>
        @else
            <div style="text-align:center;">
                <span class="payment-badge payment-cash">💵 Cash në dorëzim</span>
            </div>
            <div class="info-box" style="margin-top:16px;">
                <p>⚠️ Pagesa bëhet në dorëzim. Ju lutemi të keni shumën e saktë gati: <strong>{{ number_format($order->total_amount, 2) }} €</strong></p>
            </div>
        @endif

        <div class="cta">
            <a href="{{ url('/profili-im') }}">Shiko porositë e mia</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <div class="brand">ProMobile</div>
        <p>
            Faleminderit që zgjodhët ProMobile!<br>
            Nëse keni pyetje, na kontaktoni: info@promobile.com<br>
            © {{ date('Y') }} ProMobile. Të gjitha të drejtat e rezervuara.
        </p>
    </div>

</div>
</body>
</html>