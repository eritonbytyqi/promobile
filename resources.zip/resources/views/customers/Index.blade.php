@extends('layouts.app')

@section('title', 'Klientët')
@section('page-title', 'Klientët')

@push('styles')
<style>
    .customers-wrap{
        display:flex;
        flex-direction:column;
        gap:20px;
    }

    .customers-stats{
        display:grid;
        grid-template-columns:repeat(3, minmax(0,1fr));
        gap:16px;
    }

    .c-stat{
        background:var(--surface, #fff);
        border:1px solid var(--border, rgba(0,0,0,.08));
        border-radius:16px;
        padding:18px;
        box-shadow:0 8px 24px rgba(0,0,0,.04);
    }

    .c-stat-label{
        font-size:12px;
        color:var(--text-muted, #7a7a7a);
        margin-bottom:8px;
        text-transform:uppercase;
        letter-spacing:.7px;
        font-weight:700;
    }

    .c-stat-value{
        font-size:28px;
        font-weight:800;
        color:var(--text, #111);
        line-height:1;
    }

    .customers-card{
        background:var(--surface, #fff);
        border:1px solid var(--border, rgba(0,0,0,.08));
        border-radius:18px;
        overflow:hidden;
        box-shadow:0 8px 24px rgba(0,0,0,.04);
    }

    .customers-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        padding:18px 20px;
        border-bottom:1px solid var(--border, rgba(0,0,0,.08));
    }

    .customers-title{
        font-size:18px;
        font-weight:800;
        color:var(--text, #111);
    }

    .customers-sub{
        font-size:13px;
        color:var(--text-muted, #7a7a7a);
        margin-top:4px;
    }

    .customers-table-wrap{
        overflow:auto;
    }

    .customers-table{
        width:100%;
        border-collapse:collapse;
        min-width:820px;
    }

    .customers-table thead th{
        text-align:left;
        font-size:12px;
        color:var(--text-muted, #7a7a7a);
        text-transform:uppercase;
        letter-spacing:.7px;
        padding:14px 18px;
        background:rgba(0,0,0,.02);
        border-bottom:1px solid var(--border, rgba(0,0,0,.08));
    }

    .customers-table tbody td{
        padding:16px 18px;
        border-bottom:1px solid rgba(0,0,0,.06);
        vertical-align:middle;
    }

    .customers-table tbody tr:hover{
        background:rgba(0,0,0,.02);
    }

    .customer-id{
        font-weight:700;
        color:var(--text-muted, #7a7a7a);
    }

    .customer-main{
        display:flex;
        align-items:center;
        gap:12px;
    }

    .customer-avatar{
        width:42px;
        height:42px;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:14px;
        font-weight:800;
        background:rgba(0,188,212,.12);
        color:#00bcd4;
        flex-shrink:0;
    }

    .customer-name{
        font-size:14px;
        font-weight:700;
        color:var(--text, #111);
    }

    .customer-meta{
        font-size:12px;
        color:var(--text-muted, #7a7a7a);
        margin-top:3px;
    }

    .customer-email,
    .customer-phone{
        font-size:13px;
        color:var(--text, #111);
    }

    .customer-phone.muted{
        color:var(--text-muted, #7a7a7a);
        font-style:italic;
    }

    .customer-date{
        display:flex;
        flex-direction:column;
        gap:3px;
    }

    .customer-date-main{
        font-size:13px;
        font-weight:700;
        color:var(--text, #111);
    }

    .customer-date-sub{
        font-size:12px;
        color:var(--text-muted, #7a7a7a);
    }

    .customer-badge{
        display:inline-flex;
        align-items:center;
        justify-content:center;
        padding:6px 10px;
        border-radius:999px;
        font-size:11px;
        font-weight:800;
        background:rgba(26,122,74,.10);
        color:#1a7a4a;
        border:1px solid rgba(26,122,74,.16);
    }

    .empty-customers{
        padding:50px 20px;
        text-align:center;
        color:var(--text-muted, #7a7a7a);
    }

    .empty-customers i{
        font-size:34px;
        margin-bottom:10px;
        opacity:.7;
    }

    .pagination-wrap{
        padding:16px 20px;
    }

    @media (max-width: 900px){
        .customers-stats{
            grid-template-columns:1fr;
        }
    }
</style>
@endpush

@section('content')
@php
    $totalCustomers = $customers->total();
    $newThisMonth = $customers->getCollection()->filter(fn($c) => $c->created_at && $c->created_at->isCurrentMonth())->count();
    $withPhone = $customers->getCollection()->filter(fn($c) => !empty($c->phone))->count();
@endphp

<div class="customers-wrap">

    <div class="customers-stats">
        <div class="c-stat">
            <div class="c-stat-label">Gjithsej klientë</div>
            <div class="c-stat-value">{{ $totalCustomers }}</div>
        </div>

        <div class="c-stat">
            <div class="c-stat-label">Të rinj këtë muaj</div>
            <div class="c-stat-value">{{ $newThisMonth }}</div>
        </div>

        <div class="c-stat">
            <div class="c-stat-label">Me numër telefoni</div>
            <div class="c-stat-value">{{ $withPhone }}</div>
        </div>
    </div>

    <div class="customers-card">
        <div class="customers-head">
            <div>
                <div class="customers-title">Lista e Klientëve</div>
                <div class="customers-sub">Të gjithë përdoruesit me rolin customer.</div>
            </div>
        </div>

        @if($customers->count())
            <div class="customers-table-wrap">
                <table class="customers-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Klienti</th>
                            <th>Email</th>
                            <th>Telefoni</th>
                            <th>Data e regjistrimit</th>
                            <th>Porositë</th>
                            <th>Statusi</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach($customers as $c)
                            <tr>
       <td>
    {{ $c->orders_count_custom }}
</td>

                                <td>
                                    <div class="customer-main">
                                        <div class="customer-avatar">
                                            {{ strtoupper(substr($c->name ?? 'C', 0, 1)) }}
                                        </div>
                                        <div>
                                            <div class="customer-name">
                                                {{ $c->name }} {{ $c->surname ?? '' }}
                                            </div>
                                            <div class="customer-meta">
                                                Klient i regjistruar
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <div class="customer-email">{{ $c->email }}</div>
                                </td>

                                <td>
                                    @if(!empty($c->phone))
                                        <div class="customer-phone">{{ $c->phone }}</div>
                                    @else
                                        <div class="customer-phone muted">Pa numër</div>
                                    @endif
                                </td>

                                <td>
                                    <div class="customer-date">
                                        <div class="customer-date-main">
                                            {{ $c->created_at?->format('d.m.Y') }}
                                        </div>
                                        <div class="customer-date-sub">
                                            {{ $c->created_at?->format('H:i') }}
                                        </div>
                                    </div>
                                </td>
<td>
    <a href="{{ route('admin.customers.orders', $c->id) }}"
       class="btn btn-sm btn-ghost">
        <i class="fa-solid fa-box"></i> Porositë
    </a>
</td>
                                <td>
                                    <span class="customer-badge">Customer</span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap">
                {{ $customers->links() }}
            </div>
        @else
            <div class="empty-customers">
                <i class="fa-solid fa-users"></i>
                <div style="font-size:16px;font-weight:800;margin-bottom:6px;">Nuk ka klientë ende</div>
                <div style="font-size:13px;">Kur të regjistrohen përdorues me rolin customer, do të shfaqen këtu.</div>
            </div>
        @endif
    </div>

</div>
@endsection