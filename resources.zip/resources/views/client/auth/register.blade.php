@extends('client.layout')

@section('title', 'Regjistrohu – ProMobile')

@push('styles')
<style>
    .auth-page-wrap {
        min-height: calc(100vh - 64px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 48px 24px;
        background: var(--bg);
    }

    .auth-card {
        background: var(--surface);
        border-radius: var(--radius-2xl);
        border: 1px solid var(--border-solid);
        width: 100%;
        max-width: 460px;
        padding: 2.5rem 2.5rem 2rem;
        box-shadow: 0 4px 32px rgba(0,0,0,0.06);
    }

    .auth-logo {
        text-align: center;
        margin-bottom: 1.5rem;
        font-size: 24px;
        font-weight: 800;
        letter-spacing: -0.5px;
        color: var(--text);
    }
    .auth-logo span { color: var(--primary); }

    .auth-tab-bar {
        display: flex;
        background: var(--surface-low);
        border-radius: var(--radius-full);
        padding: 4px;
        margin-bottom: 2rem;
    }

    .auth-tab {
        flex: 1;
        padding: 9px;
        text-align: center;
        font-size: 13px;
        font-weight: 600;
        border-radius: var(--radius-full);
        color: var(--text-muted);
        text-decoration: none;
        transition: all 0.22s;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .auth-tab.active {
        background: var(--surface);
        color: var(--primary);
        box-shadow: 0 1px 8px rgba(0,0,0,0.08);
    }

    .auth-field { margin-bottom: 1rem; }

    .auth-field label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-soft);
        margin-bottom: 6px;
    }

    .auth-field input {
        width: 100%;
        padding: 11px 14px;
        font-size: 14px;
        font-family: 'Inter', sans-serif;
        border: 1.5px solid var(--border-solid);
        border-radius: 12px;
        background: var(--surface);
        color: var(--text);
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .auth-field input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(0,89,181,0.1);
    }

    .auth-field input::placeholder { color: var(--text-muted); }

    .auth-field .error-msg {
        font-size: 12px;
        color: var(--error);
        margin-top: 5px;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .auth-two-col {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .auth-btn-submit {
        width: 100%;
        padding: 13px;
        background: var(--text);
        color: #fff;
        border: none;
        border-radius: var(--radius-full);
        font-family: 'Inter', sans-serif;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: opacity 0.2s, transform 0.2s;
        margin-top: 0.25rem;
    }
    .auth-btn-submit:hover { opacity: 0.85; transform: translateY(-1px); }

    .auth-switch {
        text-align: center;
        margin-top: 1.25rem;
        font-size: 13px;
        color: var(--text-muted);
    }
    .auth-switch a {
        color: var(--primary);
        font-weight: 600;
        text-decoration: none;
    }
    .auth-switch a:hover { opacity: 0.75; }

    @media (max-width: 520px) {
        .auth-card { padding: 1.75rem 1.25rem 1.5rem; }
        .auth-two-col { grid-template-columns: 1fr; }
    }
</style>
@endpush

@section('content')
<div class="auth-page-wrap">
    <div class="auth-card">

        <div class="auth-logo">Pro<span>Mobile</span></div>

        {{-- Tab bar --}}
        <div class="auth-tab-bar">
            <a href="{{ route('login') }}" class="auth-tab">Hyr në llogari</a>
            <a href="{{ route('register') }}" class="auth-tab active">Regjistrohu</a>
        </div>

        <form method="POST" action="{{ route('register') }}">
            @csrf

            {{-- Emri & Mbiemri --}}
            <div class="auth-two-col">
                <div class="auth-field">
                    <label for="name">Emri</label>
                    <input id="name" type="text" name="name"
                           value="{{ old('name') }}"
                           placeholder="Emri"
                           required autofocus />
                    @error('name')
                        <p class="error-msg">
                            <span class="material-symbols-outlined" style="font-size:14px;">error</span>
                            {{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="auth-field">
                    <label for="surname">Mbiemri</label>
                    <input id="surname" type="text" name="surname"
                           value="{{ old('surname') }}"
                           placeholder="Mbiemri"
                           required />
                    @error('surname')
                        <p class="error-msg">
                            <span class="material-symbols-outlined" style="font-size:14px;">error</span>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            {{-- Telefoni --}}
            <div class="auth-field">
                <label for="phone">Telefoni</label>
                <input id="phone" type="text" name="phone"
                       value="{{ old('phone') }}"
                       placeholder="+383 4X XXX XXX"
                       required />
                @error('phone')
                    <p class="error-msg">
                        <span class="material-symbols-outlined" style="font-size:14px;">error</span>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            {{-- Email --}}
            <div class="auth-field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email"
                       value="{{ old('email') }}"
                       placeholder="shembull@email.com"
                       required />
                @error('email')
                    <p class="error-msg">
                        <span class="material-symbols-outlined" style="font-size:14px;">error</span>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            {{-- Password & Konfirmo --}}
            <div class="auth-two-col">
                <div class="auth-field">
                    <label for="password">Fjalëkalimi</label>
                    <input id="password" type="password" name="password"
                           placeholder="••••••••"
                           required />
                    @error('password')
                        <p class="error-msg">
                            <span class="material-symbols-outlined" style="font-size:14px;">error</span>
                            {{ $message }}
                        </p>
                    @enderror
                </div>

                <div class="auth-field">
                    <label for="password_confirmation">Përsërit</label>
                    <input id="password_confirmation" type="password"
                           name="password_confirmation"
                           placeholder="••••••••"
                           required />
                </div>
            </div>

            <button type="submit" class="auth-btn-submit">Regjistrohu</button>
        </form>

        <div class="auth-switch">
            Keni llogari?
            <a href="{{ route('login') }}">Hyrni këtu</a>
        </div>

    </div>
</div>
@endsection