<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class CartController extends Controller
{
    public function index()
    {
        $cart  = session()->get('cart', []);
        $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);
        return view('client.cart', compact('cart', 'total'));
    }

   public function sidebar()
{
    $cart  = session()->get('cart', []);
    
    // PËRKOHËSISHT — shiko çfarë ka brenda
    \Log::info('CART CONTENT:', $cart);
    \Log::info('CART COUNT:', ['count' => count($cart)]);
    
    $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);
    $count = count($cart);

    return response()->json([
        'count' => $count,
        'total' => number_format($total, 2),
        'html'  => view('client.partials.cart-sidebar-items', compact('cart'))->render(),
    ]);
}

public function add(Request $request)
{
    $request->validate([
        'product_id' => 'required|exists:products,id',
        'variant_id' => 'nullable|exists:product_variants,id',
        'quantity'   => 'nullable|integer|min:1|max:99',
    ]);

    $product = Product::with(['images', 'variants'])->findOrFail($request->product_id);
    $qty     = $request->quantity ?? 1;
    $cart    = session()->get('cart', []);

   $variant = null;

if ($request->filled('variant_id')) {
    $variant = $product->variants()->findOrFail($request->variant_id);
}

// Foto: varianti ka prioritet, pastaj primary e galerisë
if ($variant && !empty($variant->image_path)) {
    $imgSrc = asset('storage/' . $variant->image_path);
} else {
    $img = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $imgSrc = $img ? asset('storage/' . $img->image_path) : null;
}

if ($variant) {
    $price = ($variant->sale_price && $variant->sale_price < $variant->price)
        ? $variant->sale_price
        : $variant->price;
    $key = $product->id . '_' . $variant->id;
} else {
    $price = ($product->sale_price && $product->sale_price < $product->price)
        ? $product->sale_price
        : $product->price;
    $key = (string) $product->id;
}

$alreadyExists = isset($cart[$key]);

if ($alreadyExists) {
    $cart[$key]['quantity'] += $qty;
} else {
    $cart[$key] = [
        'id'         => $product->id,
        'variant_id' => $variant?->id,
        'name'       => $product->name,
        'price'      => $price,
        'image'      => $imgSrc,
        'quantity'   => $qty,
        'color'      => $variant?->color_name,
        'storage'    => $variant?->storage,
    ];
}   

    session()->put('cart', $cart);

    $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);

  return response()->json([
    'success' => true,
    'count'   => count($cart),
    'total'   => number_format($total, 2),
    'html'    => view('client.partials.cart-sidebar-items', compact('cart'))->render(),
    'message' => $alreadyExists ? 'Sasia u rrit!' : 'Produkti u shtua!',
]);
}
public function update(Request $request)
{
    $request->validate([
        'key' => 'required|string',
        'quantity' => 'required|integer|min:1|max:99',
    ]);

    $cart = session()->get('cart', []);
    $key = $request->key;

    if (isset($cart[$key])) {
        $cart[$key]['quantity'] = $request->quantity;
        session()->put('cart', $cart);
    }

    $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);

return response()->json([
    'success' => true,
    'count'   => count($cart),
    'total'   => number_format($total, 2),
    'html'    => view('client.partials.cart-sidebar-items', compact('cart'))->render(),
]);
}

   public function remove(Request $request)
{
    $request->validate([
        'key' => 'required|string',
    ]);

    $cart = session()->get('cart', []);
    $key = $request->key;

    if (isset($cart[$key])) {
        unset($cart[$key]);
        session()->put('cart', $cart);
    }

    $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);

   return response()->json([
    'success' => true,
    'count'   => count($cart),
    'total'   => number_format($total, 2),
    'html'    => view('client.partials.cart-sidebar-items', compact('cart'))->render(),
]);
}
    public function clear()
    {
        session()->forget('cart');
        return response()->json(['success' => true, 'count' => 0, 'total' => '0.00']);
    }
    public function checkout()
{
    $cart  = session()->get('cart', []);
    $total = collect($cart)->sum(fn($i) => $i['price'] * $i['quantity']);
    return view('client.Order.checkout', compact('cart', 'total'));
}
}