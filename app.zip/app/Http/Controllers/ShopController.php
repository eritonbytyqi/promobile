<?php
namespace App\Http\Controllers;
use App\Models\Banner;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Offer;

class ShopController extends Controller
{
public function home()
{
    $banners    = Banner::where('active', 1)->orderBy('sort_order')->get();
    $categories = Category::orderBy('name')->get();

    $accessoriesCategory = Category::accessories()->first();

    $accessories = collect();

    if ($accessoriesCategory) {
        $accessories = $accessoriesCategory
            ->products()
            ->with(['images', 'category'])
            ->latest()
            ->take(8)
            ->get();
    }

    $accCatId = $accessoriesCategory?->id;

$specialOffer = Offer::where('is_active', true)
    ->orderBy('sort_order')
    ->latest()
    ->first();
    $featured = Product::with(['images', 'category'])
        ->where('featured', 1)
        ->when($accCatId, fn($q) => $q->where('category_id', '!=', $accCatId))
        ->latest()
        ->take(8)
        ->get();

    $latest = Product::with(['images', 'category'])
        ->when($accCatId, fn($q) => $q->where('category_id', '!=', $accCatId))
        ->latest()
        ->take(8)
        ->get();

    $totalProducts   = Product::count();
    $totalCategories = Category::count();

    return view('client.home', compact(
        'banners',
        'categories',
        'featured',
        'latest',
        'totalProducts',
        'totalCategories',
        'accessoriesCategory',
        'accessories',
            'specialOffer'

    ));
}
    public function products(Request $request)
    {
$query = Product::with(['category', 'brand', 'images']);

        if ($request->category) {
            $query->where('category_id', $request->category);
        }

     

        if ($request->search) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'like', '%'.$request->search.'%')
                  ->orWhere('description', 'like', '%'.$request->search.'%');
            });
        }

        switch ($request->sort) {
            case 'price_asc':  $query->orderBy('price', 'asc');  break;
            case 'price_desc': $query->orderBy('price', 'desc'); break;
            case 'name_asc':   $query->orderBy('name', 'asc');   break;
            default:           $query->latest();                  break;
        }

        $products       = $query->paginate(12)->withQueryString();
        $categories     = Category::all();
        $activeCategory = $request->category ? Category::find($request->category) : null;

        return view('client.products', compact('products', 'categories', 'activeCategory'));
    }

public function productDetail($id)
{
    $product = Product::query()
        ->with([
            'category:id,name',
            'brand:id,name',
            'images' => function ($q) {
                $q->orderByDesc('is_primary')->orderBy('id');
            },
            'variants' => function ($q) {
                $q->orderBy('color_name')->orderBy('storage')->orderBy('id');
            },
            'variantImages' => function ($q) {
                $q->orderByDesc('is_primary')->orderBy('sort_order')->orderBy('id');
            },
            'specs' => function ($q) {
                $q->orderBy('id');
            },
        ])
        ->where('is_active', true)
        ->findOrFail($id);

    // Gjej kategorinë aksesore
    $accessoryCategory = Category::accessories()->first();

    $related = collect();

    if ($accessoryCategory) {
        $related = Product::query()
            ->with([
                'images' => fn($q) => $q->orderByDesc('is_primary')->orderBy('id'),
                'variants' => fn($q) => $q->orderBy('id'),
            ])
            ->where('is_active', true)
            ->where('id', '!=', $product->id)
            ->where('category_id', $accessoryCategory->id)
            ->latest('id')
            ->take(6)
            ->get();
    }

    // Nëse nuk ka aksesore, merr nga e njëjta kategori
    if ($related->isEmpty() && $product->category_id) {
        $related = Product::query()
            ->with([
                'images' => fn($q) => $q->orderByDesc('is_primary')->orderBy('id'),
                'variants' => fn($q) => $q->orderBy('id'),
            ])
            ->where('is_active', true)
            ->where('id', '!=', $product->id)
            ->where('category_id', $product->category_id)
            ->latest('id')
            ->take(6)
            ->get();
    }

    return view('client.product-detail', compact('product', 'related'));
}
   // Shto këtë metodë në ShopController — zëvendëso placeOrder() ekzistuesen
 
public function placeOrder(Request $request)
{
    $request->validate([
        'customer_name'    => 'required|string|max:255',
        'customer_email'   => 'required|email|max:255',
        'customer_phone'   => 'nullable|string|max:30',
        'shipping_address' => 'nullable|string|max:255',
        'city'             => 'nullable|string|max:100',
        'payment_method'   => 'required|in:cash,bank',
    ]);
 
    $cart = session('cart', []);
 
    if (empty($cart)) {
        return redirect()->route('checkout')->with('error', 'Shporta është bosh!');
    }
 
    $total = collect($cart)->sum(fn($item) => $item['price'] * $item['quantity']);
    $status = $request->payment_method === 'bank' ? 'awaiting_payment' : 'pending';
 
    $order = \App\Models\Order::create([
        'order_number'     => 'ORD-' . strtoupper(uniqid()),
        'customer_name'    => $request->customer_name,
        'customer_email'   => $request->customer_email,
        'customer_phone'   => $request->customer_phone,
        'shipping_address' => $request->shipping_address,
        'city'             => $request->city,
        'notes'            => $request->notes,
        'status'           => $status,
        'payment_method'   => $request->payment_method,
        'total_amount'     => $total,
    ]);
 
    foreach ($cart as $key => $item) {
        $order->items()->create([
            'product_id' => $item['id'],
            'variant_id' => $item['variant_id'] ?? null,
            'quantity'   => $item['quantity'],
            'unit_price' => $item['price'],
            'subtotal'   => $item['price'] * $item['quantity'],
        ]);
    }
 
    session()->forget('cart');
 
    // Nëse bank → dërgo te sandbox
 try {
    \Mail::to($order->customer_email)
        ->send(new \App\Mail\OrderConfirmed($order->load('items.product')));
} catch (\Exception $e) {
    // Email dështoi por vazhdo me porosinë
}
 
// Nëse bank → dërgo te faqja e pagesës
if ($request->payment_method === 'bank') {
    return redirect()->route('payment.page', $order->id);
}
 
return redirect()->route('order.success', $order->id);
 
}
    public function orderSuccess($id)
    {
        $order = Order::with('items.product')->findOrFail($id);
        return view('client.Order.order-success', compact('order'));
    }
    public function showProductPage()
{
    $accessoriesCategory = Category::accessories()->first();

    $accessories = collect();

    if ($accessoriesCategory) {
        $accessories = $accessoriesCategory
            ->products()
            ->with(['images', 'category'])
            ->latest()
            ->take(8)
            ->get();
    }

    return view('client.home', compact('accessoriesCategory', 'accessories'));
}
public function liveSearch(Request $request)
{
    $q = $request->get('q', '');
    if (strlen($q) < 1) return response()->json([]);

    $products = Product::with(['images'])
        ->where('is_active', true)
        ->where('name', 'like', '%' . $q . '%')
        ->latest()
        ->take(6)
        ->get()
        ->map(function($p) {
            $img = $p->images?->firstWhere('is_primary', true) ?? $p->images?->first();
            $hasSale = $p->sale_price && $p->sale_price < $p->price;
            return [
                'id'    => $p->id,
                'name'  => $p->name,
                'price' => number_format($hasSale ? $p->sale_price : $p->price, 2),
                'img'   => $img ? asset('storage/' . $img->image_path) : null,
            ];
        });

    return response()->json($products);
}


public function bankSandbox($orderId)
{
    $order = \App\Models\Order::findOrFail($orderId);
    return view('client.Order.bank-sandbox', compact('order'));
}
public function bankConfirm(Request $request)
{
    $order = \App\Models\Order::findOrFail($request->order_id);

    if ($request->status === 'confirmed') {
        $order->update(['status' => 'pending']); // ← ndrysho këtu
        return redirect()->route('order.success', $order->id)
            ->with('payment_success', true);
    }

    $order->update(['status' => 'payment_failed']);
    return redirect()->route('bank.sandbox', $order->id)
        ->with('error', 'Pagesa dështoi. Provoni përsëri.');
}
 public function sendContact(Request $request)
{
    $request->validate([
        'name'    => 'required|string|max:255',
        'email'   => 'required|email',
        'message' => 'required|string|min:10',
    ]);

    // Dërgo email te admini
    \Mail::raw(
        "Emri: {$request->name}\nEmail: {$request->email}\nTel: {$request->phone}\nSubjekti: {$request->subject}\n\nMesazhi:\n{$request->message}",
        fn($m) => $m->to('info@promobile.com')->subject("Kontakt nga {$request->name}")
    );

    return redirect()->route('contact')->with('contact_success', true);
}
}