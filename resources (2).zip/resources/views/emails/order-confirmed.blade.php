<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porosia u konfirmua</title>
</head>
<body>
<div class="wrapper">

    <!-- Header -->
    <div class="header">
        <div class="logo">Pro<span>Mobile</span></div>
    </div>

    <!-- Hero -->
    <div class="hero">
        <div class="hero-icon">✓</div>
        <h1>Porosia u konfirmua!</h1>
        <p>Faleminderit për blerjen tuaj. Porosia juaj është pranuar dhe po procesohet.</p>
    </div>

    <!-- Body -->
    <div class="body">
        <p class="greeting">
            Përshëndetje <strong>{{ $order->customer_name }}</strong>,<br><br>
            Porosia juaj me numër <strong>#{{ $order->order_number }}</strong> u konfirmua me sukses.
            Do t'ju kontaktojmë së shpejti për detajet e dorëzimit.
        </p>

        <!-- Order details -->
        <div class="order-box">
            <div class="order-box-title">Detajet e porosisë</div>
            <div class="order-row">
                <span class="label">Numri i porosisë</span>
                <span class="value">#{{ $order->order_number }}</span>
            </div>
            <div class="order-row">
                <span class="label">Data</span>
                <span class="value">{{ $order->created_at->format('d M Y, H:i') }}</span>
            </div>
            <div class="order-row">
                <span class="label">Adresa</span>
                <span class="value">{{ $order->shipping_address }}, {{ $order->city }}</span>
            </div>
            <div class="order-row">
                <span class="label">Telefoni</span>
                <span class="value">{{ $order->customer_phone ?? '—' }}</span>
            </div>
        </div>

        <!-- Items -->
        <div class="items-title">Produktet e porositura</div>
        @foreach($order->items as $item)
        <div class="item-row">
            <span class="item-name">{{ optional($item->product)->name ?? 'Produkt' }} × {{ $item->quantity }}</span>
            <span class="item-price">{{ number_format($item->subtotal, 2) }} €</span>
        </div>
        @endforeach
        <div class="total-row">
            <span class="total-label">Totali</span>
            <span class="total-value">{{ number_format($order->total_amount, 2) }} €</span>
        </div>

        <!-- Payment method -->
        @if($order->payment_method === 'bank')
            <div style="text-align:center;">
                <span class="payment-badge payment-stripe">✓ Paguar me kartë (Stripe)</span>
            </div>
        @else
            <div style="text-align:center;">
                <span class="payment-badge payment-cash">💵 Cash në dorëzim</span>
            </div>
            <div class="info-box" style="margin-top:16px;">
                <p>⚠️ Pagesa bëhet në dorëzim. Ju lutemi të keni shumën e saktë gati: <strong>{{ number_format($order->total_amount, 2) }} €</strong></p>
            </div>
        @endif

        <div class="cta">
            <a href="{{ url('/profili-im') }}">Shiko porositë e mia</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <div class="brand">ProMobile</div>
        <p>
            Faleminderit që zgjodhët ProMobile!<br>
            Nëse keni pyetje, na kontaktoni: info@promobile.com<br>
            © {{ date('Y') }} ProMobile. Të gjitha të drejtat e rezervuara.
        </p>
    </div>

</div>
</body>
</html>
