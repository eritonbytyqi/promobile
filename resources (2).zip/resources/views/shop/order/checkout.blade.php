@extends('layouts.shop')

@section('title', 'Checkout — ProMobile')

@push('styles')
@endpush

@section('content')
<div class="checkout-wrap">

    @if(count($cart) === 0)
        <div class="checkout-empty">
            <i class="fa-solid fa-bag-shopping"></i>
            <h2>Shporta është bosh</h2>
            <p>Shto produkte para se të vazhdosh me checkout.</p>
            <a href="{{ url('/shop') }}">
                <i class="fa-solid fa-arrow-left"></i>
                Shko te produktet
            </a>
        </div>

    @else

        <h1 class="checkout-title">Checkout</h1>
<form method="POST" action="{{ route('checkout.place') }}">
        @csrf

        <div class="checkout-grid">

            {{-- ── LEFT ── --}}
            <div class="checkout-left">

                {{-- Guest prompt ose auth banner --}}
                @guest
                    <div class="guest-prompt">
                        <div class="guest-prompt-text">
                            <strong>Keni llogari?</strong>
                            Kyçuni për të plotësuar automatikisht të dhënat tuaja dhe për të ruajtur porositë.
                        </div>
                        <a href="{{ route('login') }}" class="guest-prompt-btn">
                            <span class="material-symbols-outlined" style="font-size:16px;">login</span>
                            Kyçu
                        </a>
                    </div>
                @else
                    <div class="auth-info-banner">
                        <span class="material-symbols-outlined">verified_user</span>
                        Të dhënat u plotësuan automatikisht nga profili juaj.
                        <a href="{{ route('profile.index') }}" style="color:var(--primary);font-weight:700;margin-left:auto;text-decoration:none;font-size:12px;">Ndrysho</a>
                    </div>
                @endguest

                {{-- Informacioni i dërgimit --}}
                <div class="checkout-section">
                    <div class="checkout-section-title">
                        <i class="fa-solid fa-truck"></i>
                        Informacioni i dërgimit
                    </div>

                    <div class="form-grid-2">
                        @auth
                        @php $address = \App\Models\UserAddress::where('user_id', auth()->id())->where('is_default',1)->first(); @endphp
                        <div class="form-group">
                            <label class="form-label">Emri i plotë</label>
                            <input type="text" name="customer_name" class="form-input"
                                   value="{{ auth()->user()->name . ' ' . auth()->user()->surname }}"
                                   placeholder="Emri Mbiemri" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="customer_email" class="form-input"
                                   value="{{ auth()->user()->email }}"
                                   placeholder="email@example.com" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Telefoni</label>
                            <input type="tel" name="customer_phone" class="form-input"
                                   value="{{ auth()->user()->phone ?? '' }}"
                                   placeholder="+383 44 000 000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Qyteti</label>
                            <input type="text" name="city" class="form-input"
                                   value="{{ $address->city ?? '' }}"
                                   placeholder="Prishtinë">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="shipping_address" class="form-input"
                                   value="{{ $address->address_line_1 ?? '' }}"
                                   placeholder="Rruga, numri...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kodi Postar</label>
                            <input type="text" name="postal_code" class="form-input"
                                   value="{{ $address->postal_code ?? '' }}"
                                   placeholder="10000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Shteti</label>
                            <input type="text" name="country" class="form-input"
                                   value="{{ $address->country ?? 'Kosovë' }}"
                                   placeholder="Kosovë">
                        </div>
                        @else
                        <div class="form-group">
                            <label class="form-label">Emri i plotë</label>
                            <input type="text" name="customer_name" class="form-input" placeholder="Emri Mbiemri" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="customer_email" class="form-input" placeholder="email@example.com" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Telefoni</label>
                            <input type="tel" name="customer_phone" class="form-input" placeholder="+383 44 000 000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Qyteti</label>
                            <input type="text" name="city" class="form-input" placeholder="Prishtinë">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="shipping_address" class="form-input" placeholder="Rruga, numri...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kodi Postar</label>
                            <input type="text" name="postal_code" class="form-input" placeholder="10000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Shteti</label>
                            <input type="text" name="country" class="form-input" placeholder="Kosovë">
                        </div>
                        @endauth
                    </div>
                </div>

                {{-- Mënyra e pagesës --}}
                <div class="checkout-section">
                    <div class="checkout-section-title">
                        <i class="fa-solid fa-wallet"></i>
                        Mënyra e pagesës
                    </div>
                    <div class="payment-options">
                        <div class="payment-option">
                            <input type="radio" name="payment_method" id="cash" value="cash" checked>
                            <label for="cash">
                                <i class="fa-solid fa-money-bill-wave" style="color:#34c759;"></i>
                                Para në dorë (Cash on delivery)
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" name="payment_method" id="bank" value="bank">
                            <label for="bank">
                                <i class="fa-solid fa-building-columns" style="color:var(--primary);"></i>
                                Transfertë bankare
                            </label>
                        </div>
                    </div>
                </div>

            </div>

            {{-- ── RIGHT: Order Summary ── --}}
            <div class="checkout-right">
                <div class="order-summary">

                    <div class="order-summary-title">Përmbledhja e porosisë</div>

                    <div class="order-items">
                        @foreach($cart as $key => $item)
                        <div class="order-item">
                            <div class="order-item-img">
                                @if($item['image'])
                                    <img src="{{ $item['image'] }}" alt="{{ $item['name'] }}">
                                @else
                                    <div class="order-item-img-ph"><i class="fa-solid fa-box"></i></div>
                                @endif
                            </div>
                            <div class="order-item-info">
                                <div class="order-item-name">{{ $item['name'] }}</div>
                                <div class="order-item-qty">Sasia: {{ $item['quantity'] }}</div>
                            </div>
                            <div class="order-item-price">
                                {{ number_format($item['price'] * $item['quantity'], 2) }} €
                            </div>
                        </div>
                        @endforeach
                    </div>

                    <div class="order-divider"></div>

                    <div class="order-totals">
                        <div class="order-row">
                            <span>Nëntotali</span>
                            <span>{{ number_format($total, 2) }} €</span>
                        </div>
                        <div class="order-row shipping">
                            <span>Dërgesa</span>
                            <span><i class="fa-solid fa-truck" style="font-size:11px;"></i> Falas</span>
                        </div>
                        <div class="order-divider"></div>
                        <div class="order-row total">
                            <span>Totali</span>
                            <span>{{ number_format($total, 2) }} €</span>
                        </div>
                    </div>

                    <button type="submit" class="checkout-btn">
                        <i class="fa-solid fa-check" style="font-size:13px;"></i>
                        Përfundo porosinë
                    </button>

                    <div class="secure-badge">
                        <i class="fa-solid fa-shield-halved" style="font-size:12px;"></i>
                        Transaksion i sigurt
                    </div>

                </div>
            </div>

        </div>
        </form>

    @endif
</div>
@endsection
