@extends('layouts.app')

@section('title', isset($order) ? 'Edito Porosinë' : 'Porosia e Re')
@section('page-title', isset($order) ? 'Edito Porosinë #'.str_pad($order->id,5,'0',STR_PAD_LEFT) : 'Porosi e Re')

@section('breadcrumb')
    <a href="{{ url('/') }}">Dashboard</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <a href="{{ url('/orders') }}">Porositë</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <span>{{ isset($order) ? '#'.str_pad($order->id,5,'0',STR_PAD_LEFT) : 'E Re' }}</span>
@endsection

@section('content')

<form action="{{ isset($order) ? url('/orders/'.$order->id) : url('/orders') }}" method="POST">
    @csrf
    @if(isset($order)) @method('PUT') @endif

    <div style="display:grid; grid-template-columns: 1fr 320px; gap:24px; align-items:start;">

        {{-- LEFT --}}
        <div style="display:flex;flex-direction:column;gap:20px;">

            {{-- Të Dhënat e Klientit --}}
            <div class="card">
                <div class="card-header">
                    <span class="card-title">Të Dhënat e Klientit</span>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Emri i Klientit *</label>
                            <input type="text" name="customer_name" class="form-control" value="{{ old('customer_name', $order->customer_name ?? '') }}" placeholder="Emri Mbiemri" required>
                            @error('customer_name') <div class="form-error">{{ $message }}</div> @enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email *</label>
                            <input type="email" name="customer_email" class="form-control" value="{{ old('customer_email', $order->customer_email ?? '') }}" placeholder="email@shembull.com" required>
                            @error('customer_email') <div class="form-error">{{ $message }}</div> @enderror
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Telefoni</label>
                            <input type="tel" name="customer_phone" class="form-control" value="{{ old('customer_phone', $order->customer_phone ?? '') }}" placeholder="+383 4X XXX XXX">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Qyteti</label>
                            <input type="text" name="customer_city" class="form-control" value="{{ old('customer_city', $order->customer_city ?? '') }}" placeholder="Prishtinë">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Adresa e Dërgimit</label>
                        <textarea name="shipping_address" class="form-control" rows="2" placeholder="Rruga, numri, lagjja...">{{ old('shipping_address', $order->shipping_address ?? '') }}</textarea>
                    </div>
                </div>
            </div>

            {{-- Produktet e Porosisë --}}
            <div class="card">
                <div class="card-header">
                    <span class="card-title">Produktet</span>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="addItem()">
                        <i class="fa-solid fa-plus"></i> Shto Produkt
                    </button>
                </div>
                <div class="card-body" style="padding:0;">
                    <div id="orderItems">
                        @if(isset($order) && $order->items->count() > 0)
                            @foreach($order->items as $i => $item)
                            <div class="order-item-row" style="display:grid;grid-template-columns:1fr 100px 110px 36px;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);">
                                <div>
                                    <label class="form-label">Produkti</label>
                                    <select name="items[{{ $i }}][product_id]" class="form-select" onchange="updatePrice(this, {{ $i }})">
                                        <option value="">— Zgjedh —</option>
                                        @foreach($products as $p)
                                        <option value="{{ $p->id }}" data-price="{{ $p->price }}" {{ $item->product_id == $p->id ? 'selected':'' }}>
                                            {{ $p->name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div>
                                    <label class="form-label">Sasia</label>
                                    <input type="number" name="items[{{ $i }}][quantity]" class="form-control item-qty" value="{{ $item->quantity }}" min="1" onchange="calcTotal()">
                                </div>
                                <div>
                                    <label class="form-label">Çmimi (€)</label>
                                    <input type="number" name="items[{{ $i }}][price]" class="form-control item-price" step="0.01" value="{{ $item->price }}" onchange="calcTotal()">
                                </div>
                                <div style="display:flex;align-items:flex-end;">
                                    <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="removeItem(this)">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </div>
                            @endforeach
                        @else
                        <div class="order-item-row" style="display:grid;grid-template-columns:1fr 100px 110px 36px;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);">
                            <div>
                                <label class="form-label">Produkti</label>
                                <select name="items[0][product_id]" class="form-select" onchange="updatePrice(this, 0)">
                                    <option value="">— Zgjedh produktin —</option>
                                    @foreach($products as $p)
                                    <option value="{{ $p->id }}" data-price="{{ $p->price }}">{{ $p->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div>
                                <label class="form-label">Sasia</label>
                                <input type="number" name="items[0][quantity]" class="form-control item-qty" value="1" min="1" onchange="calcTotal()">
                            </div>
                            <div>
                                <label class="form-label">Çmimi (€)</label>
                                <input type="number" name="items[0][price]" class="form-control item-price" step="0.01" value="0.00" onchange="calcTotal()">
                            </div>
                            <div style="display:flex;align-items:flex-end;">
                                <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="removeItem(this)">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>
                        @endif
                    </div>

                    {{-- Subtotal area --}}
                    <div style="padding:16px 20px;text-align:right;border-top:1px solid var(--border);">
                        <div style="display:inline-flex;flex-direction:column;gap:8px;min-width:220px;">
                            <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text-muted);">
                                <span>Nëntotali:</span>
                                <span id="subtotalDisplay">0.00 €</span>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text-muted);">
                                <span>Transporti:</span>
                                <span>2.50 €</span>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:700;border-top:1px solid var(--border);padding-top:8px;">
                                <span>Totali:</span>
                                <span style="font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--accent);" id="totalDisplay">2.50 €</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Shënime --}}
            <div class="card">
                <div class="card-header"><span class="card-title">Shënime</span></div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Shënime të brendshme</label>
                        <textarea name="notes" class="form-control" rows="3" placeholder="Shënime për stafin...">{{ old('notes', $order->notes ?? '') }}</textarea>
                    </div>
                </div>
            </div>

        </div>

        {{-- RIGHT --}}
        <div style="display:flex;flex-direction:column;gap:20px;">

            {{-- Statusi --}}
            <div class="card">
                <div class="card-header"><span class="card-title">Statusi i Porosisë</span></div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Statusi *</label>
                        <select name="status" class="form-select" required>
                            @php
                            $statuses = ['pending'=>'Në Pritje','confirmed'=>'Konfirmuar','processing'=>'Duke u Procesuar','shipped'=>'Dërguar','delivered'=>'Dorëzuar','cancelled'=>'Anuluar'];
                            @endphp
                            @foreach($statuses as $val => $label)
                            <option value="{{ $val }}" {{ old('status', $order->status ?? 'pending') == $val ? 'selected' : '' }}>
                                {{ $label }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mënyra e Pagesës</label>
                        <select name="payment_method" class="form-select">
                            <option value="cash" {{ old('payment_method', $order->payment_method ?? '') == 'cash' ? 'selected':'' }}>Para në dorë</option>
                            <option value="card" {{ old('payment_method', $order->payment_method ?? '') == 'card' ? 'selected':'' }}>Kartë</option>
                            <option value="bank" {{ old('payment_method', $order->payment_method ?? '') == 'bank' ? 'selected':'' }}>Transfer bankar</option>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label class="form-label">Totali (€)</label>
                        <input type="hidden" name="total" id="totalInput" value="{{ old('total', $order->total ?? 0) }}">
                        <div class="form-control" style="font-family:'Bebas Neue',sans-serif;font-size:24px;color:var(--accent);text-align:center;padding:14px;" id="totalReadout">
                            {{ number_format(old('total', $order->total ?? 0), 2) }} €
                        </div>
                    </div>
                </div>
            </div>

            {{-- Veprimet --}}
            <div style="display:flex;flex-direction:column;gap:10px;">
                <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:13px;">
                    <i class="fa-solid fa-{{ isset($order) ? 'floppy-disk' : 'bag-shopping' }}"></i>
                    {{ isset($order) ? 'Ruaj Ndryshimet' : 'Krijo Porosinë' }}
                </button>
                <a href="{{ url('/orders') }}" class="btn btn-secondary" style="width:100%;justify-content:center;">
                    <i class="fa-solid fa-arrow-left"></i> Kthehu
                </a>
            </div>

        </div>
    </div>
</form>

@endsection

@push('scripts')
<script>
let itemCount = {{ isset($order) ? $order->items->count() : 1 }};
const productsData = @json($products->map(fn($p) => ['id'=>$p->id,'name'=>$p->name,'price'=>$p->price]));

function addItem() {
    const i = itemCount++;
    const opts = productsData.map(p => `<option value="${p.id}" data-price="${p.price}">${p.name}</option>`).join('');
    const row = document.createElement('div');
    row.className = 'order-item-row';
    row.style.cssText = 'display:grid;grid-template-columns:1fr 100px 110px 36px;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);';
    row.innerHTML = `
        <div>
            <label class="form-label">Produkti</label>
            <select name="items[${i}][product_id]" class="form-select" onchange="updatePrice(this,${i})">
                <option value="">— Zgjedh produktin —</option>${opts}
            </select>
        </div>
        <div>
            <label class="form-label">Sasia</label>
            <input type="number" name="items[${i}][quantity]" class="form-control item-qty" value="1" min="1" onchange="calcTotal()">
        </div>
        <div>
            <label class="form-label">Çmimi (€)</label>
            <input type="number" name="items[${i}][price]" class="form-control item-price" step="0.01" value="0.00" onchange="calcTotal()">
        </div>
        <div style="display:flex;align-items:flex-end;">
            <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="removeItem(this)">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>`;
    document.getElementById('orderItems').appendChild(row);
}

function removeItem(btn) {
    const rows = document.querySelectorAll('.order-item-row');
    if (rows.length > 1) { btn.closest('.order-item-row').remove(); calcTotal(); }
}

function updatePrice(sel, i) {
    const opt = sel.options[sel.selectedIndex];
    const price = opt.dataset.price || 0;
    const row = sel.closest('.order-item-row');
    row.querySelector('.item-price').value = parseFloat(price).toFixed(2);
    calcTotal();
}

function calcTotal() {
    let sub = 0;
    document.querySelectorAll('.order-item-row').forEach(row => {
        const qty   = parseFloat(row.querySelector('.item-qty')?.value) || 0;
        const price = parseFloat(row.querySelector('.item-price')?.value) || 0;
        sub += qty * price;
    });
    const total = sub + 2.50;
    document.getElementById('subtotalDisplay').textContent = sub.toFixed(2) + ' €';
    document.getElementById('totalDisplay').textContent = total.toFixed(2) + ' €';
    document.getElementById('totalReadout').textContent = total.toFixed(2) + ' €';
    document.getElementById('totalInput').value = total.toFixed(2);
}

calcTotal();
</script>
@endpush