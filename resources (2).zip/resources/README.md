# Resources — Struktura e Organizuar

## 📁 Struktura e Folderëve

```
resources/
├── css/
│   ├── admin.css          ← Stilet e panelit admin
│   └── client.css         ← Stilet e storefront (klienti)
│
├── js/
│   ├── admin.js           ← JavaScript i panelit admin (sidebar toggle)
│   └── client.js          ← JavaScript i klientit (cart, wishlist, search)
│
└── views/
    ├── admin/             ← 🔒 PANELI ADMIN
    │   ├── layouts/
    │   │   └── app.blade.php          ← Layout kryesor admin
    │   ├── dashboard.blade.php
    │   ├── products/
    │   │   ├── index.blade.php
    │   │   └── create.blade.php
    │   ├── orders/
    │   │   ├── index.blade.php
    │   │   ├── show.blade.php
    │   │   └── create.blade.php
    │   ├── customers/
    │   │   ├── index.blade.php
    │   │   └── orders.blade.php
    │   ├── categories/
    │   │   └── index.blade.php
    │   ├── brands/
    │   │   └── index.blade.php
    │   ├── stock/
    │   │   ├── index.blade.php
    │   │   └── history.blade.php
    │   ├── banners/
    │   │   └── create.blade.php
    │   ├── settings/
    │   │   └── index.blade.php
    │   └── profile/
    │       ├── edit.blade.php
    │       └── partials/
    │
    ├── client/            ← 🛍️ STOREFRONT (KLIENTI)
    │   ├── layouts/
    │   │   └── app.blade.php          ← Layout kryesor klienti
    │   ├── pages/
    │   │   ├── home.blade.php
    │   │   ├── products.blade.php
    │   │   ├── product-detail.blade.php
    │   │   ├── contact.blade.php
    │   │   ├── privacy.blade.php
    │   │   └── terms.blade.php
    │   ├── order/
    │   │   ├── checkout.blade.php
    │   │   ├── create.blade.php
    │   │   ├── order-success.blade.php
    │   │   └── stripe-payment.blade.php
    │   ├── auth/
    │   │   ├── login.blade.php
    │   │   ├── register.blade.php
    │   │   ├── forgot-password.blade.php
    │   │   ├── reset-password.blade.php
    │   │   ├── confirm-password.blade.php
    │   │   └── verify-email.blade.php
    │   ├── profile/
    │   │   └── index.blade.php
    │   └── partials/
    │       ├── cart-sidebar.blade.php
    │       ├── cart-sidebar-items.blade.php
    │       └── hero-carousel.blade.php
    │
    ├── components/        ← Blade components të përbashkëta
    ├── emails/            ← Template emailesh
    └── welcome.blade.php
```

## 🔗 Si të Përdorësh Layoutet

### Admin views:
```blade
@extends('admin.layouts.app')
@section('title', 'Produktet')
@section('content')
    ...
@endsection
```

### Client views:
```blade
@extends('client.layouts.app')
@section('title', 'Kryefaqja')
@section('content')
    ...
@endsection
```

## 📦 Assets — public/ folder

Kopjo CSS dhe JS në `public/`:
```
public/
├── css/
│   ├── admin.css
│   └── client.css
└── js/
    ├── admin.js
    └── client.js
```

Ose nëse përdor Vite/Mix, importoji në `vite.config.js` / `webpack.mix.js`.
