@extends('layouts.app')

@section('title', 'Historia e Stokut — ' . $product->name)
@section('page-title', 'Historia e Stokut')

@section('breadcrumb')
    <a href="{{ url('/') }}">Dashboard</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <a href="{{ route('admin.stock.index') }}">Stoku</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <span>{{ $product->name }}</span>
@endsection

@push('styles')
<style>
.hist-header {
    display:flex;align-items:center;gap:16px;
    background:var(--surface);border:1px solid var(--border);
    border-radius:14px;padding:16px 20px;margin-bottom:20px;
}
.hist-img {
    width:52px;height:52px;border-radius:10px;
    object-fit:cover;background:var(--surface2);
    display:flex;align-items:center;justify-content:center;
    color:var(--border);font-size:20px;overflow:hidden;flex-shrink:0;
}
.hist-img img { width:100%;height:100%;object-fit:cover; }
.hist-name { font-size:18px;font-weight:800;font-family:'Syne',sans-serif; }
.hist-sub  { font-size:12px;color:var(--text-muted);margin-top:3px; }

/* TABLE */
.hist-table {
    width:100%;border-collapse:collapse;
    background:var(--surface);border:1px solid var(--border);
    border-radius:14px;overflow:hidden;
}
.hist-table thead tr {
    background:var(--surface2);border-bottom:1px solid var(--border);
}
.hist-table th {
    padding:10px 16px;text-align:left;
    font-size:10px;font-weight:700;letter-spacing:1px;
    text-transform:uppercase;color:var(--text-muted);
}
.hist-table tbody tr {
    border-bottom:1px solid var(--border);transition:background 0.15s;
}
.hist-table tbody tr:last-child { border-bottom:none; }
.hist-table tbody tr:hover { background:var(--surface2); }
.hist-table td { padding:11px 16px;font-size:13px;vertical-align:middle; }

/* Badge tipi */
.type-badge {
    padding:2px 9px;border-radius:20px;
    font-size:11px;font-weight:600;white-space:nowrap;
}
.type-badge.ok   { background:rgba(0,229,160,0.12);color:var(--accent3); }
.type-badge.low  { background:rgba(255,149,0,0.12);color:#ff9500; }
.type-badge.out  { background:rgba(248,113,113,0.12);color:var(--danger); }
.type-badge.blue { background:rgba(124,111,255,0.12);color:var(--accent); }

/* Sasia */
.qty-plus { color:var(--accent3);font-weight:700; }
.qty-minus { color:var(--danger);font-weight:700; }

/* Dot ngjyrë */
.c-dot {
    width:12px;height:12px;border-radius:50%;
    border:1px solid var(--border);display:inline-block;
    vertical-align:middle;margin-right:5px;
}
</style>
@endpush

@section('content')

{{-- Header produktit --}}
<div class="hist-header">
    @php
        $img = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    @endphp
    <div class="hist-img">
        @if($img)<img src="{{ asset('storage/'.$img->image_path) }}" alt="">
        @else<i class="fa-solid fa-box"></i>@endif
    </div>
    <div>
        <div class="hist-name">{{ $product->name }}</div>
        <div class="hist-sub">
            {{ $logs->total() }} regjistrime gjithsej
        </div>
    </div>
    <a href="{{ route('admin.stock.index') }}"
       class="btn btn-secondary" style="margin-left:auto;">
        <i class="fa-solid fa-arrow-left"></i> Kthehu
    </a>
</div>

{{-- Tabela --}}
<table class="hist-table">
    <thead>
        <tr>
            <th>Data</th>
            <th>Lloji</th>
            <th>Varianti</th>
            <th>Sasia</th>
            <th>Para</th>
            <th>Pas</th>
            <th>Shënim</th>
            <th>Nga</th>
        </tr>
    </thead>
    <tbody>
        @forelse($logs as $log)
        <tr>
            <td style="color:var(--text-muted);white-space:nowrap;">
                {{ $log->created_at->format('d/m/Y H:i') }}
            </td>
            <td>
                <span class="type-badge {{ $log->type_badge }}">
                    {{ $log->type_label }}
                </span>
            </td>
            <td>
                @if($log->variant)
                    @if($log->variant->color_hex)
                        <span class="c-dot" style="background:{{ $log->variant->color_hex }};"></span>
                    @endif
                    {{ $log->variant->color_name ?? '' }}
                    <span style="color:var(--text-muted);">{{ $log->variant->storage ?? '' }}</span>
                @else
                    <span style="color:var(--text-muted);">Pa variant</span>
                @endif
            </td>
            <td>
                <span class="{{ $log->quantity > 0 ? 'qty-plus' : 'qty-minus' }}">
                    {{ $log->quantity_display }}
                </span>
            </td>
            <td style="font-weight:600;">{{ $log->stock_before }}</td>
            <td style="font-weight:600;">{{ $log->stock_after }}</td>
            <td style="color:var(--text-muted);max-width:200px;">
                {{ $log->note ?? '—' }}
            </td>
            <td style="color:var(--text-muted);">
                {{ $log->creator?->name ?? 'Sistem' }}
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="8" style="text-align:center;padding:48px;color:var(--text-muted);">
                <i class="fa-solid fa-clock-rotate-left"
                   style="font-size:28px;opacity:0.3;display:block;margin-bottom:12px;"></i>
                Nuk ka historik ende.
            </td>
        </tr>
        @endforelse
    </tbody>
</table>

{{-- Pagination --}}
@if($logs->hasPages())
<div style="margin-top:20px;">
    {{ $logs->links() }}
</div>
@endif

@endsection