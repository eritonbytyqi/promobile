(function () {
    const slides     = document.querySelectorAll('.hero-slide');
    const dots       = document.querySelectorAll('.hero-dot');
    const progressEl = document.getElementById('heroProgress');
    const prevBtn    = document.getElementById('heroPrev');
    const nextBtn    = document.getElementById('heroNext');

    if (!slides.length) return;

    let current = 0;
    let autoTimer, progTimer;
    const INTERVAL = 5000; // ms ndërmjet slides

    function goTo(n) {
        slides[current].classList.remove('active');
        slides[current].classList.add('exit');

        const exitIndex = current;
        setTimeout(() => slides[exitIndex].classList.remove('exit'), 600);

        current = (n + slides.length) % slides.length;
        slides[current].classList.add('active');

        dots.forEach((d, i) => d.classList.toggle('active', i === current));
        resetProgress();
    }

    function resetProgress() {
        clearTimeout(autoTimer);
        clearTimeout(progTimer);

        if (progressEl) {
            progressEl.style.transition = 'none';
            progressEl.style.width = '0%';
        }

        progTimer = setTimeout(() => {
            if (progressEl) {
                progressEl.style.transition = 'width ' + INTERVAL + 'ms linear';
                progressEl.style.width = '100%';
            }
        }, 60);

        autoTimer = setTimeout(() => goTo(current + 1), INTERVAL + 100);
    }

    // Dot clicks
    dots.forEach((dot, i) => dot.addEventListener('click', () => goTo(i)));

    // Arrow clicks
    if (prevBtn) prevBtn.addEventListener('click', () => goTo(current - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => goTo(current + 1));

    // Swipe support (mobile)
    let touchStartX = 0;
    const carousel = document.getElementById('heroCarousel');
    if (carousel) {
        carousel.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
        carousel.addEventListener('touchend',   e => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
        });
    }

    // Start
    if (slides.length > 1) resetProgress();
})();