@extends('layouts.admin')

@section('title', isset($product) ? 'Edito Produktin' : 'Shto Produkt')
@section('page-title', isset($product) ? 'Edito Produktin' : 'Produkt i Ri')

@section('breadcrumb')
    <a href="{{ url('/') }}">Dashboard</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <a href="{{ url('/admin/products') }}">Produktet</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <span>{{ isset($product) ? $product->name : 'I Ri' }}</span>
@endsection

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/admin/products.css') }}">
@endpush

@section('content')
<div class="pf-wrap">

{{-- PAGE HEADER --}}
<div class="pf-header">
    <div>
        <div class="pf-breadcrumb">
            <a href="{{ url('/') }}">Dashboard</a>
            <i class="fa-solid fa-chevron-right" style="font-size:8px;"></i>
            <a href="{{ url('/admin/products') }}">Produktet</a>
            <i class="fa-solid fa-chevron-right" style="font-size:8px;"></i>
            <span>{{ isset($product) ? $product->name : 'I Ri' }}</span>
        </div>
        <h1 class="pf-title">
            {{ isset($product) ? 'Edito ' : 'Produkt ' }}<span>{{ isset($product) ? 'Produktin' : 'i Ri' }}</span>
        </h1>
    </div>
    <a href="{{ url('/admin/products') }}" class="btn btn-secondary">
        <i class="fa-solid fa-arrow-left"></i> Kthehu
    </a>
</div>

{{-- MAIN FORM --}}
<form action="{{ isset($product) ? url('/admin/products/'.$product->id) : url('/admin/products') }}"
      method="POST" enctype="multipart/form-data" id="productForm">
    @csrf
    @if(isset($product)) @method('PUT') @endif

    <div class="pf-grid">

        {{-- ═══════════════ LEFT COLUMN ═══════════════ --}}
        <div class="pf-left">

            {{-- ── Informacioni Bazë ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(230,57,70,0.10);color:var(--accent);">
                            <i class="fa-solid fa-box"></i>
                        </div>
                        Informacioni Bazë
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Emri i Produktit *</label>
                        <input type="text" name="name" class="form-control"
                               value="{{ old('name', $product->name ?? '') }}"
                               placeholder="p.sh. iPhone 15 Pro Max" required>
                        @error('name')<div class="form-error">{{ $message }}</div>@enderror
                    </div>
                    <div class="form-group">
                        <label class="form-label">Përshkrimi</label>
                        <textarea name="description" class="form-control" rows="5"
                                  placeholder="Përshkruani produktin...">{{ old('description', $product->description ?? '') }}</textarea>
                    </div>
                </div>
            </div>

            {{-- ── Çmimi & Stoku ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(5,150,105,0.10);color:var(--accent3);">
                            <i class="fa-solid fa-tag"></i>
                        </div>
                        Çmimi & Stoku
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Çmimi Bazë (€) *</label>
                            <input type="number" name="price" step="0.01" class="form-control"
                                   value="{{ old('price', $product->price ?? '') }}"
                                   placeholder="0.00">
                            @error('price')<div class="form-error">{{ $message }}</div>@enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">Çmimi me Zbritje (€)</label>
                            <input type="number" name="sale_price" step="0.01" class="form-control"
                                   value="{{ old('sale_price', $product->sale_price ?? '') }}" placeholder="0.00">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Stoku Bazë</label>
                            <input type="number" name="stock" class="form-control"
                                   value="{{ old('stock', $product->stock ?? 0) }}" placeholder="0">
                        </div>
                    </div>
                    <div class="hint-box">
                        <i class="fa-solid fa-circle-info"></i>
                        Nëse shton variante më poshtë, çmimi i variantit do zëvendësojë këtë çmim bazë.
                    </div>
                </div>
            </div>

            {{-- ── Galeria e Fotove ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(5,150,105,0.10);color:var(--accent3);">
                            <i class="fa-solid fa-images"></i>
                        </div>
                        Fotot e Produktit
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div id="dropzone" class="dropzone"
                             onclick="document.getElementById('imagesInput').click()"
                             ondragover="event.preventDefault();dzHover(true)"
                             ondragleave="dzHover(false)"
                             ondrop="handleDrop(event)">
                            <i class="fa-solid fa-cloud-arrow-up dropzone-icon"></i>
                            <div class="dropzone-text">
                                Tërhiq fotot këtu ose <span>kliko për upload</span>
                            </div>
                            <div class="dropzone-sub">JPG, PNG, WEBP — max 4MB secila</div>
                        </div>
                        <input type="file" id="imagesInput" name="images[]" multiple accept="image/*" hidden>
                        @error('images')<div class="form-error">{{ $message }}</div>@enderror
                    </div>

                    <div id="previewSection" style="display:none;">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                            <div class="card-title" style="font-size:13px;">Preview <span id="previewCount"></span></div>
                            <button type="button" class="btn btn-danger-soft btn-sm" onclick="clearPreviews()">
                                <i class="fa-solid fa-trash"></i> Pastro
                            </button>
                        </div>
                        <div id="previewList"></div>
                        <div class="primary-selector">
                            <label class="form-label" style="margin-bottom:0;">Foto Kryesore</label>
                            <select name="primary_index" id="primarySelect" class="form-select"></select>
                        </div>
                    </div>

                    @if(isset($product) && $product->images && $product->images->count())
                        <div class="section-sep"></div>
                        <div class="form-group">
                            <label class="form-label">Fotot Ekzistuese</label>
                            <div class="existing-grid">
                                @foreach($product->images as $img)
                                    <div class="existing-img-card {{ $img->is_primary ? 'is-primary' : '' }}" id="imgWrap{{ $img->id }}">
                                        <img src="{{ asset('storage/'.$img->image_path) }}" alt="">
                                        @if($img->is_primary)
                                            <span class="existing-primary-badge">
                                                <i class="fa-solid fa-star" style="font-size:8px;"></i> KRYESORE
                                            </span>
                                        @endif
                                        <div class="existing-img-actions">
                                            @if(!$img->is_primary)
                                                <button type="button" class="img-action-btn img-action-primary"
                                                        onclick="setPrimary({{ $img->id }}, {{ $product->id }})">
                                                    <i class="fa-solid fa-star"></i> Kryesore
                                                </button>
                                            @endif
                                            <button type="button" class="img-action-btn img-action-delete"
                                                    onclick="deleteImage({{ $img->id }}, {{ $product->id }})">
                                                <i class="fa-solid fa-trash"></i> Fshi
                                            </button>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            {{-- ── Variantet (Ngjyra + Foto Multiple + Storage Multiple) ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(124,58,237,0.10);color:#7c3aed;">
                            <i class="fa-solid fa-palette"></i>
                        </div>
                        Variantet — Ngjyra, Foto & Storage
                    </div>
                    <button type="button" onclick="addVariant()" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-plus"></i> Shto Ngjyrë
                    </button>
                </div>
                <div class="card-body">
                    <div id="variantsList" style="display:flex;flex-direction:column;gap:16px;">

                    @php
    $groupedVariants = isset($product) && $product->variants
        ? $product->variants->groupBy(function ($v) {
            return trim(($v->color_hex ?? '')) . '||' . trim(($v->color_name ?? ''));
        })
        : collect();

    $groupedVarImages = isset($product) && $product->variantImages
        ? $product->variantImages->groupBy(function ($img) {
            return trim(($img->color_hex ?? '')) . '||' . trim(($img->color_name ?? ''));
        })
        : collect();
@endphp

                        @if($groupedVariants->count() > 0)
                        @foreach($groupedVariants as $colorKey => $colorVariants)
    @php
        $vi = $loop->index;
        $firstVariant = $colorVariants->first();
        $colorImages  = $groupedVarImages->get($colorKey, collect());
    @endphp 

                                <div class="variant-color-group" id="variant_{{ $vi }}">
                                    {{-- HEAD --}}
                                    <div class="variant-color-head">
                                        <div class="color-swatch-preview" id="swatchPreview_{{ $vi }}"
                                             style="background:{{ $firstVariant->color_hex ?? '#cccccc' }};">
                                        </div>

                                        <div>
                                            <label class="form-label" style="margin-bottom:6px;">Ngjyra</label>
                                            <div class="color-picker-row">
                                                // Brenda variant-color-head, pas color-picker-row
<div>
    <label class="form-label" style="margin-bottom:6px;">Çmimi Bazë (€)</label>
    <input type="number" step="0.01"
           name="variants[${vi}][base_price]"
           id="basePrice_${vi}"
           class="form-control"
           placeholder="p.sh. 999.00"
           oninput="refreshAllTotals(${vi})">
</div>
                                                <input type="color"
                                                       name="variants[{{ $vi }}][color_hex]"
                                                       value="{{ $firstVariant->color_hex ?? '#cccccc' }}"
                                                       oninput="updateSwatch({{ $vi }}, this.value)">
                                                <input type="text"
                                                       name="variants[{{ $vi }}][color_name]"
                                                       class="form-control"
                                                       value="{{ $firstVariant->color_name ?? '' }}"
                                                       placeholder="p.sh. Black, Midnight, Silver">
                                            </div>
                                        </div>

                                        <div></div>

                                        <button type="button" class="rm-btn" onclick="removeVariant({{ $vi }})">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    </div>

                                    <div class="variant-body">
                                        {{-- FOTO MULTIPLE — nga product_variant_images --}}
                                        <div class="color-photos-section">
                                            <div class="color-photos-header">
                                                <div class="label">
                                                    <i class="fa-solid fa-images" style="color:var(--accent3);"></i>
                                                    Fotot e Ngjyrës
                                                    @if($colorImages->count())
                                                        <span style="background:rgba(5,150,105,0.1);color:var(--accent3);padding:1px 8px;border-radius:10px;font-size:10px;">
                                                            {{ $colorImages->count() }} foto
                                                        </span>
                                                    @endif
                                                </div>
                                                <button type="button"
                                                        onclick="document.getElementById('colorPhotoInput_{{ $vi }}').click()"
                                                        class="btn btn-success-soft btn-sm">
                                                    <i class="fa-solid fa-plus"></i> Shto Foto
                                                </button>
                                                <input type="file"
                                                       id="colorPhotoInput_{{ $vi }}"
                                                       name="variants[{{ $vi }}][images][]"
                                                       accept="image/*"
                                                       multiple
                                                       hidden
                                                       onchange="addColorPhotos(this, {{ $vi }})">
                                            </div>
                                            <div class="color-photos-grid" id="colorPhotosGrid_{{ $vi }}">

                                                {{-- ★ NDRYSHIMI KRYESOR: Lexo fotot nga variantImages, jo nga image_path --}}
                                                @foreach($colorImages as $imgIdx => $varImg)
                                                    <div class="color-photo-item {{ $varImg->is_primary ? 'primary-photo' : '' }}"
                                                         data-vi="{{ $vi }}"
                                                         data-existing-id="{{ $varImg->id }}">
                                                        <img src="{{ asset('storage/'.$varImg->image_path) }}" alt="">
                                                        {{-- Dërgo path ekzistues me form --}}
                                                        <input type="hidden"
                                                               name="variants[{{ $vi }}][existing_images][]"
                                                               value="{{ $varImg->image_path }}">
                                                        @if($varImg->is_primary)
                                                            <span class="color-photo-primary-badge">★ Kryesore</span>
                                                        @endif
                                                        <button type="button" class="color-photo-rm"
                                                                onclick="removeColorPhoto(this)">
                                                            <i class="fa-solid fa-xmark"></i>
                                                        </button>
                                                    </div>
                                                @endforeach

                                                {{-- Nëse nuk ka asnjë foto në variantImages, shfaq mesazh --}}
                                                @if($colorImages->isEmpty())
                                                    <div style="padding:12px;font-size:11px;color:var(--text-muted);width:100%;">
                                                        <i class="fa-solid fa-circle-info"></i>
                                                        Nuk ka foto për këtë ngjyrë. Shto fotot e para.
                                                    </div>
                                                @endif

                                                <div class="color-photo-add-btn"
                                                     onclick="document.getElementById('colorPhotoInput_{{ $vi }}').click()">
                                                    <i class="fa-solid fa-plus"></i>
                                                    <span>Shto</span>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- STORAGE MULTIPLE --}}
                                        <div class="storage-section">
                                            <div class="storage-section-header">
                                                <div class="label">
                                                    <i class="fa-solid fa-hard-drive" style="color:#7c3aed;"></i>
                                                    Storage / Çmimi / Stoku
                                                </div>
                                                <button type="button"
                                                        onclick="addStorageRow({{ $vi }})"
                                                        class="btn btn-secondary btn-sm">
                                                    <i class="fa-solid fa-plus"></i> Shto Storage
                                                </button>
                                            </div>
<div class="storage-col-headers">
    <span>Storage</span>
    <span>Bazë (€)</span>
    <span>Shtesë (€)</span>
    <span>Totali</span>
    <span>Stoku</span>
    <span></span>
</div>
                                     @foreach($colorVariants as $si => $sv)
<div class="storage-row" id="storageRow_{{ $vi }}_{{ $si }}">

    <select name="variants[{{ $vi }}][storages][{{ $si }}][storage]" class="form-select">
        <option value="">— Zgjedh —</option>
        @foreach(['64GB','128GB','256GB','512GB','1TB','2TB'] as $opt)
            <option value="{{ $opt }}" {{ ($sv->storage ?? '') === $opt ? 'selected' : '' }}>{{ $opt }}</option>
        @endforeach
        @if(!in_array($sv->storage ?? '', ['','64GB','128GB','256GB','512GB','1TB','2TB']))
            <option value="{{ $sv->storage }}" selected>{{ $sv->storage }}</option>
        @endif
    </select>

    @if($si === 0)
        <input type="number" step="0.01"
               name="variants[{{ $vi }}][storages][{{ $si }}][base_price]"
               class="form-control storage-base"
               id="basePrice_{{ $vi }}"
               value="{{ $sv->base_price ?? '' }}"
               placeholder="999.00"
               oninput="syncBasePrice({{ $vi }}); calcTotal({{ $vi }}, {{ $si }})">
    @else
        <div style="font-size:12px;color:var(--text-muted);align-self:center;padding:0 4px;">
            <i class="fa-solid fa-arrow-turn-down-right" style="font-size:10px;"></i>
            <span id="baseDisplay_{{ $vi }}_{{ $si }}" style="font-weight:600;">
                {{ $sv->base_price > 0 ? number_format($sv->base_price, 2) . ' €' : '—' }}
            </span>
        </div>
        <input type="hidden"
               name="variants[{{ $vi }}][storages][{{ $si }}][base_price]"
               id="basePriceHidden_{{ $vi }}_{{ $si }}"
               value="{{ $sv->base_price ?? 0 }}">
    @endif

    <input type="number" step="0.01"
           name="variants[{{ $vi }}][storages][{{ $si }}][extra_price]"
           class="form-control"
           value="{{ $sv->extra_price ?? 0 }}"
           placeholder="+0.00"
           oninput="calcTotal({{ $vi }}, {{ $si }})">

    <div style="font-size:13px;color:#059669;font-weight:700;align-self:center;"
         id="total_{{ $vi }}_{{ $si }}">
        @php $t = ($sv->base_price ?? 0) + ($sv->extra_price ?? 0); @endphp
        {{ $t > 0 ? number_format($t, 2) . ' €' : '—' }}
    </div>

    <input type="number"
           name="variants[{{ $vi }}][storages][{{ $si }}][stock]"
           class="form-control"
           value="{{ $sv->stock ?? 0 }}"
           placeholder="0">

    <button type="button" class="rm-btn-sm" onclick="removeStorageRow(this)">
        <i class="fa-solid fa-xmark"></i>
    </button>
</div>
@endforeach
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div id="variantsEmpty" class="variant-empty">
                                <i class="fa-solid fa-palette" style="font-size:28px;opacity:0.2;display:block;margin-bottom:10px;"></i>
                                Nuk ka variante. Kliko <strong>"Shto Ngjyrë"</strong> për të shtuar ngjyrë me foto dhe storage.
                            </div>
                        @endif
                    </div>

                    <div class="hint-box" style="margin-top:4px;">
                        <i class="fa-solid fa-circle-info"></i>
                        Për çdo ngjyrë mund të shtosh <strong style="color:#92400e;">shumë foto</strong> dhe <strong style="color:#92400e;">shumë storage</strong> (128GB, 256GB, etj). Accessories mund t'i lënë storage bosh.
                    </div>
                </div>
            </div>

            {{-- ── Karakteristikat Teknike ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(217,119,6,0.10);color:var(--accent2);">
                            <i class="fa-solid fa-list-check"></i>
                        </div>
                        Karakteristikat Teknike
                    </div>
                    <button type="button" onclick="addSpec()" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-plus"></i> Shto
                    </button>
                </div>
                <div class="card-body">
                    <div class="spec-header">
                        <span>Karakteristika</span>
                        <span>Vlera</span>
                        <span></span>
                    </div>
                 <div id="specsList" style="display:flex;flex-direction:column;gap:8px;">

    {{-- Sugjerimet shfaqen GJITHMONË --}}
    <div class="spec-suggestions" id="specSuggestions">
        @foreach(['Ekrani','Procesori','RAM','Bateria','Kamera','OS','Pesha','Dimensionet','USB','5G','Garancia','Dërgesa'] as $sug)
            <button type="button" onclick="addSpec('{{ $sug }}')" class="spec-chip">
                + {{ $sug }}
            </button>
        @endforeach
    </div>

    {{-- Specs ekzistuese (edit mode) --}}
    @if(isset($product) && $product->specs && $product->specs->count() > 0)
        @foreach($product->specs as $si => $spec)
            <div class="spec-row" id="specRow_{{ $si }}">
                <input type="text" name="specs[{{ $si }}][key]"
                       class="form-control" value="{{ $spec->spec_key }}"
                       placeholder="p.sh. Ekrani">
                <input type="text" name="specs[{{ $si }}][value]"
                       class="form-control" value="{{ $spec->spec_value }}"
                       placeholder="p.sh. 6.7&quot; OLED">
                <button type="button" onclick="removeSpec(this)" class="rm-btn">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
        @endforeach
    @else
        <div id="specsEmpty" class="spec-empty">
            <i class="fa-solid fa-list-check" style="font-size:22px;opacity:0.2;display:block;margin-bottom:8px;"></i>
            Nuk ka karakteristika. Kliko "Shto" ose zgjidh nga sugjerimet.
        </div>
    @endif

</div>
                </div>
            </div>

        </div>
        {{-- /LEFT --}}

        {{-- ═══════════════ RIGHT COLUMN ═══════════════ --}}
        <div class="pf-right">

            {{-- ── Publikimi ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(230,57,70,0.10);color:var(--accent);">
                            <i class="fa-solid fa-rocket"></i>
                        </div>
                        Publikimi
                    </div>
                </div>
                <div class="card-body" style="gap:0;padding:14px 22px;">
                    <div class="toggle-row">
                        <div>
                            <div class="toggle-label-title">
                                <i class="fa-solid fa-star" style="color:var(--accent2);"></i>
                                Produkt i Featuar
                            </div>
                            <div class="toggle-label-sub">Shfaqet në seksionin kryesor</div>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" name="featured" value="1"
                                   {{ old('featured', $product->featured ?? false) ? 'checked' : '' }}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div class="toggle-row">
                        <div>
                            <div class="toggle-label-title">
                                <i class="fa-solid fa-eye" style="color:var(--accent3);"></i>
                                Aktiv / i Dukshëm
                            </div>
                            <div class="toggle-label-sub">Shfaqet në dyqan</div>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" name="is_active" value="1"
                                   {{ old('is_active', $product->is_active ?? true) ? 'checked' : '' }}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>
            </div>

            {{-- ── Organizimi ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(124,58,237,0.10);color:#7c3aed;">
                            <i class="fa-solid fa-folder-tree"></i>
                        </div>
                        Organizimi
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Kategoria *</label>
                        <select name="category_id" id="categorySelect" class="form-select" required>
                            <option value="">— Zgjedh kategorinë —</option>
                            @foreach($categories as $cat)
                                <option value="{{ $cat->id }}"
                                    {{ old('category_id', $product->category_id ?? '') == $cat->id ? 'selected' : '' }}>
                                    {{ $cat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Brendi</label>
                        <select name="brand_id" id="brandSelect" class="form-select">
                            <option value="">— Zgjedh brendin —</option>
                            {{-- Brendi i zgjedhur i produktit aktual --}}
                            @if(isset($product) && $product->brand)
                                <option value="{{ $product->brand->id }}" selected>
                                    {{ $product->brand->name }}
                                </option>
                            @endif
                        </select>
                    </div>
                </div>
            </div>

            {{-- ── Rezymeja e Fotove ── --}}
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-title-icon" style="background:rgba(5,150,105,0.10);color:var(--accent3);">
                            <i class="fa-solid fa-images"></i>
                        </div>
                        Fotot
                    </div>
                </div>
                <div class="card-body" style="gap:0;padding:14px 22px;">
                    <div class="photo-stat">
                        <span style="font-size:13px;color:var(--text-muted);">Ekzistuese</span>
                        <span class="photo-stat-val" id="statExisting">
                            {{ isset($product) ? ($product->images->count() ?? 0) : 0 }}
                        </span>
                    </div>
                    <div class="photo-stat">
                        <span style="font-size:13px;color:var(--text-muted);">Të reja</span>
                        <span class="photo-stat-val" id="statNew">0</span>
                    </div>
                    <div class="photo-stat" style="border-top:1px solid var(--border);margin-top:4px;padding-top:12px;">
                        <span style="font-size:13px;font-weight:600;">Gjithsej</span>
                        <span class="photo-stat-val" style="color:var(--accent);" id="statTotal">
                            {{ isset($product) ? ($product->images->count() ?? 0) : 0 }}
                        </span>
                    </div>
                </div>
            </div>

            {{-- ── Butonat ── --}}
            <div class="pf-actions" style="display:flex;flex-direction:column;gap:10px;">
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fa-solid fa-{{ isset($product) ? 'floppy-disk' : 'box' }}"></i>
                    {{ isset($product) ? 'Ruaj Ndryshimet' : 'Krijo Produktin' }}
                </button>
                <a href="{{ url('/admin/products') }}" class="btn btn-secondary btn-full">
                    <i class="fa-solid fa-arrow-left"></i> Kthehu
                </a>
            </div>

        </div>{{-- /RIGHT --}}
    </div>
</form>

</div>{{-- /pf-wrap --}}
@endsection

@push('scripts')
<script>
// ════════════ FOTO KRYESORE TË PRODUKTIT ════════════
let selectedFiles = [];
const existingCount = {{ isset($product) ? ($product->images->count() ?? 0) : 0 }};

function dzHover(on) {
    document.getElementById('dropzone')?.classList.toggle('hover', on);
}

function handleDrop(e) {
    e.preventDefault();
    dzHover(false);
    const dropped = Array.from(e.dataTransfer.files || []).filter(f => f.type.startsWith('image/'));
    if (dropped.length) addFiles(dropped);
}

function addFiles(incoming) {
    Array.from(incoming).forEach(f => {
        const exists = selectedFiles.some(s =>
            s.name === f.name &&
            s.size === f.size &&
            s.lastModified === f.lastModified
        );

        if (!exists) {
            selectedFiles.push(f);
        }
    });

    syncInputFiles();
    renderPreviews();
}

function syncInputFiles() {
    const input = document.getElementById('imagesInput');
    if (!input) return;

    const dt = new DataTransfer();
    selectedFiles.forEach(f => dt.items.add(f));
    input.files = dt.files;
}

function renderPreviews() {
    const section = document.getElementById('previewSection');
    const list = document.getElementById('previewList');
    const countEl = document.getElementById('previewCount');
    const selPrim = document.getElementById('primarySelect');

    if (!section || !list || !countEl || !selPrim) return;

    updateStats();

    if (!selectedFiles.length) {
        section.style.display = 'none';
        list.innerHTML = '';
        selPrim.innerHTML = '';
        return;
    }

    section.style.display = 'block';
    countEl.textContent = selectedFiles.length + ' foto';
    list.innerHTML = '';
    selPrim.innerHTML = '';

    selectedFiles.forEach((file, i) => {
        const div = document.createElement('div');
        div.className = 'prev-item' + (i === 0 ? ' primary' : '');
        div.id = `prev_${i}`;

        const reader = new FileReader();
        reader.onload = ev => {
            div.innerHTML = `
                <img src="${ev.target.result}" alt="${file.name}">
                ${i === 0 ? '<div class="p-label"><i class="fa-solid fa-star" style="font-size:8px;"></i> KRYESORE</div>' : ''}
                <div class="prev-actions">
                    <button type="button" class="prev-rm-btn" onclick="removeFile(${i})">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>`;
        };
        reader.readAsDataURL(file);

        list.appendChild(div);

        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = `Foto ${i + 1} — ${file.name.substring(0, 22)}`;
        selPrim.appendChild(opt);
    });

    selPrim.value = "0";
}

function removeFile(idx) {
    selectedFiles.splice(idx, 1);
    syncInputFiles();
    renderPreviews();
}

function clearPreviews() {
    selectedFiles = [];

    const input = document.getElementById('imagesInput');
    if (input) input.value = '';

    const section = document.getElementById('previewSection');
    const list = document.getElementById('previewList');
    const primary = document.getElementById('primarySelect');

    if (section) section.style.display = 'none';
    if (list) list.innerHTML = '';
    if (primary) primary.innerHTML = '';

    updateStats();
}

function updateStats() {
    const n = selectedFiles.length;
    const sN = document.getElementById('statNew');
    const sT = document.getElementById('statTotal');

    if (sN) sN.textContent = n;
    if (sT) sT.textContent = existingCount + n;
}

document.addEventListener('change', function (e) {
    if (e.target.id === 'imagesInput') {
        addFiles(e.target.files);
    }

    if (e.target.id === 'primarySelect') {
        const idx = parseInt(e.target.value, 10);

        document.querySelectorAll('.prev-item').forEach((el, i) => {
            el.classList.toggle('primary', i === idx);

            const lbl = el.querySelector('.p-label');
            if (i === idx && !lbl) {
                el.insertAdjacentHTML('beforeend', '<div class="p-label"><i class="fa-solid fa-star" style="font-size:8px;"></i> KRYESORE</div>');
            } else if (i !== idx && lbl) {
                lbl.remove();
            }
        });
    }
});

// ════════════ VARIANTET ════════════
let variantIndex = {{ isset($product) && $product->variants
    ? $product->variants->groupBy(function ($v) {
        return trim(($v->color_hex ?? '')) . '||' . trim(($v->color_name ?? ''));
    })->count()
    : 0 }};

const storageCounters = {};
const variantPhotoFiles = {};

// Inicializo counter-at për variantet ekzistuese
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.variant-color-group').forEach(group => {
        const id = group.id || '';
        const parts = id.split('_');
        if (parts.length < 2) return;

        const vi = parseInt(parts[1], 10);
        if (isNaN(vi)) return;

        storageCounters[vi] = document.querySelectorAll(`#storageRows_${vi} .storage-row`).length;
        variantPhotoFiles[vi] = [];
    });
});

function updateSwatch(vi, color) {
    const swatch = document.getElementById(`swatchPreview_${vi}`);
    if (swatch) swatch.style.background = color;
}

function addVariant() {
    const list = document.getElementById('variantsList');
    const empty = document.getElementById('variantsEmpty');
    if (empty) empty.remove();

    const vi = variantIndex++;
    variantPhotoFiles[vi] = [];
    storageCounters[vi] = 0;

    const wrap = document.createElement('div');
    wrap.className = 'variant-color-group';
    wrap.id = `variant_${vi}`;

    wrap.innerHTML = `
        <div class="variant-color-head">
            <div class="color-swatch-preview" id="swatchPreview_${vi}" style="background:#cccccc;"></div>

            <div>
                <label class="form-label" style="margin-bottom:6px;">Ngjyra</label>
                <div class="color-picker-row">
                    <input type="color"
                           name="variants[${vi}][color_hex]"
                           value="#cccccc"
                           oninput="updateSwatch(${vi}, this.value)">
                    <input type="text"
                           name="variants[${vi}][color_name]"
                           class="form-control"
                           placeholder="p.sh. Black, Midnight, Silver">
                </div>
            </div>

            <div></div>
 <div>
        <label class="form-label">Çmimi Bazë (€)</label>
     <input type="number" step="0.01"
       name="variants[${vi}][base_price]"
       id="basePrice_${vi}"
       class="form-control"
       placeholder="p.sh. 999.00"
       oninput="refreshAllTotals(${vi})">
    </div>
            <button type="button" class="rm-btn" onclick="removeVariant(${vi})">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div class="variant-body">
            <div class="color-photos-section">
                <div class="color-photos-header">
                    <div class="label">
                        <i class="fa-solid fa-images" style="color:var(--accent3);"></i>
                        Fotot e Ngjyrës
                    </div>

                    <button type="button"
                            onclick="document.getElementById('colorPhotoInput_${vi}').click()"
                            class="btn btn-success-soft btn-sm">
                        <i class="fa-solid fa-plus"></i> Shto Foto
                    </button>

                    <input type="file"
                           id="colorPhotoInput_${vi}"
                           name="variants[${vi}][images][]"
                           accept="image/*"
                           multiple
                           hidden
                           onchange="addColorPhotos(this, ${vi})">

                </div>

                <div class="color-photos-grid" id="colorPhotosGrid_${vi}">
                    <div class="color-photo-add-btn"
                         onclick="document.getElementById('colorPhotoInput_${vi}').click()">
                        <i class="fa-solid fa-plus"></i>
                        <span>Shto Foto</span>
                    </div>
                </div>
            </div>

            <div class="storage-section">
                <div class="storage-section-header">
                    <div class="label">
                        <i class="fa-solid fa-hard-drive" style="color:#7c3aed;"></i>
                        Storage / Çmimi / Stoku
                    </div>

                    <button type="button"
                            onclick="addStorageRow(${vi})"
                            class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-plus"></i> Shto Storage
                    </button>
                </div>

<div class="storage-col-headers">
    <span>Storage</span>
    <span>Bazë (€)</span>
    <span>Shtesë (€)</span>
    <span>Totali</span>
    <span>Stoku</span>
    <span></span>
</div>

                <div class="storage-rows" id="storageRows_${vi}">
                    <div class="storage-empty" id="storageEmpty_${vi}">
                        Nuk ka storage. Kliko "Shto Storage".
                    </div>
                </div>
            </div>
        </div>
    `;

    list.appendChild(wrap);
}

function removeVariant(vi) {
    const el = document.getElementById(`variant_${vi}`);
    if (el) el.remove();

    delete variantPhotoFiles[vi];
    delete storageCounters[vi];

    const list = document.getElementById('variantsList');
    if (!list.querySelector('.variant-color-group')) {
        list.innerHTML = `
            <div id="variantsEmpty" class="variant-empty">
                <i class="fa-solid fa-palette" style="font-size:28px;opacity:0.2;display:block;margin-bottom:10px;"></i>
                Nuk ka variante. Kliko <strong>"Shto Ngjyrë"</strong> për të shtuar ngjyrë me foto dhe storage.
            </div>`;
    }
}

function syncColorPhotoInput(vi) {
    const input = document.getElementById(`colorPhotoInput_${vi}`);
    if (!input) return;

    const dt = new DataTransfer();
    (variantPhotoFiles[vi] || []).forEach(file => dt.items.add(file));
    input.files = dt.files;
}

function refreshPrimaryBadges(vi) {
    const grid = document.getElementById(`colorPhotosGrid_${vi}`);
    if (!grid) return;

    const items = Array.from(grid.querySelectorAll('.color-photo-item'));

    items.forEach((el, i) => {
        el.classList.toggle('primary-photo', i === 0);

        const badge = el.querySelector('.color-photo-primary-badge');
        if (i === 0 && !badge) {
            el.insertAdjacentHTML('beforeend', '<span class="color-photo-primary-badge">★ Kryesore</span>');
        } else if (i !== 0 && badge) {
            badge.remove();
        }
    });
}

function renderColorPhotos(vi) {
    const grid = document.getElementById(`colorPhotosGrid_${vi}`);
    if (!grid) return;

    // Largo preview-t e upload-eve të reja
    grid.querySelectorAll('.color-photo-item.new-upload').forEach(el => el.remove());

    const addBtn = grid.querySelector('.color-photo-add-btn');
    const files = variantPhotoFiles[vi] || [];

    files.forEach((file, idx) => {
        const reader = new FileReader();

        reader.onload = function (e) {
            const item = document.createElement('div');
            item.className = 'color-photo-item new-upload';
            item.dataset.vi = vi;
            item.dataset.idx = idx;

            item.innerHTML = `
                <img src="${e.target.result}" alt="">
                <button type="button" class="color-photo-rm" onclick="removeColorPhoto(this)">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            `;

            if (addBtn) {
                grid.insertBefore(item, addBtn);
            } else {
                grid.appendChild(item);
            }

            refreshPrimaryBadges(vi);
        };

        reader.readAsDataURL(file);
    });

    setTimeout(() => refreshPrimaryBadges(vi), 30);
}

function addColorPhotos(input, vi) {
    if (!input.files || !input.files.length) return;

    if (!variantPhotoFiles[vi]) {
        variantPhotoFiles[vi] = [];
    }

    Array.from(input.files).forEach(file => {
        const exists = variantPhotoFiles[vi].some(f =>
            f.name === file.name &&
            f.size === file.size &&
            f.lastModified === file.lastModified
        );

        if (!exists) {
            variantPhotoFiles[vi].push(file);
        }
    });
    input.value = '';

    syncColorPhotoInput(vi);
    renderColorPhotos(vi);

}

function removeColorPhoto(btn) {
    const item = btn.closest('.color-photo-item');
    if (!item) return;

    const vi = parseInt(item.dataset.vi, 10);

    // Foto ekzistuese nga DB
    const hiddenInput = item.querySelector('input[type="hidden"]');
    if (hiddenInput) {
        item.remove();
        refreshPrimaryBadges(vi);
        return;
    }

    // Foto e re
    const idx = parseInt(item.dataset.idx, 10);
    if (!isNaN(vi) && !isNaN(idx) && variantPhotoFiles[vi]) {
        variantPhotoFiles[vi].splice(idx, 1);
        syncColorPhotoInput(vi);
        renderColorPhotos(vi);
        return;
    }

    item.remove();
    refreshPrimaryBadges(vi);
}

function addStorageRow(vi) {
    if (storageCounters[vi] === undefined) {
        storageCounters[vi] = document.querySelectorAll(`#storageRows_${vi} .storage-row`).length;
    }

    const si = storageCounters[vi]++;
    const isFirst = si === 0;
    const container = document.getElementById(`storageRows_${vi}`);
    if (!container) return;

    const empty = document.getElementById(`storageEmpty_${vi}`);
    if (empty) empty.remove();

    const row = document.createElement('div');
    row.className = 'storage-row';
    row.id = `storageRow_${vi}_${si}`;

    row.innerHTML = `
        <select name="variants[${vi}][storages][${si}][storage]" class="form-select">
            <option value="">— Zgjedh —</option>
            <option value="64GB">64GB</option>
            <option value="128GB">128GB</option>
            <option value="256GB">256GB</option>
            <option value="512GB">512GB</option>
            <option value="1TB">1TB</option>
            <option value="2TB">2TB</option>
        </select>

        ${isFirst ? `
        <input type="number" step="0.01"
               name="variants[${vi}][storages][${si}][base_price]"
               class="form-control storage-base"
               id="basePrice_${vi}"
               placeholder="999.00"
               oninput="syncBasePrice(${vi}); calcTotal(${vi}, ${si})">
        ` : `
        <div style="font-size:12px;color:var(--text-muted);align-self:center;padding:0 4px;">
            <i class="fa-solid fa-arrow-turn-down-right" style="font-size:10px;"></i>
            <span id="baseDisplay_${vi}_${si}" style="font-weight:600;">—</span>
        </div>
        <input type="hidden" name="variants[${vi}][storages][${si}][base_price]"
               id="basePriceHidden_${vi}_${si}" value="0">
        `}

        <input type="number" step="0.01"
               name="variants[${vi}][storages][${si}][extra_price]"
               class="form-control"
               placeholder="+0.00"
               oninput="calcTotal(${vi}, ${si})">

        <div style="font-size:13px;color:#059669;font-weight:700;align-self:center;"
             id="total_${vi}_${si}">—</div>

        <input type="number"
               name="variants[${vi}][storages][${si}][stock]"
               class="form-control"
               value="0" placeholder="0">

        <button type="button" class="rm-btn-sm" onclick="removeStorageRow(this)">
            <i class="fa-solid fa-xmark"></i>
        </button>
    `;

    container.appendChild(row);
}
function updateStoragePrice(select, vi, si) {
    const customInput = document.getElementById(`customStorage_${vi}_${si}`);
    
    // Shfaq input custom nëse zgjedh "Tjetër"
    if (select.value === 'custom') {
        customInput.style.display = 'block';
        select.style.width = '50%';
    } else {
        customInput.style.display = 'none';
        select.style.width = '';
        // Nëse zgjedh storage, vendos çmim bazë automatik nga produkti
        const basePrice = parseFloat(document.querySelector('[name="price"]')?.value || 0);
        const extras = { '64GB': 0, '128GB': 0, '256GB': 50, '512GB': 100, '1TB': 200, '2TB': 350 };
        const extra = extras[select.value] || 0;
        const priceInput = document.getElementById(`storagePrice_${vi}_${si}`);
        if (priceInput && !priceInput.value) {
            priceInput.value = basePrice > 0 ? (basePrice + extra).toFixed(2) : '';
        }
    }
}
function removeStorageRow(btn) {
    const row = btn.closest('.storage-row');
    if (!row) return;

    const vi = row.id.split('_')[1];
    row.remove();

    const container = document.getElementById(`storageRows_${vi}`);
    if (container && !container.querySelector('.storage-row')) {
        container.innerHTML = `
            <div class="storage-empty" id="storageEmpty_${vi}">
                Nuk ka storage. Kliko "Shto Storage".
            </div>`;
    }
}

// ════════════ SPECS ════════════
let specIndex = {{ isset($product) && $product->specs ? $product->specs->count() : 0 }};

function addSpec(keyName = '') {
    const empty = document.getElementById('specsEmpty');
    if (empty) empty.style.display = 'none';

    const si = specIndex++;
    const row = document.createElement('div');
    row.className = 'spec-row';
    row.id = `specRow_${si}`;
    row.innerHTML = `
        <input type="text"
               name="specs[${si}][key]"
               class="form-control"
               value="${keyName}"
               placeholder="p.sh. Ekrani">

        <input type="text"
               name="specs[${si}][value]"
               class="form-control"
               placeholder="p.sh. 6.7&quot; OLED">

        <button type="button" onclick="removeSpec(this)" class="rm-btn">
            <i class="fa-solid fa-xmark"></i>
        </button>
    `;

    document.getElementById('specsList').appendChild(row);

    setTimeout(() => {
        const inputs = row.querySelectorAll('input');
        (keyName ? inputs[1] : inputs[0])?.focus();
    }, 50);
}

function removeSpec(button) {
    button.closest('.spec-row')?.remove();

    if (!document.querySelectorAll('#specsList .spec-row').length) {
        const empty = document.getElementById('specsEmpty');
        if (empty) empty.style.display = 'block';
    }
}

// ════════════ FOTO EKZISTUESE TË PRODUKTIT ════════════
function deleteImage(imgId, productId) {
    if (!confirm('Fshi këtë foto?')) return;

    fetch(`/admin/products/${productId}/images/${imgId}`, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const el = document.getElementById(`imgWrap${imgId}`);
            if (!el) return;

            el.style.cssText += ';opacity:0;transform:scale(0.8);transition:all .3s;';

            setTimeout(() => {
                el.remove();

                const remaining = document.querySelectorAll('[id^="imgWrap"]').length;
                const sE = document.getElementById('statExisting');
                if (sE) sE.textContent = remaining;

                updateStats();
            }, 300);
        }
    });
}

function setPrimary(imgId, productId) {
    fetch(`/admin/products/${productId}/images/${imgId}/primary`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.querySelectorAll('.existing-primary-badge').forEach(b => b.remove());
            document.querySelectorAll('.existing-img-card').forEach(c => c.classList.remove('is-primary'));

            const wrap = document.getElementById(`imgWrap${imgId}`);
            if (wrap) {
                wrap.classList.add('is-primary');

                const badge = document.createElement('span');
                badge.className = 'existing-primary-badge';
                badge.innerHTML = '<i class="fa-solid fa-star" style="font-size:8px;"></i> KRYESORE';
                wrap.appendChild(badge);

                const starBtn = wrap.querySelector('.img-action-primary');
                if (starBtn) starBtn.remove();
            }
        }
    });
}

// ════════════ CATEGORY -> BRAND ════════════
document.addEventListener('DOMContentLoaded', function () {
    const categorySelect = document.getElementById('categorySelect');
    const brandSelect = document.getElementById('brandSelect');

    if (!categorySelect || !brandSelect) return;

    categorySelect.addEventListener('change', function () {
        const categoryId = this.value;
        const currentBrandId = {{ isset($product) && $product->brand_id ? $product->brand_id : 'null' }};

        brandSelect.innerHTML = '<option value="">— Zgjedh brendin —</option>';

        if (!categoryId) return;

        fetch('/admin/get-brands-by-category/' + categoryId)
            .then(r => r.json())
            .then(data => {
                data.forEach(brand => {
                    const opt = document.createElement('option');
                    opt.value = brand.id;
                    opt.textContent = brand.name;

                    if (brand.id === currentBrandId) {
                        opt.selected = true;
                    }

                    brandSelect.appendChild(opt);
                });
            });
    });
function syncBasePrice(vi) {
    const base = parseFloat(document.getElementById(`basePrice_${vi}`)?.value || 0);
    // Përditëso të gjitha storage-t e tjera me çmimin bazë
    document.querySelectorAll(`#storageRows_${vi} .storage-row`).forEach((row, idx) => {
        if (idx === 0) return; // skip i pari
        const nameAttr = row.querySelector('[name*="extra_price"]')?.getAttribute('name');
        if (!nameAttr) return;
        const match = nameAttr.match(/storages\]\[(\d+)\]/);
        if (!match) return;
        const si = match[1];

        // Përditëso hidden input
        const hidden = document.getElementById(`basePriceHidden_${vi}_${si}`);
        if (hidden) hidden.value = base;

        // Shfaq vlerën
        const display = document.getElementById(`baseDisplay_${vi}_${si}`);
        if (display) display.textContent = base > 0 ? base.toFixed(2) + ' €' : '—';

        // Rillogarit totalin
        calcTotal(vi, parseInt(si));
    });
}

function calcTotal(vi, si) {
    const base  = parseFloat(document.getElementById(`basePrice_${vi}`)?.value || 0);
    const row   = document.getElementById(`storageRow_${vi}_${si}`);
    if (!row) return;
    const extraInput = row.querySelector('[name*="extra_price"]');
    const extra = parseFloat(extraInput?.value || 0);
    const total = base + extra;
    const el = document.getElementById(`total_${vi}_${si}`);
    if (el) el.textContent = total > 0 ? `${total.toFixed(2)} €` : '—';
}

function refreshAllTotals(vi) {
    document.querySelectorAll(`#storageRows_${vi} .storage-row`).forEach(row => {
        const extraInput = row.querySelector('[name*="extra_price"]');
        if (!extraInput) return;
        const nameAttr = extraInput.getAttribute('name');
        const match = nameAttr.match(/storages\]\[(\d+)\]/);
        if (match) calcTotal(extraInput, vi, match[1]);
    });
}

    @if(isset($product) && $product->category_id)
        if (categorySelect.value) {
            categorySelect.dispatchEvent(new Event('change'));
        }
    @endif
});

</script>
@endpush
