<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
     protected $fillable = [
        'category_id',
        'brand_id',
        'name',
        'slug',
        'description',
        'price',
        'sale_price',
        'stock',
        'sku',
        'is_active',
        'is_featured'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

public function images()
{
    return $this->hasMany(ProductImage::class)->orderBy('sort_order');
}

public function primaryImage()
{
    return $this->hasOne(ProductImage::class)->where('is_primary', true);
}

 
public function variants()
{
    return $this->hasMany(\App\Models\ProductVariant::class)
                ->orderBy('sort_order');
}
// ProductSpec relacioni (nëse nuk e ke):
public function specs()
{
    return $this->hasMany(\App\Models\ProductSpec::class);
}
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }
    public function stockLogs()
{
    return $this->hasMany(\App\Models\ProductStockLog::class)
                ->orderByDesc('created_at');
}
public function variantImages()
{
    return $this->hasMany(ProductVariantImage::class)->orderBy('sort_order');
}

}
