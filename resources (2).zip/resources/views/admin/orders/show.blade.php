@extends('layouts.admin')

@section('title', 'Porosia #' . str_pad($order->id, 5, '0', STR_PAD_LEFT))
@section('page-title', 'Detajet e Porosisë')

@section('breadcrumb')
    <a href="{{ url('/admin') }}">Dashboard</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <a href="{{ url('/admin/orders') }}">Porositë</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <span>#{{ str_pad($order->id, 5, '0', STR_PAD_LEFT) }}</span>
@endsection

@section('content')

@php
    $statusMap = [
        'pending'          => ['label' => 'Në Pritje',      'color' => 'var(--warning)', 'bg' => 'rgba(245,158,11,0.12)'],
        'awaiting_payment' => ['label' => 'Pret Pagesën',   'color' => '#0059b5',        'bg' => 'rgba(0,89,181,0.12)'],
        'confirmed'        => ['label' => 'Konfirmuar',     'color' => '#06b6d4',         'bg' => 'rgba(6,182,212,0.12)'],
        'shipped'          => ['label' => 'Dërguar',        'color' => 'var(--accent2)',  'bg' => 'rgba(167,139,250,0.12)'],
        'delivered'        => ['label' => 'Dorëzuar',       'color' => 'var(--success)',  'bg' => 'rgba(16,185,129,0.12)'],
        'cancelled'        => ['label' => 'Anuluar',        'color' => 'var(--danger)',   'bg' => 'rgba(248,113,113,0.12)'],
        'payment_failed'   => ['label' => 'Pagesa Dështoi', 'color' => 'var(--danger)',   'bg' => 'rgba(248,113,113,0.12)'],
    ];
    $st = $statusMap[$order->status] ?? ['label' => ucfirst($order->status ?? '—'), 'color' => 'var(--text-muted)', 'bg' => 'var(--surface2)'];
@endphp

<div style="display:grid;grid-template-columns:1fr 340px;gap:24px;align-items:start;">

    {{-- LEFT --}}
    <div style="display:flex;flex-direction:column;gap:20px;">

        {{-- HEADER CARD --}}
        <div class="card">
            <div class="card-body" style="flex-direction:row;align-items:center;justify-content:space-between;gap:16px;">
                <div style="display:flex;align-items:center;gap:16px;">
                    <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:18px;color:white;flex-shrink:0;">
                        <i class="fa-solid fa-bag-shopping"></i>
                    </div>
                    <div>
                        <div style="font-size:20px;font-weight:800;color:#fff;">
                            #{{ str_pad($order->id, 5, '0', STR_PAD_LEFT) }}
                        </div>
                        <div style="font-size:12px;color:var(--text-muted);margin-top:2px;">
                            {{ $order->created_at?->format('d M Y, H:i') ?? '—' }}
                        </div>
                    </div>
                </div>
                <span style="display:inline-flex;align-items:center;padding:6px 14px;border-radius:100px;font-size:12px;font-weight:700;color:{{ $st['color'] }};background:{{ $st['bg'] }};">
                    {{ $st['label'] }}
                </span>
            </div>
        </div>

        {{-- PRODUKTET --}}
        <div class="card">
            <div class="card-header"><span class="card-title">Produktet e Porositura</span></div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Produkti</th>
                            <th>Çmimi</th>
                            <th>Sasia</th>
                            <th style="text-align:right;">Nëntotali</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($order->items as $item)
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:12px;">
                                    @php
                                        $img = optional($item->product)->images?->firstWhere('is_primary', true)
                                            ?? optional($item->product)->images?->first();
                                    @endphp
                                    @if($img)
                                        <img src="{{ asset('storage/'.$img->image_path) }}"
                                             style="width:44px;height:44px;border-radius:8px;object-fit:cover;border:1px solid var(--border);">
                                    @else
                                        <div style="width:44px;height:44px;border-radius:8px;background:var(--surface2);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--text-muted);font-size:16px;">
                                            <i class="fa-solid fa-box"></i>
                                        </div>
                                    @endif
                                    <div>
                                        <div style="font-weight:600;font-size:13px;">
                                            {{ optional($item->product)->name ?? 'Produkt i fshirë' }}
                                        </div>
                                        @if(optional($item->product)->sku)
                                        <div style="font-size:11px;color:var(--text-muted);">SKU: {{ $item->product->sku }}</div>
                                        @endif
                                    </div>
                                </div>
                            </td>
                            <td style="font-size:13px;color:var(--text-soft);">
                                {{ number_format($item->unit_price ?? 0, 2) }} €
                            </td>
                            <td>
                                <span style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;background:var(--surface2);border:1px solid var(--border);border-radius:6px;font-size:13px;font-weight:700;">
                                    {{ $item->quantity }}
                                </span>
                            </td>
                            <td style="text-align:right;">
                                <span style="font-size:15px;font-weight:800;color:var(--accent);">
                                    {{ number_format($item->subtotal ?? (($item->unit_price ?? 0) * $item->quantity), 2) }} €
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align:right;padding:14px 16px;font-weight:700;font-size:13px;color:var(--text-soft);">
                                Totali i Porosisë:
                            </td>
                            <td style="text-align:right;padding:14px 16px;">
                                <span style="font-size:20px;font-weight:800;color:var(--accent);">
                                    {{ number_format($order->total_amount ?? 0, 2) }} €
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        {{-- SHËNIME --}}
        @if($order->notes)
        <div class="card">
            <div class="card-header"><span class="card-title">Shënime</span></div>
            <div class="card-body">
                <p style="font-size:14px;color:var(--text-soft);line-height:1.7;margin:0;">{{ $order->notes }}</p>
            </div>
        </div>
        @endif

    </div>

    {{-- RIGHT --}}
    <div style="display:flex;flex-direction:column;gap:20px;">

    {{-- NDRYSHO STATUSIN --}}
<div class="card">
    <div class="card-header"><span class="card-title">Ndrysho Statusin</span></div>
    <div class="card-body">
        @if(in_array($order->status, ['cancelled', 'payment_failed']))
            <div style="background:var(--error-bg);border:1px solid #ffb4ab;border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-ban" style="color:var(--danger);"></i>
                <span style="font-size:13px;color:var(--danger);font-weight:600;">
                    Kjo porosi është anuluar dhe nuk mund të ndryshohet më.
                </span>
            </div>
        @else
            <form action="{{ url('/admin/orders/'.$order->id) }}" method="POST">
                @csrf @method('PUT')
                <div class="form-group">
                    <label class="form-label">Statusi aktual</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        @foreach([
                            'pending'          => 'Në Pritje',
                            'awaiting_payment' => 'Pret Pagesën',
                            'confirmed'        => 'Konfirmuar',
                            'shipped'          => 'Dërguar',
                            'delivered'        => 'Dorëzuar',
                            'cancelled'        => 'Anuluar',
                        ] as $val => $lbl)
                            <option value="{{ $val }}" {{ $order->status === $val ? 'selected' : '' }}>
                                {{ $lbl }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </form>
        @endif
    </div>
</div>

        {{-- INFO KLIENTIT --}}
        <div class="card">
            <div class="card-header"><span class="card-title">Informacioni i Klientit</span></div>
            <div class="card-body" style="gap:12px;">
                <div style="display:flex;align-items:center;gap:12px;padding-bottom:12px;border-bottom:1px solid var(--border);">
                    <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;color:white;flex-shrink:0;">
                        {{ strtoupper(substr($order->customer_name ?? 'K', 0, 1)) }}
                    </div>
                    <div>
                        <div style="font-weight:700;font-size:14px;">{{ $order->customer_name ?? '—' }}</div>
                        <div style="font-size:11px;color:var(--text-muted);">Klient</div>
                    </div>
                </div>
                @if($order->customer_email)
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fa-solid fa-envelope" style="color:var(--text-muted);width:16px;font-size:12px;"></i>
                    <span style="font-size:13px;">{{ $order->customer_email }}</span>
                </div>
                @endif
                @if($order->customer_phone)
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fa-solid fa-phone" style="color:var(--text-muted);width:16px;font-size:12px;"></i>
                    <span style="font-size:13px;">{{ $order->customer_phone }}</span>
                </div>
                @endif
                @if($order->shipping_address)
                <div style="display:flex;align-items:flex-start;gap:10px;">
                    <i class="fa-solid fa-location-dot" style="color:var(--text-muted);width:16px;font-size:12px;margin-top:3px;"></i>
                    <span style="font-size:13px;line-height:1.5;">{{ $order->shipping_address }}</span>
                </div>
                @endif

                {{-- Metoda e pagesës --}}
                @if($order->payment_method)
                <div style="display:flex;align-items:center;gap:10px;margin-top:4px;padding-top:12px;border-top:1px solid var(--border);">
                    <i class="fa-solid fa-credit-card" style="color:var(--text-muted);width:16px;font-size:12px;"></i>
                    <span style="font-size:13px;">
                        {{ $order->payment_method === 'bank' ? 'Kartë krediti (Stripe)' : 'Cash në dorëzim' }}
                    </span>
                </div>
                @endif

                {{-- Stripe payment info --}}
                @if($order->payment_intent_id)
                <div style="background:rgba(0,89,181,0.06);border-radius:8px;padding:10px 12px;margin-top:4px;">
                    <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">Stripe Payment ID</div>
                    <div style="font-size:11px;font-family:monospace;color:#0059b5;word-break:break-all;">
                        {{ $order->payment_intent_id }}
                    </div>
                </div>
                @endif
            </div>
        </div>

        {{-- VEPRIMET --}}
    {{-- ZËVENDËSO seksionin VEPRIMET në orders/show.blade.php --}}

{{-- VEPRIMET --}}
<div style="display:flex;flex-direction:column;gap:10px;">

    {{-- REFUND I PJESSHËM — vetëm nëse ka Stripe payment --}}
    @if($order->payment_intent_id && !in_array($order->status, ['cancelled', 'payment_failed']))
    <div class="card">
        <div class="card-header">
            <span class="card-title">
                <i class="fa-solid fa-rotate-left" style="color:var(--warning);"></i>
                Kthe Pagesën (Refund)
            </span>
        </div>
        <div class="card-body" style="gap:12px;">

            <p style="font-size:12px;color:var(--text-muted);margin:0;">
                Zgjedh sasinë për çdo produkt që dëshiron ta kthesh. Lëre 0 për produktet që nuk i kthen.
            </p>

            <form action="{{ route('payment.refund', $order->id) }}" method="POST"
                  onsubmit="return confirmRefund()">
                @csrf

                <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px;">
                    @foreach($order->items as $item)
                    <div style="background:var(--surface2);border-radius:10px;padding:10px 12px;">
                        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;">
                            <span style="font-size:13px;font-weight:600;color:var(--text);">
                                {{ optional($item->product)->name ?? 'Produkt' }}
                            </span>
                            <span style="font-size:12px;color:var(--text-muted);">
                                {{ number_format($item->unit_price, 2) }} € / copë
                            </span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <label style="font-size:11px;color:var(--text-muted);white-space:nowrap;">
                                Kthe (max {{ $item->quantity }}):
                            </label>
                            <input type="number"
                                   name="items[{{ $item->id }}][quantity]"
                                   min="0"
                                   max="{{ $item->quantity }}"
                                   value="0"
                                   class="form-control"
                                   style="width:70px;padding:6px 10px;font-size:13px;"
                                   oninput="updateRefundTotal()">
                            <input type="hidden" name="items[{{ $item->id }}][unit_price]" value="{{ $item->unit_price }}">
                            <input type="hidden" name="items[{{ $item->id }}][max]" value="{{ $item->quantity }}">
                            <span style="font-size:12px;color:var(--text-muted);">
                                nga {{ $item->quantity }} cope
                            </span>
                        </div>
                    </div>
                    @endforeach
                </div>

                {{-- Total refund preview --}}
                <div style="background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.3);border-radius:10px;padding:10px 14px;margin-bottom:12px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <span style="font-size:13px;font-weight:600;color:var(--warning);">Shuma për kthim:</span>
                        <span style="font-size:16px;font-weight:800;color:var(--warning);" id="refundTotal">0.00 €</span>
                    </div>
                </div>

                <button type="submit" class="btn btn-warning btn-full">
                    <i class="fa-solid fa-rotate-left"></i> Kthe Pagesën
                </button>
            </form>

            {{-- Kthe të gjitha --}}
            <form action="{{ route('payment.refund', $order->id) }}" method="POST"
                  onsubmit="return confirm('A jeni i sigurt? Do të kthehet e gjithë pagesa prej {{ number_format($order->total_amount, 2) }} €!')">
                @csrf
                <input type="hidden" name="refund_all" value="1">
                <button type="submit" class="btn btn-danger btn-full">
                    <i class="fa-solid fa-ban"></i> Kthe Gjithçka ({{ number_format($order->total_amount, 2) }} €)
                </button>
            </form>
        </div>
    </div>
    @endif

    <a href="{{ url('/admin/orders') }}" class="btn btn-secondary" style="width:100%;justify-content:center;">
        <i class="fa-solid fa-arrow-left"></i> Kthehu te Porositë
    </a>

    <form action="{{ url('/admin/orders/'.$order->id) }}" method="POST"
          onsubmit="return confirm('Fshi porosinë?')">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger" style="width:100%;justify-content:center;">
            <i class="fa-solid fa-trash"></i> Fshi Porosinë
        </button>
    </form>

</div>

@push('scripts')
@endpush

    </div>
</div>

@endsection
