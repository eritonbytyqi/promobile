<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porosia u anulua</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Helvetica Neue', Arial, sans-serif; background: #f5f5f7; color: #1d1d1f; }
        .wrapper { max-width: 600px; margin: 40px auto; background: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .header { background: #1d1d1f; padding: 32px 40px; text-align: center; }
        .header .logo { font-size: 24px; font-weight: 800; color: white; letter-spacing: -0.5px; }
        .header .logo span { color: #0071e3; }
        .hero { background: linear-gradient(135deg, #ba1a1a, #dc2626); padding: 40px; text-align: center; }
        .hero-icon { width: 64px; height: 64px; background: rgba(255,255,255,0.15); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px; font-size: 28px; }
        .hero h1 { font-size: 26px; font-weight: 800; color: white; margin-bottom: 8px; }
        .hero p { font-size: 15px; color: rgba(255,255,255,0.85); line-height: 1.6; }
        .body { padding: 40px; }
        .greeting { font-size: 16px; color: #1d1d1f; margin-bottom: 20px; line-height: 1.6; }
        .order-box { background: #f5f5f7; border-radius: 14px; padding: 24px; margin-bottom: 24px; }
        .order-box-title { font-size: 11px; font-weight: 700; color: #6e6e73; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 16px; }
        .order-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e8e8ed; font-size: 14px; }
        .order-row:last-child { border-bottom: none; }
        .order-row .label { color: #6e6e73; }
        .order-row .value { font-weight: 600; color: #1d1d1f; }
        .refund-box { background: #d6f5e3; border-radius: 12px; padding: 20px 24px; margin-bottom: 24px; }
        .refund-box-title { font-size: 13px; font-weight: 700; color: #1a7a4a; margin-bottom: 8px; }
        .refund-box p { font-size: 14px; color: #1a7a4a; line-height: 1.6; }
        .refund-amount { font-size: 24px; font-weight: 800; color: #1a7a4a; margin: 8px 0; }
        .cta { text-align: center; margin: 32px 0; }
        .cta a { display: inline-block; padding: 14px 32px; background: #1d1d1f; color: white; text-decoration: none; border-radius: 999px; font-size: 14px; font-weight: 700; }
        .footer { background: #f5f5f7; padding: 28px 40px; text-align: center; border-top: 1px solid #e8e8ed; }
        .footer p { font-size: 12px; color: #6e6e73; line-height: 1.8; }
        .footer .brand { font-size: 14px; font-weight: 700; color: #1d1d1f; margin-bottom: 8px; }
    </style>
</head>
<body>
<div class="wrapper">

    <!-- Header -->
    <div class="header">
        <div class="logo">Pro<span>Mobile</span></div>
    </div>

    <!-- Hero -->
    <div class="hero">
        <div class="hero-icon">✕</div>
        <h1>Porosia u anulua</h1>
        <p>Porosia juaj është anuluar. Nëse keni paguar, paratë do t'ju kthehen automatikisht.</p>
    </div>

    <!-- Body -->
    <div class="body">
        <p class="greeting">
            Përshëndetje <strong>{{ $order->customer_name }}</strong>,<br><br>
            Na vjen keq të njoftojmë se porosia juaj <strong>#{{ $order->order_number }}</strong> është anuluar.
        </p>

        <!-- Order details -->
        <div class="order-box">
            <div class="order-box-title">Detajet e porosisë</div>
            <div class="order-row">
                <span class="label">Numri i porosisë</span>
                <span class="value">#{{ $order->order_number }}</span>
            </div>
            <div class="order-row">
                <span class="label">Data e porosisë</span>
                <span class="value">{{ $order->created_at->format('d M Y, H:i') }}</span>
            </div>
            <div class="order-row">
                <span class="label">Totali</span>
                <span class="value">{{ number_format($order->total_amount, 2) }} €</span>
            </div>
        </div>

        <!-- Refund info -->
        @if($order->payment_method === 'bank' && $order->payment_intent_id)
        <div class="refund-box">
            <div class="refund-box-title">✓ Kthimi i pagesës</div>
            <div class="refund-amount">{{ number_format($order->total_amount, 2) }} €</div>
            <p>
                Pagesa juaj do të kthehet automatikisht te karta juaj brenda <strong>5-10 ditëve pune</strong>,
                varësisht nga banka juaj.
            </p>
        </div>
        @endif

        <div class="cta">
            <a href="{{ url('/shop') }}">Vazhdo blerjen</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <div class="brand">ProMobile</div>
        <p>
            Nëse keni pyetje rreth anulimit, na kontaktoni: info@promobile.com<br>
            © {{ date('Y') }} ProMobile. Të gjitha të drejtat e rezervuara.
        </p>
    </div>

</div>
</body>
</html>