<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'ProMobile')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<meta name="stripe-key" content="{{ config('services.stripe.key') }}">

    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }

        :root {
            --bg:               #f9f9fb;
            --surface:          #ffffff;
            --surface-low:      #f3f3f5;
            --surface-high:     #e8e8ea;
            --surface-highest:  #e2e2e4;
            --border:           rgba(0,0,0,0.08);
            --border-solid:     #e2e2e4;
            --text:             #1a1c1d;
            --text-soft:        #414753;
            --text-muted:       #717785;
            --primary:          #0059b5;
            --primary-cont:     #0071e3;
            --primary-fixed:    #d7e2ff;
            --primary-dim:      #abc7ff;
            --secondary:        #5f5e60;
            --error:            #ba1a1a;
            --error-bg:         #ffdad6;
            --success:          #1a7a4a;
            --success-bg:       #d6f5e3;
            --radius-full:      9999px;
            --radius-xl:        1.5rem;
            --radius-2xl:       2rem;
            --radius-3xl:       2.5rem;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
        }

        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }

        /* ── NAVBAR ── */
        .navbar {
            position: fixed;
            top: 0; left: 0; right: 0;
            z-index: 300;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            background: rgba(249,249,251,0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-solid);
        }

        .navbar-inner {
            width: 100%;
            max-width: 1300px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
        }

        .nav-logo {
            font-size: 20px;
            font-weight: 800;
            color: var(--text);
            text-decoration: none;
            letter-spacing: -0.5px;
            flex-shrink: 0;
        }
        .nav-logo span { color: var(--primary); }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 2px;
            list-style: none;
        }

        .nav-links a {
            display: block;
            padding: 7px 14px;
            color: var(--text-soft);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: var(--radius-full);
            transition: all 0.2s;
        }

        .nav-links a:hover { color: var(--text); background: var(--surface-low); }
        .nav-links a.active {
            color: var(--primary);
            background: var(--primary-fixed);
            font-weight: 600;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-search { position: relative; }

        .nav-search input {
            width: 200px;
            padding: 9px 14px 9px 38px;
            background: var(--surface-low);
            border: 1px solid var(--border-solid);
            border-radius: var(--radius-full);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            font-size: 13px;
            outline: none;
            transition: all 0.2s;
        }

        .nav-search input:focus {
            width: 240px;
            border-color: var(--primary);
            background: var(--surface);
            box-shadow: 0 0 0 3px rgba(0,89,181,0.1);
        }

        .nav-search input::placeholder { color: var(--text-muted); }

        .nav-search .search-icon {
            position: absolute;
            left: 13px; top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 16px;
            pointer-events: none;
        }

        /* ── CART BUTTON ── */
        .cart-btn {
            position: relative;
            width: 40px; height: 40px;
            border-radius: var(--radius-full);
            background: var(--surface);
            border: 1px solid var(--border-solid);
            display: flex; align-items: center; justify-content: center;
            color: var(--text-soft);
            text-decoration: none;
            transition: all 0.2s;
            cursor: pointer;
        }

        .cart-btn:hover {
            background: var(--surface-low);
            border-color: var(--primary);
            color: var(--primary);
        }

        .cart-count {
            position: absolute;
            top: -5px; right: -5px;
            min-width: 18px; height: 18px;
            padding: 0 4px;
            background: var(--primary-cont);
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            display: flex; align-items: center; justify-content: center;
            color: white;
            border: 2px solid var(--bg);
        }

        /* ── MAIN ── */
        .main-wrap {
            padding-top: 64px;
            min-height: 100vh;
        }

        /* ── FLASH ── */
        .flash {
            position: fixed;
            top: 80px; right: 24px;
            z-index: 500;
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease, fadeOut 0.4s ease 3s forwards;
            max-width: 360px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }

        .flash-success {
            background: var(--success-bg);
            border: 1px solid #a3e0be;
            color: var(--success);
        }

        .flash-error {
            background: var(--error-bg);
            border: 1px solid #ffb4ab;
            color: var(--error);
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(30px); }
            to   { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeOut {
            to { opacity: 0; transform: translateX(30px); }
        }

        /* ── BUTTONS ── */
        .btn {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 11px 22px;
            border-radius: var(--radius-full);
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            border: none;
            text-decoration: none;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .btn-primary { background: var(--text); color: var(--surface); }
        .btn-primary:hover { opacity: 0.85; transform: translateY(-1px); }

        .btn-outline {
            background: transparent;
            color: var(--text);
            border: 1px solid var(--border-solid);
        }
        .btn-outline:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-fixed); }

        .btn-danger { background: var(--error-bg); color: var(--error); border: 1px solid #ffb4ab; }
        .btn-danger:hover { opacity: 0.85; }
        .btn-sm { padding: 7px 14px; font-size: 12px; }

        /* ── PRODUCT GRID ── */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 24px;
        }

        .product-card {
            background: var(--surface-low);
            border-radius: var(--radius-3xl);
            padding: 16px;
            transition: background 0.3s;
            cursor: pointer;
        }
        .product-card:hover { background: var(--surface-high); }

        .product-card-img {
            aspect-ratio: 4/5;
            overflow: hidden;
            border-radius: var(--radius-2xl);
            background: var(--surface);
            margin-bottom: 16px;
            position: relative;
        }
        .product-card-img img {
            width: 100%; height: 100%;
            object-fit: cover;
            transition: transform 0.6s;
        }
        .product-card:hover .product-card-img img { transform: scale(1.07); }

        .product-card-body { padding: 0 4px 4px; }

        .product-card-meta {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 12px;
        }

        .product-card-name { font-size: 15px; font-weight: 700; color: var(--text); letter-spacing: -0.2px; }
        .product-card-sub  { font-size: 13px; color: var(--text-muted); margin-top: 2px; }
        .product-card-price { font-size: 15px; font-weight: 700; color: var(--text); white-space: nowrap; }

        .btn-add-cart {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 12px;
            background: var(--text);
            color: var(--surface);
            border-radius: var(--radius-full);
            font-size: 13.5px;
            font-weight: 700;
            border: none;
            cursor: pointer;
            text-decoration: none;
            transition: opacity 0.2s, transform 0.2s;
        }
        .btn-add-cart:hover { opacity: 0.85; transform: translateY(-1px); }

        /* ── BADGE ── */
        .badge {
            display: inline-flex; align-items: center; gap: 4px;
            padding: 4px 12px;
            border-radius: var(--radius-full);
            font-size: 11px; font-weight: 700; letter-spacing: 0.3px;
        }
        .badge-blue  { background: var(--primary-fixed); color: var(--primary); }
        .badge-green { background: var(--success-bg);    color: var(--success); }
        .badge-red   { background: var(--error-bg);      color: var(--error); }

        /* ── SECTION HELPERS ── */
        .section { padding: 48px 24px; max-width: 1300px; margin: 0 auto; }
        .section-header {
            display: flex; align-items: flex-end;
            justify-content: space-between; gap: 16px;
            margin-bottom: 32px;
        }
        .section-title { font-size: 28px; font-weight: 800; letter-spacing: -0.5px; color: var(--text); }
        .section-sub   { font-size: 14px; color: var(--text-muted); margin-top: 4px; }
        .section-link  {
            font-size: 14px; font-weight: 600;
            color: var(--primary); text-decoration: none; white-space: nowrap;
        }
        .section-link:hover { opacity: 0.75; }

        /* ── SCROLLBAR ── */
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--border-solid); border-radius: 4px; }

        /* ── FOOTER ── */
        footer {
            margin-top: 80px;
            background: var(--surface);
            border-top: 1px solid var(--border-solid);
            padding: 52px 5%;
        }

    .footer-inner {
    max-width: 1300px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1.6fr 1fr 1fr 1fr;
    gap: 40px;
}
        .footer-brand .logo { font-size: 20px; font-weight: 800; color: var(--text); letter-spacing: -0.5px; margin-bottom: 12px; }
        .footer-brand .logo span { color: var(--primary); }
        .footer-brand p { font-size: 13px; color: var(--text-muted); line-height: 1.75; max-width: 280px; }

        .footer-col h4 { font-size: 12px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: var(--text-soft); margin-bottom: 18px; }
        .footer-col ul { list-style: none; }
        .footer-col ul li { margin-bottom: 12px; }
        .footer-col ul li a { color: var(--text-muted); text-decoration: none; font-size: 14px; transition: color 0.2s; }
        .footer-col ul li a:hover { color: var(--primary); }

        .footer-bottom {
            max-width: 1300px;
            margin: 32px auto 0;
            padding-top: 24px;
            border-top: 1px solid var(--border-solid);
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            color: var(--text-muted);
        }
@media (max-width: 768px) {
    .nav-links { display: none; }
    .nav-search input { width: 130px; }
    .nav-search input:focus { width: 160px; }
    .main-wrap { padding-bottom: 70px; }
    footer { margin-bottom: 70px; }
    .footer-inner { grid-template-columns: 1fr; gap: 28px; }
    .product-grid { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
    .section { padding: 32px 16px; }
}

        /* ── CART SIDEBAR ── */
        .cs-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.4);
            z-index: 900;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.35s ease;
            backdrop-filter: blur(4px);
        }
        .cs-overlay.open { opacity: 1; pointer-events: all; }

        .cs-sidebar {
            position: fixed;
            top: 0; right: 0; bottom: 0;
            width: 420px;
            max-width: 100vw;
            background: #fff;
            z-index: 901;
            display: flex;
            flex-direction: column;
            transform: translateX(100%);
            transition: transform 0.38s cubic-bezier(.4,0,.2,1);
            box-shadow: -8px 0 40px rgba(0,0,0,0.12);
        }
        .cs-sidebar.open { transform: translateX(0); }

        .cs-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            border-bottom: 1px solid #f0f0f0;
            flex-shrink: 0;
        }
        .cs-title {
            display: flex; align-items: center; gap: 10px;
            font-size: 17px; font-weight: 800; color: #1d1d1f; letter-spacing: -0.3px;
        }
        .cs-title i { color: #0071e3; font-size: 16px; }
        .cs-count-badge {
            background: #0071e3; color: white;
            font-size: 10px; font-weight: 700;
            width: 20px; height: 20px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }
        .cs-close {
            width: 34px; height: 34px; border-radius: 50%;
            border: 1px solid #e8e8e8; background: #f5f5f7;
            color: #6e6e73; font-size: 14px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.2s;
        }
        .cs-close:hover { background: #1d1d1f; color: white; border-color: #1d1d1f; }

        .cs-body {
            flex: 1; overflow-y: auto; padding: 8px 0; scrollbar-width: thin;
        }
        .cs-body::-webkit-scrollbar { width: 4px; }
        .cs-body::-webkit-scrollbar-thumb { background: #e2e2e4; border-radius: 4px; }

        .cs-items { padding: 8px 0; }

        .cs-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 24px; transition: background 0.2s;
        }
        .cs-item:hover { background: #fafafa; }

        .cs-item-img {
            width: 72px; height: 72px; border-radius: 14px;
            overflow: hidden; background: #f5f5f7; flex-shrink: 0;
        }
        .cs-item-img img { width: 100%; height: 100%; object-fit: cover; }
        .cs-item-img-ph {
            width: 100%; height: 100%;
            display: flex; align-items: center; justify-content: center;
            color: #ccc; font-size: 24px;
        }

        .cs-item-info { flex: 1; min-width: 0; }
        .cs-item-name {
            font-size: 13px; font-weight: 700; color: #1d1d1f;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 4px;
        }
        .cs-item-price { font-size: 14px; font-weight: 800; color: #1d1d1f; margin-bottom: 10px; }
        .cs-item-qty {
            display: flex; align-items: center;
            background: #f5f5f7; border-radius: 999px;
            width: fit-content; padding: 3px;
        }
        .cs-qty-btn {
            width: 26px; height: 26px; border-radius: 50%;
            border: none; background: transparent; color: #1d1d1f;
            font-size: 10px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: background 0.15s;
        }
        .cs-qty-btn:hover { background: #e8e8e8; }
        .cs-qty-num {
            font-size: 13px; font-weight: 700; color: #1d1d1f;
            min-width: 22px; text-align: center;
        }
        .cs-item-remove {
            width: 32px; height: 32px; border-radius: 50%;
            border: none; background: transparent; color: #aeaeb2;
            font-size: 12px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.2s; flex-shrink: 0;
        }
        .cs-item-remove:hover { background: #fff0f0; color: #ff3b30; }

        .cs-empty {
            display: flex; flex-direction: column; align-items: center;
            justify-content: center; padding: 60px 24px; text-align: center; height: 100%;
        }
        .cs-empty-icon {
            width: 72px; height: 72px; border-radius: 50%;
            background: #f5f5f7;
            display: flex; align-items: center; justify-content: center;
            font-size: 28px; color: #c7c7cc; margin-bottom: 20px;
        }
        .cs-empty-title { font-size: 16px; font-weight: 700; color: #1d1d1f; margin-bottom: 6px; }
        .cs-empty-sub   { font-size: 13px; color: #6e6e73; margin-bottom: 24px; line-height: 1.5; }
        .cs-empty-btn {
            padding: 11px 24px; background: #1d1d1f; color: white;
            border-radius: 999px; font-size: 13px; font-weight: 700;
            text-decoration: none; transition: opacity 0.2s;
        }
        .cs-empty-btn:hover { opacity: 0.8; }

        .cs-footer {
            padding: 20px 24px; border-top: 1px solid #f0f0f0;
            flex-shrink: 0; background: #fff;
        }
        .cs-subtotal {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 10px; font-size: 14px; color: #6e6e73;
        }
        .cs-subtotal-val { font-size: 20px; font-weight: 800; color: #1d1d1f; }
        .cs-shipping {
            display: flex; align-items: center; gap: 6px;
            font-size: 12px; color: #6e6e73; margin-bottom: 16px;
        }
        .cs-checkout-btn {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            width: 100%; padding: 15px; background: #1d1d1f; color: white;
            border-radius: 14px; font-size: 15px; font-weight: 700;
            text-decoration: none; transition: opacity 0.2s, transform 0.2s;
        }
        .cs-checkout-btn:hover { opacity: 0.85; transform: translateY(-1px); color: white; }

        @media (max-width: 480px) {
            .cs-sidebar { width: 100vw; border-radius: 20px 20px 0 0; top: auto; height: 90vh; }
        }

        .bp-bg {
            position: absolute; inset: 0;
            background-size: cover;
            background-position: right center;
            background-repeat: no-repeat;
        }
        .banner-preview-box { position: relative; overflow: hidden; }
        .banner-preview-box::after {
            content: ""; position: absolute; inset: 0;
            background: linear-gradient(90deg, rgba(10,10,26,0.85) 0%, rgba(10,10,26,0.65) 35%, rgba(10,10,26,0.25) 60%, rgba(10,10,26,0.05) 80%, transparent 100%);
        }

        /* ── WISHLIST ── */
        .pm-wish-btn {
            position: absolute;
            top: 10px; right: 10px;
            width: 32px; height: 32px;
            border-radius: 50%;
            background: rgba(255,255,255,0.18);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.30);
            display: flex; align-items: center; justify-content: center;
            font-size: 13px;
            color: white;
            cursor: pointer;
            transition: all 0.22s cubic-bezier(.4,0,.2,1);
            z-index: 3;
            text-shadow: 0 1px 3px rgba(0,0,0,0.35);
        }
        .pm-wish-btn:hover {
            background: rgba(255,255,255,0.30);
            border-color: rgba(255,255,255,0.50);
            transform: scale(1.10);
        }
        .pm-wish-btn.saved {
            background: #ff3b30;
            border-color: #ff3b30;
            color: white;
            text-shadow: none;
        }
        .pm-wish-btn.saved:hover {
            background: #e02d22;
            border-color: #e02d22;
            transform: scale(1.10);
        }
        @keyframes heartPop {
            0%   { transform: scale(1); }
            40%  { transform: scale(1.40); }
            70%  { transform: scale(0.88); }
            100% { transform: scale(1); }
        }
        .pm-wish-btn.pop { animation: heartPop 0.32s cubic-bezier(.4,0,.2,1) forwards; }

        .pm-wishlist-section {
            padding: 0 5%;
            margin-bottom: 48px;
        }

        .search-result-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    text-decoration: none;
    color: var(--text);
    font-size: 13px;
    transition: background 0.15s;
    cursor: pointer;
}
.search-result-item:hover { background: var(--surface-low); }
.search-result-item img {
    width: 36px; height: 36px;
    border-radius: 8px;
    object-fit: cover;
    background: var(--surface-low);
    flex-shrink: 0;
}
.search-result-name { font-weight: 600; flex: 1; }
.search-result-price { font-weight: 700; color: var(--primary); white-space: nowrap; }
.search-result-empty {
    padding: 16px;
    text-align: center;
    color: var(--text-muted);
    font-size: 13px;
}
/* ── BOTTOM NAV MOBILE ── */
.bottom-nav {
    display: none;
    position: fixed;
    bottom: 0; left: 0; right: 0;
    z-index: 400;
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-top: 1px solid var(--border-solid);
    padding: 8px 0 calc(8px + env(safe-area-inset-bottom));
}

.bottom-nav-inner {
    display: flex;
    align-items: center;
    justify-content: space-around;
}

.bottom-nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    color: var(--text-muted);
    font-size: 10px;
    font-weight: 500;
    padding: 4px 16px;
    border-radius: 12px;
    transition: color 0.2s;
    position: relative;
    background: none;
    border: none;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
}

.bottom-nav-item i {
    font-size: 20px;
    transition: transform 0.2s;
}

.bottom-nav-item.active {
    color: #00bcd4;
}

.bottom-nav-item:active i { transform: scale(0.88); }

.bottom-nav-badge {
    position: absolute;
    top: 2px; right: 10px;
    min-width: 16px; height: 16px;
    background: #ff3b30;
    color: white;
    font-size: 9px;
    font-weight: 700;
    border-radius: 999px;
    display: flex; align-items: center; justify-content: center;
    padding: 0 4px;
    border: 2px solid white;
}

@media (max-width: 768px) {
    .bottom-nav { display: block; }
    .main-wrap { padding-bottom: 70px; }
    footer { margin-bottom: 70px; }
}
@media (max-width: 600px) {
    .pm-cats-section { padding: 0 4%; margin-bottom: 48px; }

    .pm-cat-card {
        width: 110px;
        height: 110px;
        border-radius: 18px;
        gap: 8px;
    }

    .pm-cat-icon {
        width: 40px; height: 40px;
        border-radius: 10px;
        font-size: 18px;
    }

    .pm-cat-name { font-size: 12px; }

    .pm-section-title { font-size: 24px; }
}
    </style>

    @stack('styles')
</head>
<body>

@php $cartCount = count(session('cart', [])); @endphp
@include('client.partials.cart-sidebar')

<!-- NAVBAR -->
<nav class="navbar">
    <div class="navbar-inner">
        <a href="{{ url('/') }}" class="nav-logo">Pro<span>Mobile</span></a>

     <ul class="nav-links">
    <li>
        <a href="{{ url('/') }}" class="{{ request()->is('/') ? 'active' : '' }}">
            Kryefaqja
        </a>
    </li>

    <li>
        <a href="{{ url('/shop') }}" class="{{ request()->is('shop') && !request('featured') ? 'active' : '' }}">
            Produktet
        </a>
    </li>

    <li>
        <a href="{{ route('contact') }}" class="{{ request()->routeIs('contact') ? 'active' : '' }}">
            Kontakt
        </a>
    </li>

    <li>
        <a href="{{ url('/shop?featured=1') }}"
           class="{{ request()->is('shop') && request('featured') ? 'active' : '' }}"
           style="display:flex;align-items:center;gap:6px;">
            Favoritet
            <span id="navWishCount" style="display:none;background:#ff3b30;color:white;font-size:10px;font-weight:700;min-width:18px;height:18px;border-radius:999px;padding:0 5px;align-items:center;justify-content:center;">0</span>
        </a>
    </li>
</ul>

        <div class="nav-right">
         <form action="{{ url('/shop') }}" method="GET" class="nav-search" id="searchForm" autocomplete="off">
    @if(request('category'))
        <input type="hidden" name="category" value="{{ request('category') }}">
    @endif
    @if(request('featured'))
        <input type="hidden" name="featured" value="1">
    @endif
    <span class="material-symbols-outlined search-icon" style="font-size:18px;">search</span>
    <input type="text" name="search" id="searchInput"
           placeholder="Kërko..." value="{{ request('search') }}"
           autocomplete="off">
    <div id="searchDropdown" style="
        display:none;
        position:absolute;
        top:calc(100% + 6px);
        left:0; right:0;
        background:white;
        border:1px solid #e2e2e4;
        border-radius:14px;
        box-shadow:0 8px 32px rgba(0,0,0,0.12);
        z-index:999;
        overflow:hidden;
        max-height:320px;
        overflow-y:auto;
    "></div>
</form>
{{-- PROFILI / LOGIN --}}
@auth
<div style="position:relative;" id="profileDropdownWrap">
    <button onclick="toggleProfileMenu()" style="
        width:38px; height:38px; border-radius:50%;
        background:var(--primary-fixed); border:1.5px solid var(--primary-dim);
        color:var(--primary); font-size:14px; font-weight:800;
        cursor:pointer; display:flex; align-items:center; justify-content:center;
        font-family:'Inter',sans-serif; transition: all 0.2s;
    ">
        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
    </button>

    <div id="profileMenu" style="
        display:none; position:absolute; top:calc(100% + 10px); right:0;
        background:var(--surface); border:1px solid var(--border-solid);
        border-radius:16px; min-width:200px;
        box-shadow:0 8px 32px rgba(0,0,0,0.1); z-index:999; overflow:hidden;
    ">
        <div style="padding:14px 16px; border-bottom:1px solid var(--border-solid);">
            <div style="font-size:13px; font-weight:700; color:var(--text);">
                {{ auth()->user()->name }} {{ auth()->user()->surname }}
            </div>
            <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">
                {{ auth()->user()->email }}
            </div>
        </div>
        <a href="{{ route('profile.index') }}" style="
            display:flex; align-items:center; gap:10px;
            padding:12px 16px; text-decoration:none;
            color:var(--text-soft); font-size:13px; font-weight:500;
            transition:background 0.15s;
        " onmouseover="this.style.background='var(--surface-low)'"
           onmouseout="this.style.background='transparent'">
            <span class="material-symbols-outlined" style="font-size:17px;">person</span>
            Profili im
        </a>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" style="
                width:100%; display:flex; align-items:center; gap:10px;
                padding:12px 16px; background:transparent; border:none;
                color:var(--error); font-size:13px; font-weight:500;
                cursor:pointer; font-family:'Inter',sans-serif;
                border-top:1px solid var(--border-solid);
                transition:background 0.15s; text-align:left;
            " onmouseover="this.style.background='var(--error-bg)'"
               onmouseout="this.style.background='transparent'">
                <span class="material-symbols-outlined" style="font-size:17px;">logout</span>
                Dil
            </button>
        </form>
    </div>
</div>
@else
<a href="{{ route('login') }}" style="
    display:flex; align-items:center; gap:6px;
    padding:8px 16px; border-radius:var(--radius-full);
    background:var(--primary); color:white;
    font-size:13px; font-weight:700; text-decoration:none;
    transition:opacity 0.2s;
" onmouseover="this.style.opacity='0.85'"
   onmouseout="this.style.opacity='1'">
    <span class="material-symbols-outlined" style="font-size:16px;">login</span>
    Hyr
</a>
@endauth
            <button onclick="openCart()" class="cart-btn" title="Shporta">
                <span class="material-symbols-outlined" style="font-size:20px;">shopping_cart</span>
                <span class="cart-count" style="{{ $cartCount > 0 ? '' : 'display:none;' }}">
                    {{ $cartCount }}
                </span>
            </button>
        </div>
    </div>
</nav>

<!-- FLASH MESSAGES -->
@if(session('success'))
    <div class="flash flash-success">
        <span class="material-symbols-outlined" style="font-size:18px;">check_circle</span>
        {{ session('success') }}
    </div>
@endif
@if(session('error'))
    <div class="flash flash-error">
        <span class="material-symbols-outlined" style="font-size:18px;">error</span>
        {{ session('error') }}
    </div>
@endif

<!-- CONTENT -->
<div class="main-wrap">
    @yield('content')
</div>

<!-- FOOTER -->
<footer>
    <div class="footer-inner">
        <div class="footer-brand">
            <div class="logo">Pro<span>Mobile</span></div>
            <p>Dyqani juaj online me produktet më të mira. Cilësi e lartë, çmime të arsyeshme, dorëzim i shpejtë.</p>
        </div>

        <div class="footer-col">
            <h4>Navigim</h4>
            <ul>
                <li><a href="{{ url('/') }}">Kryefaqja</a></li>
                <li><a href="{{ url('/shop') }}">Produktet</a></li>
                <li><a href="{{ route('contact') }}">Kontakt</a></li>
                <li><a href="{{ url('/shop?featured=1') }}">Favoritet</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Informata</h4>
            <ul>
                <li><a href="{{ route('terms') }}">Kushtet e Përdorimit</a></li>
                <li><a href="{{ route('privacy') }}">Politika e Privatësisë</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Kontakt</h4>
            <ul>
                <li><a href="mailto:info@promobile.com">info@promobile.com</a></li>
                <li><a href="tel:+38344000000">+383 44 000 000</a></li>
                <li><span>Prishtinë, Kosovë</span></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <span>© {{ date('Y') }} ProMobile. Të gjitha të drejtat e rezervuara.</span>
    </div>
</footer>

<!-- CART + WISHLIST JS -->
<script>
/* ── CART ── */
function addToCart(productId, btn) {
    const icon = btn?.querySelector('i');
    if (icon) icon.className = 'fa-solid fa-spinner fa-spin';

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify({ product_id: productId, quantity: 1 })
    })
    .then(r => r.json())
    .then(data => {
        if (!data.success) return;
        refreshCartUI(data);
        if (icon) icon.className = 'fa-solid fa-check';
        if (btn) btn.style.background = '#34c759';
        openCartUIOnly();
        setTimeout(() => {
            if (icon) icon.className = 'fa-solid fa-plus';
            if (btn) btn.style.background = '';
        }, 1800);
    })
    .catch(err => {
        console.error('Add to cart error:', err);
        if (icon) icon.className = 'fa-solid fa-plus';
    });
}

function openCart() {
    fetch('/cart/sidebar', { headers: { 'Accept': 'application/json' } })
    .then(r => r.json())
    .then(data => { refreshCartUI(data); openCartUIOnly(); })
    .catch(err => console.error('Cart sidebar error:', err));
}

function openCartUIOnly() {
    document.getElementById('cartSidebar')?.classList.add('open');
    document.getElementById('cartOverlay')?.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeCart() {
    document.getElementById('cartSidebar')?.classList.remove('open');
    document.getElementById('cartOverlay')?.classList.remove('open');
    document.body.style.overflow = '';
}

function removeItem(cartKey) {
    fetch('/cart/remove', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify({ key: cartKey })
    })
    .then(r => r.json())
    .then(data => refreshCartUI(data))
    .catch(err => console.error('Remove item error:', err));
}

function updateQty(cartKey, quantity) {
    if (quantity < 1) { removeItem(cartKey); return; }
    fetch('/cart/update', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify({ key: cartKey, quantity: quantity })
    })
    .then(r => r.json())
    .then(data => refreshCartUI(data))
    .catch(err => console.error('Update qty error:', err));
}

function refreshCartUI(data) {
    document.querySelectorAll('.cart-count').forEach(el => {
        el.textContent = data.count;
        el.style.display = data.count > 0 ? 'flex' : 'none';
    });

    // Bottom nav cart badge
    const bottomCart = document.getElementById('bottomNavCartCount');
    if (bottomCart) {
        bottomCart.textContent   = data.count;
        bottomCart.style.display = data.count > 0 ? 'flex' : 'none';
    }

    const badge = document.getElementById('csCountBadge');
    if (badge) { badge.textContent = data.count; badge.style.display = data.count > 0 ? 'flex' : 'none'; }
    const totalEl = document.getElementById('csTotal');
    if (totalEl) totalEl.textContent = data.total + ' €';
    const footer = document.getElementById('csFooter');
    if (footer) footer.style.display = data.count > 0 ? '' : 'none';
    const body = document.getElementById('csBody');
    if (body && data.html) body.innerHTML = data.html;
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCart(); });

/* ── WISHLIST ── */
const WISH_KEY = 'shopzone_wishlist';

function getWish() {
    try { return JSON.parse(localStorage.getItem(WISH_KEY)) || {}; }
    catch { return {}; }
}

function saveWish(data) {
    localStorage.setItem(WISH_KEY, JSON.stringify(data));
}
function toggleWish(btn) {
    const id   = btn.dataset.id;
    const wish = getWish();
    const icon = btn.querySelector('i');

    if (wish[id]) {
        delete wish[id];
        btn.classList.remove('saved');
        icon.className = 'fa-regular fa-heart';
        btn.style.color = '#ccc';
        btn.style.background = '#f5f5f7';
        btn.style.borderColor = 'rgba(0,0,0,0.1)';
    } else {
        wish[id] = {
            id:    id,
            name:  btn.dataset.name,
            price: btn.dataset.price,
            img:   btn.dataset.img,
            url:   btn.dataset.url,
            cat:   btn.dataset.cat,
        };
        btn.classList.add('saved');
        icon.className = 'fa-solid fa-heart';
        btn.style.color = '#ff3b30';
        btn.style.background = 'rgba(255,59,48,0.08)';
        btn.style.borderColor = 'rgba(255,59,48,0.2)';
        btn.classList.remove('pop');
        void btn.offsetWidth;
        btn.classList.add('pop');
        btn.addEventListener('animationend', () => btn.classList.remove('pop'), { once: true });
    }

    saveWish(wish);
    updateNavWishCount();
    renderWishlist();
}
function renderWishlist() {
    const wish    = getWish();
    const items   = Object.values(wish);
    const section = document.getElementById('wishlistSection');
    const grid    = document.getElementById('wishlistGrid');

    if (!section || !grid) return;

    if (!items.length) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';
    grid.innerHTML = items.map(function(p) {
        var imgHtml = p.img
            ? '<img src="' + p.img + '" alt="' + p.name + '" loading="lazy">'
            : '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:48px;"><i class="fa-solid fa-box"></i></div>';

return '<a href="' + p.url + '" class="product-card" style="text-decoration:none;">'
    + '<div class="product-img" style="aspect-ratio:1;overflow:hidden;border-radius:var(--radius-2xl);background:var(--surface);margin-bottom:16px;position:relative;">'
    + imgHtml
    + '<button class="pm-wish-btn saved"'
    + ' data-id="' + p.id + '"'
    + ' data-name="' + p.name + '"'
    + ' data-price="' + p.price + '"'
    + ' data-img="' + p.img + '"'
    + ' data-url="' + p.url + '"'
    + ' data-cat="' + p.cat + '"'
    + ' onclick="event.preventDefault(); toggleWish(this)">'
    + '<i class="fa-solid fa-heart"></i>'
    + '</button>'
    + '</div>'
    + '<div class="product-card-body">'
    + '<div class="product-card-meta">'
    + '<div>'
    + '<div class="product-card-name">' + p.name + '</div>'
    + '<div class="product-card-sub">' + p.cat + '</div>'
    + '</div>'
    + '<div class="product-card-price">' + p.price + ' \u20AC</div>'
    + '</div>'
    + '</div>'
    + '</a>';
    }).join('');
}
document.addEventListener('DOMContentLoaded', () => {
    const wish = getWish();
    document.querySelectorAll('.pm-wish-btn[data-id]').forEach(btn => {
        if (wish[btn.dataset.id]) {
            btn.classList.add('saved');
            btn.querySelector('i').className = 'fa-solid fa-heart';
        } else {
            btn.querySelector('i').className = 'fa-regular fa-heart';
        }
    });
    updateNavWishCount();
    renderWishlist();
});

function updateNavWishCount() {
    const wish  = getWish();
    const count = Object.keys(wish).length;

    const badge      = document.getElementById('navWishCount');
    const bottomBadge = document.getElementById('bottomNavWishCount');

    if (badge) {
        badge.textContent   = count;
        badge.style.display = count > 0 ? 'inline-flex' : 'none';
    }
    if (bottomBadge) {
        bottomBadge.textContent   = count;
        bottomBadge.style.display = count > 0 ? 'flex' : 'none';
    }
}
/* ── LIVE SEARCH ── */
(function() {
    const input    = document.getElementById('searchInput');
    const dropdown = document.getElementById('searchDropdown');
    if (!input || !dropdown) return;

    let timer = null;

    input.addEventListener('input', function() {
        clearTimeout(timer);
        const q = this.value.trim();

        if (q.length < 1) {
            dropdown.style.display = 'none';
            return;
        }

        timer = setTimeout(function() {
            fetch('/shop/search-live?q=' + encodeURIComponent(q))
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (!data.length) {
                    dropdown.innerHTML = '<div class="search-result-empty">Nuk u gjet asgjë</div>';
                    dropdown.style.display = 'block';
                    return;
                }

                dropdown.innerHTML = data.map(function(p) {
                    return '<a href="/shop/' + p.id + '" class="search-result-item">'
                        + (p.img ? '<img src="' + p.img + '" alt="' + p.name + '">' : '<div style="width:36px;height:36px;border-radius:8px;background:#f3f3f5;flex-shrink:0;"></div>')
                        + '<span class="search-result-name">' + p.name + '</span>'
                        + '<span class="search-result-price">' + p.price + ' €</span>'
                        + '</a>';
                }).join('');

                dropdown.style.display = 'block';
            })
            .catch(function() { dropdown.style.display = 'none'; });
        }, 220);
    });

    document.addEventListener('click', function(e) {
        if (!input.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.style.display = 'none';
        }
    });

    input.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') dropdown.style.display = 'none';
    });
})();
function toggleProfileMenu() {
    const menu = document.getElementById('profileMenu');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}

document.addEventListener('click', function(e) {
    const wrap = document.getElementById('profileDropdownWrap');
    if (wrap && !wrap.contains(e.target)) {
        const menu = document.getElementById('profileMenu');
        if (menu) menu.style.display = 'none';
    }
});
</script>

@stack('scripts')
<!-- BOTTOM NAV MOBILE -->
<div class="bottom-nav">
    <div class="bottom-nav-inner">
        <a href="{{ url('/') }}" class="bottom-nav-item {{ request()->is('/') ? 'active' : '' }}">
            <i class="fa-solid fa-house"></i>
            <span>Kryefaqja</span>
        </a>

        <a href="{{ url('/shop?featured=1') }}" class="bottom-nav-item {{ request()->is('shop') && request('featured') ? 'active' : '' }}">
            <i class="fa-regular fa-heart"></i>
            <span>Favoritet</span>
            <span class="bottom-nav-badge" id="bottomNavWishCount" style="display:none;">0</span>
        </a>


     <a href="{{ url('/profili-im') }}" class="bottom-nav-item {{ request()->is('profili-im') ? 'active' : '' }}">
    <i class="fa-solid fa-bag-shopping"></i>
    <span>Blerjet</span>
</a>

        <button onclick="openCart()" class="bottom-nav-item">
            <i class="fa-solid fa-cart-shopping"></i>
            <span>Shporta</span>
            <span class="bottom-nav-badge" id="bottomNavCartCount" style="{{ $cartCount > 0 ? '' : 'display:none;' }}">
                {{ $cartCount }}
            </span>
        </button>
    </div>
</div>
</body>
</html>