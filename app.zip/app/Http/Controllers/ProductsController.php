<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use App\Models\ProductVariantImage;
use App\Models\ProductSpec;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductsController extends Controller
{
    public function index()
    {
        $products   = Product::with(['category', 'brand', 'images'])->latest()->paginate(15);
        $categories = Category::all();
        $brands     = Brand::all();
        return view('products.index', compact('products', 'categories', 'brands'));
    }

    public function create()
    {
        $categories = Category::all();
        $brands     = Brand::all();
        return view('products.Create', compact('categories', 'brands'));
    }

    // ════════════════════════════════════════════════════════
    // STORE
    // ════════════════════════════════════════════════════════
    public function store(Request $request)
    {
        $request->validate([
            'name'                              => 'nullable|string|max:255',
            'description'                       => 'nullable|string',
            'price'                             => 'nullable|numeric|min:0',
            'sale_price'                        => 'nullable|numeric|min:0',
            'stock'                             => 'nullable|integer|min:0',
            'category_id'                       => 'nullable|exists:categories,id',
            'brand_id'                          => 'nullable|exists:brands,id',

            'images'                            => 'nullable|array',
            'images.*'                          => 'nullable|image|mimes:jpeg,png,jpg,webp,avif|max:4096',
            'primary_index'                     => 'nullable|integer|min:0',

            'specs'                             => 'nullable|array',
            'specs.*.key'                       => 'nullable|string|max:255',
            'specs.*.value'                     => 'nullable|string|max:1000',

            'variants'                          => 'nullable|array',
            'variants.*.color_name'             => 'nullable|string|max:255',
            'variants.*.color_hex'              => 'nullable|string|max:20',

            'variants.*.images'                 => 'nullable|array',
            'variants.*.images.*'               => 'nullable|image|mimes:jpeg,png,jpg,webp,avif|max:4096',
            'variants.*.existing_images'        => 'nullable|array',
            'variants.*.existing_images.*'      => 'nullable|string|max:500',

            'variants.*.storages'               => 'nullable|array',
            'variants.*.storages.*.storage'     => 'nullable|string|max:50',
            'variants.*.storages.*.price'       => 'nullable|numeric|min:0',
            'variants.*.storages.*.sale_price'  => 'nullable|numeric|min:0',
            'variants.*.storages.*.stock'       => 'nullable|integer|min:0',
        ]);

        if (!$request->filled('name') || !$request->filled('category_id')) {
            return redirect()->route('admin.products.index')
                ->with('error', 'Emri dhe kategoria janë të detyrueshme.');
        }

        $productData                = $request->only(['name', 'description', 'price', 'sale_price', 'stock', 'category_id', 'brand_id']);
        $productData['stock']       = $productData['stock'] ?? 0;
        $productData['featured']    = $request->has('featured')  ? 1 : 0;
        $productData['is_active']   = $request->has('is_active') ? 1 : 0;

        $product = Product::create($productData);

        $this->saveProductImages($request, $product);
        $this->saveSpecs($request, $product);
        $this->saveVariants($request, $product);

        return redirect()->route('admin.products.index')
            ->with('success', 'Produkti u krijua me sukses!');
    }

    // ════════════════════════════════════════════════════════
    // UPDATE
    // ════════════════════════════════════════════════════════
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'                              => 'required|string|max:255',
            'description'                       => 'nullable|string',
            'price'                             => 'nullable|numeric|min:0',
            'sale_price'                        => 'nullable|numeric|min:0',
            'stock'                             => 'nullable|integer|min:0',
            'category_id'                       => 'required|exists:categories,id',
            'brand_id'                          => 'nullable|exists:brands,id',

            'images'                            => 'nullable|array',
            'images.*'                          => 'nullable|image|mimes:jpeg,png,jpg,webp,avif|max:4096',
            'primary_index'                     => 'nullable|integer|min:0',

            'specs'                             => 'nullable|array',
            'specs.*.key'                       => 'nullable|string|max:255',
            'specs.*.value'                     => 'nullable|string|max:1000',

            'variants'                          => 'nullable|array',
            'variants.*.color_name'             => 'nullable|string|max:255',
            'variants.*.color_hex'              => 'nullable|string|max:20',

            'variants.*.images'                 => 'nullable|array',
            'variants.*.images.*'               => 'nullable|image|mimes:jpeg,png,jpg,webp,avif|max:4096',
            'variants.*.existing_images'        => 'nullable|array',
            'variants.*.existing_images.*'      => 'nullable|string|max:500',

            'variants.*.storages'               => 'nullable|array',
            'variants.*.storages.*.storage'     => 'nullable|string|max:50',
            'variants.*.storages.*.price'       => 'nullable|numeric|min:0',
            'variants.*.storages.*.sale_price'  => 'nullable|numeric|min:0',
            'variants.*.storages.*.stock'       => 'nullable|integer|min:0',
        ]);

        $product = Product::with(['images', 'variants', 'variantImages', 'specs'])->findOrFail($id);

        $data                = $request->only(['name', 'description', 'price', 'sale_price', 'stock', 'category_id', 'brand_id']);
        $data['stock']       = $data['stock'] ?? 0;
        $data['featured']    = $request->has('featured')  ? 1 : 0;
        $data['is_active']   = $request->has('is_active') ? 1 : 0;

        $product->update($data);

        // ── Fotot e produktit ─────────────────────────────────
        $this->saveProductImages($request, $product, isUpdate: true);

        // ── Specs ─────────────────────────────────────────────
        $product->specs()->delete();
        $this->saveSpecs($request, $product);

        // ── Variant Images: fshi vetëm ato që nuk u dërguan mbrapsht ──
        $allExistingKept = [];
        if ($request->has('variants') && is_array($request->variants)) {
            foreach ($request->variants as $variantInput) {
                $kept = array_filter((array)($variantInput['existing_images'] ?? []));
                $allExistingKept = array_merge($allExistingKept, array_values($kept));
            }
        }

        // Fshi nga storage & DB vetëm fotot që nuk janë mbajtur
        $product->variantImages->each(function ($img) use ($allExistingKept) {
            if (!in_array($img->image_path, $allExistingKept)) {
                Storage::disk('public')->delete($img->image_path);
                $img->delete();
            }
        });

        // ── Variantet: fshi të vjetrat, ruaj të rejat ─────────
        $product->variants()->delete();
        $this->saveVariants($request, $product);

        return redirect()->route('admin.products.index')
            ->with('success', 'Produkti u përditësua me sukses!');
    }

    // ════════════════════════════════════════════════════════
    // EDIT
    // ════════════════════════════════════════════════════════
    public function edit($id)
    {
        $product    = Product::with(['images', 'variants', 'variantImages', 'specs'])->findOrFail($id);
        $categories = Category::all();
        $brands     = Brand::all();
        return view('products.Create', compact('product', 'categories', 'brands'));
    }

    // ════════════════════════════════════════════════════════
    // SHOW (frontend)
    // ════════════════════════════════════════════════════════
    public function show($id)
    {
        $product = Product::with([
            'category', 'brand', 'images', 'variants', 'variantImages', 'specs'
        ])->findOrFail($id);

        $related = Product::with(['images', 'variants'])
            ->where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('is_active', true)
            ->limit(4)
            ->get();

        return view('products.show', compact('product', 'related'));
    }

    // ════════════════════════════════════════════════════════
    // DESTROY
    // ════════════════════════════════════════════════════════
    public function destroy($id)
    {
        $product = Product::with(['images', 'variants', 'variantImages'])->findOrFail($id);

        foreach ($product->images as $img) {
            Storage::disk('public')->delete($img->image_path);
        }

        $product->variantImages->each(function ($img) {
            Storage::disk('public')->delete($img->image_path);
        });

        $product->variants
            ->pluck('image_path')
            ->filter()
            ->unique()
            ->each(fn($p) => Storage::disk('public')->delete($p));

        $product->images()->delete();
        $product->variantImages()->delete();
        $product->variants()->delete();
        $product->specs()->delete();
        $product->delete();

        return redirect()->route('admin.products.index')
            ->with('success', 'Produkti u fshi!');
    }

    // ════════════════════════════════════════════════════════
    // BULK DELETE
    // ════════════════════════════════════════════════════════
    public function bulkDelete(Request $request)
    {
        $ids = $request->input('product_ids', []);

        if (!is_array($ids) || empty($ids)) {
            return redirect()->route('admin.products.index')
                ->with('error', 'Nuk u zgjodh asnjë produkt.');
        }

        $products = Product::with(['images', 'variants', 'variantImages', 'specs'])
            ->whereIn('id', $ids)
            ->get();

        foreach ($products as $product) {
            foreach ($product->images as $img) {
                if ($img->image_path) Storage::disk('public')->delete($img->image_path);
            }

            $product->variantImages->each(function ($img) {
                Storage::disk('public')->delete($img->image_path);
            });

            $product->variants
                ->pluck('image_path')
                ->filter()
                ->unique()
                ->each(fn($p) => Storage::disk('public')->delete($p));

            $product->images()->delete();
            $product->variantImages()->delete();
            $product->variants()->delete();
            $product->specs()->delete();
            $product->delete();
        }

        return redirect()->route('admin.products.index')
            ->with('success', 'Produktet e zgjedhura u fshinë me sukses!');
    }

    // ════════════════════════════════════════════════════════
    // AJAX — Fshi foto produkti
    // ════════════════════════════════════════════════════════
    public function deleteImage($productId, $imageId)
    {
        $image = ProductImage::where('product_id', $productId)
                             ->where('id', $imageId)
                             ->firstOrFail();

        Storage::disk('public')->delete($image->image_path);
        $wasPrimary = $image->is_primary;
        $image->delete();

        if ($wasPrimary) {
            $next = ProductImage::where('product_id', $productId)->first();
            if ($next) $next->update(['is_primary' => true]);
        }

        return response()->json(['success' => true]);
    }

    // ════════════════════════════════════════════════════════
    // AJAX — Bëje foto kryesore
    // ════════════════════════════════════════════════════════
    public function setPrimaryImage($productId, $imageId)
    {
        ProductImage::where('product_id', $productId)->update(['is_primary' => false]);
        ProductImage::where('product_id', $productId)
                    ->where('id', $imageId)
                    ->update(['is_primary' => true]);

        return response()->json(['success' => true]);
    }

    // ════════════════════════════════════════════════════════
    // Brands by Category (AJAX)
    // ════════════════════════════════════════════════════════
    public function getBrandsByCategory($categoryId)
    {
        $category = Category::with('brands')->find($categoryId);
        if (!$category) return response()->json([]);
        return response()->json($category->brands);
    }

    // ════════════════════════════════════════════════════════
    // HELPER — Ruaj fotot e produktit
    // ════════════════════════════════════════════════════════
    private function saveProductImages(Request $request, Product $product, bool $isUpdate = false): void
    {
        if (!$request->hasFile('images')) return;

        $primaryIndex  = (int) $request->input('primary_index', 0);
        $existingCount = $isUpdate ? $product->images()->count() : 0;
        $hasNoPrimary  = $isUpdate ? !$product->images()->where('is_primary', true)->exists() : true;

        foreach ($request->file('images') as $i => $file) {
            $path      = $file->store('products', 'public');
            $isPrimary = ($i === $primaryIndex) && (!$isUpdate || $hasNoPrimary || $existingCount === 0);

            if ($isPrimary && $isUpdate) {
                $product->images()->update(['is_primary' => false]);
            }

            ProductImage::create([
                'product_id' => $product->id,
                'image_path' => $path,
                'is_primary' => $isPrimary,
                'sort_order' => $existingCount + $i,
            ]);
        }
    }

    // ════════════════════════════════════════════════════════
    // HELPER — Ruaj specs
    // ════════════════════════════════════════════════════════
    private function saveSpecs(Request $request, Product $product): void
    {
        if (!$request->has('specs') || !is_array($request->specs)) return;

        foreach ($request->specs as $spec) {
            $key   = trim($spec['key']   ?? '');
            $value = trim($spec['value'] ?? '');
            if ($key === '' || $value === '') continue;

            ProductSpec::create([
                'product_id' => $product->id,
                'spec_key'   => $key,
                'spec_value' => $value,
            ]);
        }
    }

    // ════════════════════════════════════════════════════════
    // HELPER — Ruaj variantet
    // ════════════════════════════════════════════════════════
    private function saveVariantImages(Request $request, Product $product, int $vi, string $colorName, string $colorHex): void
{
    $variantInput = $request->variants[$vi] ?? [];

    // Ruaj fotot e reja të ngarkuara
    if (!empty($request->file("variants.{$vi}.images"))) {
        $files = $request->file("variants.{$vi}.images");
        foreach ($files as $idx => $file) {
            if (!$file || !$file->isValid()) continue;

            $path = $file->store('variant-images', 'public');

            ProductVariantImage::create([
                'product_id' => $product->id,
                'color_name' => $colorName,
                'color_hex'  => $colorHex,
                'image_path' => $path,
                'is_primary' => $idx === 0,
                'sort_order' => $idx,
            ]);
        }
    }

    // Ruaj fotot ekzistuese që u mbajtën
    $existingImages = array_filter((array)($variantInput['existing_images'] ?? []));

    foreach ($existingImages as $idx => $imagePath) {
        // Kontrollo nëse ekziston tashmë në DB
        $exists = ProductVariantImage::where('product_id', $product->id)
            ->where('image_path', $imagePath)
            ->exists();

        if (!$exists) {
            ProductVariantImage::create([
                'product_id' => $product->id,
                'color_name' => $colorName,
                'color_hex'  => $colorHex,
                'image_path' => $imagePath,
                'is_primary' => $idx === 0,
                'sort_order' => $idx,
            ]);
        }
    }
}
  private function saveVariants(Request $request, Product $product)
{
    if (!$request->has('variants') || !is_array($request->variants)) return;

    foreach ($request->variants as $vi => $variantInput) {
        $colorName = $variantInput['color_name'] ?? '';
        $colorHex  = $variantInput['color_hex']  ?? '';

        $storages = $variantInput['storages'] ?? [];

        foreach ($storages as $si => $storageData) {
            $storageName = $storageData['storage'] ?? '';

            // Nëse zgjodhën "custom", merr nga storage_custom
            if ($storageName === 'custom') {
                $storageName = $storageData['storage_custom'] ?? '';
            }
$basePrice  = (float)($storageData['base_price']  ?? 0);
$extraPrice = (float)($storageData['extra_price'] ?? 0);
$finalPrice = $basePrice + $extraPrice;

$salePrice = !empty($storageData['sale_price'])
    ? (float)$storageData['sale_price']
    : null;

$product->variants()->create([
    'color_name'  => $colorName,
    'color_hex'   => $colorHex,
    'storage'     => $storageName,
    'base_price'  => $basePrice,
    'extra_price' => $extraPrice,
    'price'       => $finalPrice,
    'sale_price'  => $salePrice,
    'stock'       => (int)($storageData['stock'] ?? 0),
]);
        }

        // Fotot e variantit
        $this->saveVariantImages($request, $product, $vi, $colorName, $colorHex);
    }
}

    // ════════════════════════════════════════════════════════
    // PRIVATE HELPER — formatStorage
    // ════════════════════════════════════════════════════════
    private function formatStorage(string $val): string
    {
        $val = trim($val);
        if (preg_match('/\d+\s*(GB|TB)/i', $val)) {
            return strtoupper(preg_replace('/\s+/', '', $val));
        }
        $num = (int) filter_var($val, FILTER_SANITIZE_NUMBER_INT);
        return $num >= 1000 ? ($num / 1000) . 'TB' : $num . 'GB';
    }
}