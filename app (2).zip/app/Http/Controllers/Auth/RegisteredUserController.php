<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('shop.auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
$request->validate([
    'name' => ['required', 'string', 'max:255'],
    'surname' => ['required', 'string', 'max:255'],
    'phone' => ['required', 'string', 'max:50'],
    'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:'.User::class],
    'password' => ['required', 'confirmed', Rules\Password::defaults()],
    'phone'    => 'nullable|regex:~^[0-9\+\s\-]{7,20}$~', 
]
, [
    'phone.regex' => 'Numri i telefonit mund të përmbajë vetëm numra.',
]);
     $user = User::create([
    'name' => $request->name,
    'surname' => $request->surname,
    'email' => $request->email,
    'phone' => $request->phone,
    'password' => Hash::make($request->password),
    'role' => 'customer',
]);

        event(new Registered($user));

        Auth::login($user);

        return redirect(route('dashboard', absolute: false));
    }
}
