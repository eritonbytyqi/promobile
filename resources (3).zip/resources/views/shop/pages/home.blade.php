@extends('layouts.shop')

@section('title', 'ShopZone — Kryefaqja')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/shop/home.css') }}">
@endpush

@push('scripts')
    <script src="{{ asset('js/shop/home.js') }}"></script>
@endpush
@section('content')

{{-- CAROUSEL --}}
@include('shop.partials.hero-carousel', ['banners' => $banners])

{{-- KATEGORITË --}}
@if($categories->count() > 0)
<div class="pm-cats-section">
    <div class="pm-section-label">Shfleto sipas kategorisë</div>
 <div class="pm-section-header">
    <h2 class="pm-section-title" style="margin-bottom:0;">Kategoritë</h2>
    <a href="{{ url('/shop') }}" class="pm-see-all">
        Shiko të gjitha <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
    </a>
</div>
    <div class="pm-cats-grid">
        @foreach($categories as $cat)
        <a href="{{ url('/shop?category='.$cat->id) }}" class="pm-cat-card">
            <div class="pm-cat-icon">
                <i class="fa-solid {{ $cat->icon ?? 'fa-tag' }}"></i>
            </div>
            <span class="pm-cat-name">{{ $cat->name }}</span>
        </a>
        @endforeach
    </div>
</div>
@endif

{{-- FEATURED --}}
@if($featured->count() > 0)
<div class="pm-products-section">
    <div class="pm-section-header">
        <div>
            <div class="pm-section-label">Të Zgjedhura</div>
            <h2 class="pm-section-title" style="margin-bottom:0;">Produktet e Featuara</h2>
        </div>
        <a href="{{ url('/shop?featured=1') }}" class="pm-see-all">
            Shiko të gjitha <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>
       <div id="wishlistSection" style="display:none; margin-bottom:40px;">
    <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#6e6e73;margin-bottom:6px;">Lista jote</div>
    <h2 style="font-size:24px;font-weight:800;letter-spacing:-0.5px;margin-bottom:20px;">
        <i class="fa-solid fa-heart" style="color:#ff3b30;font-size:20px;margin-right:8px;"></i>
        Të preferuarat
    </h2>
    <div class="products-grid" id="wishlistGrid" style="grid-template-columns: repeat(auto-fill, minmax(180px, 220px));"></div>
    <hr style="border:none;border-top:1px solid rgba(0,0,0,0.07);margin:32px 0;">
</div>
    <div class="pm-products-grid">
        @foreach($featured as $product)
   @php
    $firstVariant = $product->variants?->first();

   $pImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $pSrc = $pImg ? asset('storage/' . $pImg->image_path) : null;

    $pHasSale = $product->sale_price && $product->sale_price < $product->price;
    $pPrice   = $pHasSale ? $product->sale_price : $product->price;
    $pOldPrice = $pHasSale ? $product->price : null;

    $colors = $product->variants
        ? $product->variants->filter(fn($v) => $v->color_name)->unique('color_name')->values()
        : collect();
@endphp
        <a href="{{ url('/shop/'.$product->id) }}" class="pm-product-card">
            <div class="pm-product-img">
              
                @if($pSrc)
                    <img src="{{ $pSrc }}" alt="{{ $product->name }}" loading="lazy">
                @else
                    <div class="pm-product-img-ph"><i class="fa-solid fa-box"></i></div>
                @endif
                  <button class="pm-wish-btn"
        data-id="{{ $product->id }}"
        data-name="{{ addslashes($product->name) }}"
        data-price="{{ $pHasSale ? number_format($product->sale_price,2) : number_format($product->price,2) }}"
        data-img="{{ $pSrc ?? '' }}"
        data-url="{{ url('/shop/'.$product->id) }}"
        data-cat="{{ $product->category->name ?? '' }}"
        onclick="event.preventDefault(); toggleWish(this)">
    <i class="fa-solid fa-heart"></i>
</button>
                @if($product->featured)
                    <span class="pm-product-badge pm-badge-featured">
                        <i class="fa-solid fa-star" style="font-size:9px;"></i> Top
                    </span>
                @endif
                @if($pHasSale)
                    <span class="pm-product-badge pm-badge-sale" style="left:auto;right:12px;">SALE</span>
                @endif
            </div>
            <div class="pm-product-info">
                <div class="pm-product-cat">{{ $product->category->name ?? '—' }}</div>
                <div class="pm-product-name">{{ $product->name }}</div>
                <div class="pm-product-brand">{{ $product->brand->name ?? '' }}</div>

@if($colors->count() > 0)
    <div class="pm-card-colors">
        @foreach($colors as $color)
            <span class="pm-card-color"
                  title="{{ $color->color_name }}"
                  style="background: {{ $color->color_hex ?? '#ccc' }};"></span>
        @endforeach
    </div>
@endif
                <div class="pm-product-footer">
                    <div>
                        @if($pHasSale)
                            <span class="pm-product-old">{{ number_format($product->price, 2) }} €</span>
                        @endif
                      <span class="pm-product-price">
    @if($product->variants && $product->variants->count() > 0)
        <span style="font-size:11px;font-weight:500;color:#6e6e73;">nga</span>
    @endif
    {{ number_format($pPrice, 2) }} €
</span>
                    </div>
                    <button class="pm-add-btn"
                            onclick="event.preventDefault(); addToCart({{ $product->id }}, this)">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </a>
        @endforeach
    </div>
</div>
@endif
{{-- NEW RELEASES --}}
@if($latest->count() > 0)
<div class="pm-releases">
<div class="pm-releases-header">
    <div>
        <div class="pm-section-label">Koleksioni i Ri</div>
        <div class="pm-releases-label">New Releases</div>
        <div class="pm-releases-sub">Të fundit nga koleksioni ynë.</div>
    </div>
    <a href="{{ url('/shop') }}" class="pm-see-all">
        Shiko të gjitha <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
    </a>
</div>
    <div class="pm-releases-grid">
            @foreach($latest->take(8) as $product)
       @php
    $pImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $pSrc = $pImg ? asset('storage/' . $pImg->image_path) : null;

    $pHasSale = $product->sale_price && $product->sale_price < $product->price;
    $pPrice   = $pHasSale ? $product->sale_price : $product->price;
    $pOldPrice = $pHasSale ? $product->price : null;

    $discount = $pOldPrice ? round((($pOldPrice - $pPrice) / $pOldPrice) * 100) : 0;

    $firstVariant = $product->variants?->first();

    $colors = $product->variants
        ? $product->variants->filter(fn($v) => $v->color_name)->unique('color_name')->values()
        : collect();
@endphp
       <a href="{{ url('/shop/'.$product->id) }}" class="pm-nr-card">
    <div class="pm-nr-img">
        <button class="pm-wish-btn"
        data-id="{{ $product->id }}"
        data-name="{{ addslashes($product->name) }}"
        data-price="{{ $pHasSale ? number_format($product->sale_price,2) : number_format($product->price,2) }}"
        data-img="{{ $pSrc ?? '' }}"
        data-url="{{ url('/shop/'.$product->id) }}"
        data-cat="{{ $product->category->name ?? '' }}"
        onclick="event.preventDefault(); toggleWish(this)">
  <i class="fa-regular fa-heart"></i>

</button>
        @if($pSrc)
            <img src="{{ $pSrc }}" alt="{{ $product->name }}" loading="lazy">
        @else
            <div class="pm-nr-img-ph"><i class="fa-solid fa-box"></i></div>
        @endif
        <div class="pm-nr-badge-new">NEW</div>
        @if($discount > 0)
            <span class="pm-nr-badge-discount">-{{ $discount }}%</span>
        @endif
        <div class="pm-nr-overlay">
            <button class="pm-nr-quick-add"
                    onclick="event.preventDefault(); addToCart({{ $product->id }}, this, {{ $firstVariant?->id ?? 'null' }})">
                <i class="fa-solid fa-bag-shopping"></i>
                Shto në shportë
            </button>
        </div>
    </div>
            <div class="pm-nr-info">
                <div class="pm-nr-cat">{{ $product->category->name ?? '—' }}</div>
                <div class="pm-nr-name">{{ $product->name }}</div>
                @if($colors->count() > 0)
    <div class="pm-card-colors pm-card-colors--small">
        @foreach($colors as $color)
            <span class="pm-card-color pm-card-color--small"
                  title="{{ $color->color_name }}"
                  style="background: {{ $color->color_hex ?? '#ccc' }};"></span>
        @endforeach
    </div>
@endif
                <div class="pm-nr-footer">
                    <div class="pm-nr-prices">
                        @if($pHasSale)
                            <span class="pm-nr-old">{{ number_format($product->price, 2) }} €</span>
                        @endif
                        <span class="pm-product-price">
    @if($product->variants && $product->variants->count() > 0 && $colors->count() > 0)
        <span style="font-size:11px;font-weight:500;color:#6e6e73;">nga</span>
    @endif
    {{ number_format($pPrice, 2) }} €
</span>
                    </div>
                    <button class="pm-nr-add-btn"
                            onclick="event.preventDefault(); addToCart({{ $product->id }}, this, {{ $product->variants?->first()?->id ?? 'null' }})">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </a>
        @endforeach
    </div>
</div>
@endif

{{-- BENTO GRID --}}
{{-- BENTO GRID --}}
<div class="pm-bento">
    <div class="pm-bento-grid">

      @php
    $bentoProduct = $featured->first();
    $bentoImg = $bentoProduct?->images?->firstWhere('is_primary', true)
             ?? $bentoProduct?->images?->first();
    $bentoSrc = $bentoImg ? asset('storage/'.$bentoImg->image_path) : null;

    // Merre bannerin e parë aktiv për bento
    $bentoBanner = $banners->first();
@endphp 

        <a href="{{ $bentoProduct ? url('/shop/'.$bentoProduct->id) : url('/shop') }}"
           class="pm-bento-hero">
            <div class="pm-bento-hero-img"
                 style="{{ $bentoSrc ? 'background-image:url('.$bentoSrc.')' : 'background:#1d1d1f;' }}">
            </div>
            <div class="pm-bento-hero-content">
                <div class="pm-bento-hero-badge">Produkt i Featuar</div>
                <div class="pm-bento-hero-title">
                    {{ $bentoProduct?->name ?? 'Zbulo koleksionin' }}
                </div>
                <span class="pm-bento-hero-btn">
                    Eksploro <i class="fa-solid fa-arrow-right" style="font-size:10px;"></i>
                </span>
            </div>
        </a>

        {{-- Karta Oferta — dinamike nga banneri i parë --}}
        @if($bentoBanner)
        <a href="{{ $bentoBanner->btn_primary_url ?? url('/shop?featured=1') }}" class="pm-bento-card blue">
            <div>
                <div class="pm-bento-card-title">
                    {{ $bentoBanner->badge_text ?? 'Oferta Speciale' }}
                </div>
                <div class="pm-bento-card-sub">
                    {{ $bentoBanner->subtitle ?? 'Zbulo produktet me zbritje.' }}
                </div>
                @if($bentoBanner->price)
                <div style="font-size:1.6rem;font-weight:800;color:#fff;margin-top:4px;">
                    {{ number_format($bentoBanner->price, 2) }} €
                </div>
                @endif
            </div>
            <span class="pm-bento-card-link">
                {{ $bentoBanner->btn_primary_text ?? 'Shiko ofertat' }} →
            </span>
        </a>
        @else
        <a href="{{ url('/shop?featured=1') }}" class="pm-bento-card blue">
            <div>
                <div class="pm-bento-card-title">Oferta Speciale</div>
                <div class="pm-bento-card-sub">Zbulo produktet me zbritje dhe oferta ekskluzive.</div>
            </div>
            <span class="pm-bento-card-link">Shiko ofertat →</span>
        </a>
        @endif

        <div class="pm-bento-info-row">
            {{-- ... info kartat mbeten njëlloj --}}
        </div>
    </div>
</div>

{{-- ACCESSORIES --}}
@php
    $keywords = [
    'accessor',
    'accessories',
    'accesor',
    'aksesor',
    'aksesorë',
];

$accessoriesCategory = \App\Models\Category::where(function ($query) use ($keywords) {
    foreach ($keywords as $word) {
        $query->orWhereRaw('LOWER(name) LIKE ?', ['%' . strtolower($word) . '%']);
    }
})->first();
@endphp

@if($accessories->count() > 0)
<div class="pm-accessories">
    <div class="pm-acc-header">
        <div class="pm-acc-title">Essential Accessories</div>
        <a href="{{ url('/shop?category='.($accessoriesCategory->id ?? '')) }}"
           class="pm-acc-see-all">
            View all <i class="fa-solid fa-arrow-right" style="font-size:11px;"></i>
        </a>
    </div>
    <div class="pm-acc-grid">
        @foreach($accessories as $acc)
        @php
            $aImg = $acc->images?->firstWhere('is_primary', true) ?? $acc->images?->first();
            $aSrc = $aImg ? asset('storage/'.$aImg->image_path) : null;
            $aHasSale = $acc->sale_price && $acc->sale_price < $acc->price;
            $aPrice   = $aHasSale ? $acc->sale_price : $acc->price;
        @endphp
        <a href="{{ url('/shop/'.$acc->id) }}" class="pm-acc-card">
            <div class="pm-acc-img">
                @if($aSrc)
                    <img src="{{ $aSrc }}" alt="{{ $acc->name }}" loading="lazy">
                @else
                    <div class="pm-acc-img-ph"><i class="fa-solid fa-plug"></i></div>
                @endif
            </div>
            <div class="pm-acc-name">{{ $acc->name }}</div>
            <div class="pm-acc-cat">{{ $acc->category->name ?? '' }}</div>
            <div class="pm-acc-price">{{ number_format($aPrice, 2) }} €</div>
        </a>
        @endforeach
    </div>
</div>
@endif

@endsection
