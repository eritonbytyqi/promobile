@extends('client.layout')

@section('title', 'Kontakto — ProMobile')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/shop/contact.css') }}">
@endpush

@section('content')
@php
    $locations = setting('company_locations');
    $locations = $locations ? json_decode($locations, true) : [];
@endphp

<div class="contact-page">

    <div class="contact-hero">
        <div class="contact-hero-grid">
            <div>
                <div class="contact-kicker">
                    <span class="material-symbols-outlined" style="font-size:16px;">support_agent</span>
                    Kontakt & Mbështetje
                </div>

                <h1>Na kontaktoni lehtë dhe shpejt</h1>
                <p>
                    Këtu i gjeni të gjitha mënyrat për të na kontaktuar: lokacionet, telefonat,
                    email-at, orarin e punës dhe rrjetet sociale. Dizajni është mbajtur i pastër
                    që vizitori ta kuptojë menjëherë ku duhet të klikojë.
                </p>
            </div>

            <div class="contact-hero-side">
                @if(setting('company_phone'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Telefoni Kryesor</div>
                        <div class="hero-mini-value">{{ setting('company_phone') }}</div>
                    </div>
                @endif

                @if(setting('company_email'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Email Kryesor</div>
                        <div class="hero-mini-value">{{ setting('company_email') }}</div>
                    </div>
                @endif

                @if(setting('hours_weekdays'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Orari</div>
                        <div class="hero-mini-value">
                            E Hënë — E Premte: {{ setting('hours_weekdays') }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    @if(session('contact_success'))
        <div class="alert-success">
            <span class="material-symbols-outlined" style="font-size:20px;">check_circle</span>
            Mesazhi u dërgua me sukses.
        </div>
    @endif

    <div class="contact-main">

        {{-- MAJTAS: LOKACIONET --}}
        <div class="section-card">
            <div class="section-head">
                <div class="section-kicker">Lokacionet</div>
                <h2 class="section-title">Ku na gjeni</h2>
                <p class="section-sub">
                    Zgjidhni lokacionin që ju përshtatet. Poshtë secilit lokacion shfaqet edhe harta.
                </p>
            </div>

            <div class="section-body">
                @if(count($locations))
                    <div class="location-list">
                        @foreach($locations as $loc)
                            <div class="location-card">
                                <div class="location-top">
                                    <div class="location-icon">
                                        <span class="material-symbols-outlined">location_on</span>
                                    </div>

                                    <div>
                                        <h3 class="location-name">
                                            {{ $loc['name'] ?? 'Lokacioni' }}
                                        </h3>

                                        <p class="location-address">
                                            {{ $loc['address_full'] ?? '' }}
                                        </p>

                                        @if(!empty($loc['phone']))
                                            <a class="location-phone" href="tel:{{ preg_replace('/\s+/', '', $loc['phone']) }}">
                                                <span class="material-symbols-outlined" style="font-size:18px;">call</span>
                                                {{ $loc['phone'] }}
                                            </a>
                                        @endif
                                    </div>
                                </div>

                                @if(!empty($loc['address_full']))
                                    <div class="location-map">
                                        <iframe
                                            src="https://maps.google.com/maps?q={{ urlencode($loc['address_full']) }}&output=embed"
                                            loading="lazy"
                                            allowfullscreen>
                                        </iframe>
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="empty-note">
                        Ende nuk janë shtuar lokacione. Sapo t’i shtoni nga paneli admin,
                        këtu do të shfaqen automatikisht.
                    </div>
                @endif
            </div>
        </div>

        {{-- DJATHTAS: KONTAKTI --}}
        <div class="contact-side-grid">

            <div class="section-card">
                <div class="section-head">
                    <div class="section-kicker">Kontakt i drejtpërdrejtë</div>
                    <h2 class="section-title">Na kontaktoni</h2>
                    <p class="section-sub">
                        Mënyrat kryesore për porosi, pyetje ose mbështetje.
                    </p>
                </div>

                <div class="section-body">
                    <div class="contact-methods">

                        @if(setting('social_whatsapp'))
                            <a class="contact-method" href="https://wa.me/{{ preg_replace('/\s+/', '', setting('social_whatsapp')) }}" target="_blank">
                                <div class="contact-method-icon">
                                    <i class="fa-brands fa-whatsapp" style="font-size:20px;"></i>
                                </div>
                                <div>
                                    <div class="contact-method-label">WhatsApp</div>
                                    <div class="contact-method-value">{{ setting('social_whatsapp') }}</div>
                                    <div class="contact-method-desc">Na shkruani direkt për përgjigje më të shpejtë.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_phone'))
                            <a class="contact-method" href="tel:{{ preg_replace('/\s+/', '', setting('company_phone')) }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">call</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Telefoni</div>
                                    <div class="contact-method-value">{{ setting('company_phone') }}</div>
                                    <div class="contact-method-desc">Na telefononi për informata të shpejta.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_phone2'))
                            <a class="contact-method" href="tel:{{ preg_replace('/\s+/', '', setting('company_phone2')) }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">phone_in_talk</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Numri Shtesë</div>
                                    <div class="contact-method-value">{{ setting('company_phone2') }}</div>
                                    <div class="contact-method-desc">Alternativë shtesë për kontakt.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_email'))
                            <a class="contact-method" href="mailto:{{ setting('company_email') }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">mail</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Email</div>
                                    <div class="contact-method-value">{{ setting('company_email') }}</div>
                                    <div class="contact-method-desc">Për kërkesa më të detajuara ose bashkëpunime.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_email2'))
                            <a class="contact-method" href="mailto:{{ setting('company_email2') }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">alternate_email</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Email Shtesë</div>
                                    <div class="contact-method-value">{{ setting('company_email2') }}</div>
                                    <div class="contact-method-desc">Email alternativ për support ose pyetje tjera.</div>
                                </div>
                            </a>
                        @endif

                    </div>
                </div>
            </div>

            @if(setting('hours_weekdays') || setting('hours_saturday') || setting('hours_sunday'))
                <div class="section-card">
                    <div class="section-head">
                        <div class="section-kicker">Orari</div>
                        <h2 class="section-title">Orët e punës</h2>
                    </div>

                    <div class="section-body">
                        <div class="hours-box">
                            @if(setting('hours_weekdays'))
                                <div class="hours-row">
                                    <div class="hours-day">E Hënë — E Premte</div>
                                    <div class="hours-time">{{ setting('hours_weekdays') }}</div>
                                </div>
                            @endif

                            @if(setting('hours_saturday'))
                                <div class="hours-row">
                                    <div class="hours-day">E Shtunë</div>
                                    <div class="hours-time">{{ setting('hours_saturday') }}</div>
                                </div>
                            @endif

                            @if(setting('hours_sunday'))
                                <div class="hours-row">
                                    <div class="hours-day">E Diel</div>
                                    <div class="hours-time">{{ setting('hours_sunday') }}</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

            @if(setting('social_instagram') || setting('social_facebook'))
                <div class="section-card">
                    <div class="section-head">
                        <div class="section-kicker">Rrjetet sociale</div>
                        <h2 class="section-title">Na ndiqni online</h2>
                    </div>

                    <div class="section-body">
                        <div class="social-row">
                            @if(setting('social_instagram'))
                                <a href="{{ setting('social_instagram') }}" target="_blank" class="social-pill">
                                    <i class="fa-brands fa-instagram"></i>
                                    Instagram
                                </a>
                            @endif

                            @if(setting('social_facebook'))
                                <a href="{{ setting('social_facebook') }}" target="_blank" class="social-pill">
                                    <i class="fa-brands fa-facebook-f"></i>
                                    Facebook
                                </a>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

        </div>
    </div>
</div>
@endsection
@push('scripts')
    <script src="{{ asset('js/shop/pages.js') }}"></script>
@endpush