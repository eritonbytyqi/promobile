
<section class="hero-section">

    @if(isset($banners) && $banners->count() > 0)

        <div class="hero-carousel" id="heroCarousel">

            @foreach($banners as $index => $banner)
                <div class="hero-slide {{ $index === 0 ? 'active' : '' }}" data-index="{{ $index }}">

                    {{-- Background image nga databaza --}}
                    <div class="hero-bg" style="
                        background-image: url('{{ $banner->image ? asset('storage/' . $banner->image) : asset('images/banner-default.jpg') }}');
                        background-color: {{ $banner->bg_color ?? '#0a0a1a' }};
                    "></div>

<div class="hero-banner-content">
                        @if($banner->badge_text)
                            <div class="hero-badge">{{ $banner->badge_text }}</div>
                        @endif

                        <h1 class="hero-title">{!! nl2br(e($banner->title)) !!}</h1>

                        @if($banner->subtitle)
                            <p class="hero-desc">{{ $banner->subtitle }}</p>
                        @endif

                        @if($banner->price)
                            <div class="hero-price">
                                Nga <strong>{{ number_format($banner->price, 2) }} €</strong>
                                &nbsp;·&nbsp; Transport falas
                            </div>
                        @endif

                        <div class="hero-actions">
                            @if($banner->btn_primary_text)
                                <a href="{{ $banner->btn_primary_url ?? url('/shop') }}"
                                   class="hero-btn hero-btn-primary">
                                    {{ $banner->btn_primary_text }}
                                </a>
                            @endif

                            @if($banner->btn_secondary_text)
                                <a href="{{ $banner->btn_secondary_url ?? url('/shop') }}"
                                   class="hero-btn hero-btn-ghost">
                                    {{ $banner->btn_secondary_text }}
                                </a>
                            @endif
                        </div>

                    </div>
                </div>
            @endforeach

            {{-- Dots --}}
            <div class="hero-dots" id="heroDots">
                @foreach($banners as $index => $banner)
                    <button class="hero-dot {{ $index === 0 ? 'active' : '' }}"
                            data-slide="{{ $index }}"
                            aria-label="Slide {{ $index + 1 }}">
                    </button>
                @endforeach
            </div>

            {{-- Arrows (vetëm nëse ka më shumë se 1 banner) --}}
            @if($banners->count() > 1)
                <div class="hero-arrows">
                    <button class="hero-arrow" id="heroPrev" aria-label="Para">&#8592;</button>
                    <button class="hero-arrow" id="heroNext" aria-label="Pas">&#8594;</button>
                </div>
            @endif

            <div class="hero-progress" id="heroProgress"></div>
        </div>

    @else
        {{-- Fallback nëse nuk ka bannerë në databazë --}}
        <div class="hero-empty">
            <p>Nuk ka oferta aktive.</p>
        </div>
    @endif

</section>

@push('styles')
<style>
    .hero-section {
        width: 100%;
        margin-bottom: 0;
    }

    .hero-carousel {
        position: relative;
        width: 100%;
        height: 520px;
        overflow: hidden;
        background: #0a0a1a;
    }

    @media (max-width: 768px) {
        .hero-carousel { height: 420px; }
    }

.hero-slide {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    padding: 0 6%;
    opacity: 0;
    transform: translateX(60px);
    transition: opacity .55s ease, transform .55s ease;
    pointer-events: none;
}

    .hero-slide.active {
        opacity: 1;
        transform: translateX(0);
        pointer-events: all;
    }

    .hero-slide.exit {
        opacity: 0;
        transform: translateX(-60px);
    }

.hero-bg {
    position: absolute;
    inset: 0;
    background-size: cover;
    background-position: center right;
    background-repeat: no-repeat;
    z-index: 0;
}

.hero-bg::after {
    content: '';
    position: absolute;
    inset: 0;
    background:
        linear-gradient(
            90deg,
            rgba(5,5,15,.88) 0%,
            rgba(5,5,15,.70) 30%,
            rgba(5,5,15,.30) 55%,
            rgba(5,5,15,.10) 75%,
            rgba(5,5,15,0) 100%
        );
}

.hero-banner-content {
    position: relative;
    z-index: 1;
    max-width: 560px;
    color: #fff;
    padding-top: 10px;
}

    .hero-badge {
        display: inline-block;
        padding: 5px 16px;
        background: rgba(255,255,255,.12);
        border: 1px solid rgba(255,255,255,.22);
        border-radius: 999px;
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 1.3px;
        text-transform: uppercase;
        margin-bottom: 18px;
        backdrop-filter: blur(8px);
    }

    .hero-title {
        font-size: 44px;
        font-weight: 800;
        line-height: 1.1;
        letter-spacing: -1.2px;
        margin-bottom: 14px;
    }

    @media (max-width: 768px) {
        .hero-title { font-size: 30px; }
    }

    .hero-desc {
        font-size: 15px;
        line-height: 1.65;
        opacity: .8;
        margin-bottom: 20px;
        max-width: 440px;
    }

    .hero-price {
        font-size: 13px;
        opacity: .75;
        margin-bottom: 26px;
    }

    .hero-price strong {
        font-size: 26px;
        font-weight: 800;
        opacity: 1;
        color: #fff;
    }

    .hero-actions {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
    }

    .hero-btn {
        padding: 13px 28px;
        border-radius: 999px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        border: none;
        text-decoration: none;
        transition: opacity .2s, transform .2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .hero-btn-primary {
        background: #ffffff;
        color: #1a1c1d;
    }

    .hero-btn-primary:hover {
        opacity: .9;
        transform: translateY(-2px);
        color: #1a1c1d;
    }

    .hero-btn-ghost {
        background: rgba(255,255,255,.12);
        color: #fff;
        border: 1px solid rgba(255,255,255,.28);
    }

    .hero-btn-ghost:hover {
        background: rgba(255,255,255,.22);
        color: #fff;
    }

    .hero-dots {
        position: absolute;
        bottom: 28px;
        left: 6%;
        z-index: 10;
        display: flex;
        gap: 6px;
    }

    .hero-dot {
        height: 4px;
        width: 16px;
        border-radius: 999px;
        background: rgba(255,255,255,.35);
        border: none;
        cursor: pointer;
        transition: width .3s, background .3s;
        padding: 0;
    }

    .hero-dot.active {
        width: 36px;
        background: #fff;
    }

    .hero-arrows {
        position: absolute;
        bottom: 22px;
        right: 28px;
        z-index: 10;
        display: flex;
        gap: 8px;
    }

    .hero-arrow {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: rgba(255,255,255,.12);
        border: 1px solid rgba(255,255,255,.22);
        color: #fff;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background .2s;
        backdrop-filter: blur(8px);
    }

    .hero-arrow:hover {
        background: rgba(255,255,255,.28);
    }

    .hero-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background: rgba(255,255,255,.45);
        z-index: 20;
        width: 0%;
    }

    .hero-empty {
        height: 120px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-muted, #717785);
        font-size: 14px;
    }
</style>
@endpush

@push('scripts')
<script>
(function () {
    const slides     = document.querySelectorAll('.hero-slide');
    const dots       = document.querySelectorAll('.hero-dot');
    const progressEl = document.getElementById('heroProgress');
    const prevBtn    = document.getElementById('heroPrev');
    const nextBtn    = document.getElementById('heroNext');

    if (!slides.length) return;

    let current = 0;
    let autoTimer, progTimer;
    const INTERVAL = 5000; // ms ndërmjet slides

    function goTo(n) {
        slides[current].classList.remove('active');
        slides[current].classList.add('exit');

        const exitIndex = current;
        setTimeout(() => slides[exitIndex].classList.remove('exit'), 600);

        current = (n + slides.length) % slides.length;
        slides[current].classList.add('active');

        dots.forEach((d, i) => d.classList.toggle('active', i === current));
        resetProgress();
    }

    function resetProgress() {
        clearTimeout(autoTimer);
        clearTimeout(progTimer);

        if (progressEl) {
            progressEl.style.transition = 'none';
            progressEl.style.width = '0%';
        }

        progTimer = setTimeout(() => {
            if (progressEl) {
                progressEl.style.transition = 'width ' + INTERVAL + 'ms linear';
                progressEl.style.width = '100%';
            }
        }, 60);

        autoTimer = setTimeout(() => goTo(current + 1), INTERVAL + 100);
    }

    // Dot clicks
    dots.forEach((dot, i) => dot.addEventListener('click', () => goTo(i)));

    // Arrow clicks
    if (prevBtn) prevBtn.addEventListener('click', () => goTo(current - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => goTo(current + 1));

    // Swipe support (mobile)
    let touchStartX = 0;
    const carousel = document.getElementById('heroCarousel');
    if (carousel) {
        carousel.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
        carousel.addEventListener('touchend',   e => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
        });
    }

    // Start
    if (slides.length > 1) resetProgress();
})();
</script>
@endpush