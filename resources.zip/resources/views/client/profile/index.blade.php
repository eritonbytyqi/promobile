@extends('client.layout')

@section('title', 'Profili im – ProMobile')

@push('styles')
<style>
    .profile-page {
        max-width: 1100px;
        margin: 0 auto;
        padding: 40px 24px;
        display: grid;
        grid-template-columns: 1fr 340px;
        gap: 24px;
        align-items: start;
    }

    /* ── LEFT COLUMN ── */
    .profile-left { display: flex; flex-direction: column; gap: 0; }

    .profile-header {
        display: flex; align-items: center; gap: 16px; margin-bottom: 24px;
    }
    .profile-avatar {
        width: 56px; height: 56px; border-radius: 50%;
        background: var(--primary-fixed);
        display: flex; align-items: center; justify-content: center;
        font-size: 22px; font-weight: 800; color: var(--primary); flex-shrink: 0;
    }
    .profile-name  { font-size: 20px; font-weight: 800; color: var(--text); letter-spacing: -0.4px; }
    .profile-email { font-size: 13px; color: var(--text-muted); margin-top: 2px; }

    .profile-card {
        background: var(--surface);
        border: 1px solid var(--border-solid);
        border-radius: var(--radius-2xl);
        padding: 1.5rem 1.75rem;
        margin-bottom: 1rem;
    }
    .profile-card-title {
        font-size: 13px; font-weight: 700; color: var(--text);
        margin-bottom: 1.1rem; display: flex; align-items: center; gap: 7px;
    }
    .profile-card-title .material-symbols-outlined { font-size: 17px; color: var(--primary); }

    .profile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .profile-field { display: flex; flex-direction: column; gap: 5px; }
    .profile-field.full { grid-column: 1 / -1; }
    .profile-field label { font-size: 11.5px; font-weight: 600; color: var(--text-soft); }
    .profile-field input {
        padding: 10px 13px; font-size: 13.5px; font-family: 'Inter', sans-serif;
        border: 1.5px solid var(--border-solid); border-radius: 11px;
        background: var(--surface); color: var(--text); outline: none;
        transition: border-color 0.2s, box-shadow 0.2s; width: 100%;
    }
    .profile-field input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(0,89,181,0.1); }
    .profile-field input::placeholder { color: var(--text-muted); }
    .field-error { font-size: 11px; color: var(--error); }

    .profile-divider { height: 1px; background: var(--border-solid); margin: 1.25rem 0; }

    .profile-btn {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 12px 28px; background: var(--text); color: #fff; border: none;
        border-radius: var(--radius-full); font-family: 'Inter', sans-serif;
        font-size: 14px; font-weight: 700; cursor: pointer;
        transition: opacity 0.2s, transform 0.2s; margin-top: 0.25rem;
        width: 100%; justify-content: center;
    }
    .profile-btn:hover { opacity: 0.85; transform: translateY(-1px); }
    .profile-btn-outline {
        background: transparent; color: var(--error);
        border: 1.5px solid #ffb4ab;
    }
    .profile-btn-outline:hover { background: var(--error-bg); transform: none; opacity: 1; }

    .alert-success {
        display: flex; align-items: center; gap: 10px;
        background: var(--success-bg); border: 1px solid #a3e0be; color: var(--success);
        padding: 11px 14px; border-radius: 11px; font-size: 13px; font-weight: 500; margin-bottom: 1rem;
    }
    .alert-error {
        display: flex; align-items: center; gap: 10px;
        background: var(--error-bg); border: 1px solid #ffb4ab; color: var(--error);
        padding: 11px 14px; border-radius: 11px; font-size: 13px; font-weight: 500; margin-bottom: 1rem;
    }

    /* ── RIGHT COLUMN (Orders sidebar) ── */
   /* GJEJ këtë */
.orders-sidebar {
    background: var(--surface);
    border: 1px solid var(--border-solid);
    border-radius: var(--radius-2xl);
    overflow: hidden;
    position: sticky;
    top: 80px;
}

.orders-sidebar-body {
    max-height: 520px;
    overflow-y: auto;
    scrollbar-width: thin;
}

/* ZËVENDËSO me këtë */
.orders-sidebar {
    background: var(--surface);
    border: 1px solid var(--border-solid);
    border-radius: var(--radius-2xl);
    overflow: hidden;
    position: sticky;
    top: 80px;
    max-height: calc(100vh - 100px);
    display: flex;
    flex-direction: column;
}

.orders-sidebar-body {
    flex: 1;
    overflow-y: auto;
    scrollbar-width: thin;
}
    .orders-sidebar-body::-webkit-scrollbar { width: 4px; }
    .orders-sidebar-body::-webkit-scrollbar-thumb { background: var(--border-solid); border-radius: 4px; }

    .order-item {
        padding: 13px 1.4rem;
        border-bottom: 1px solid var(--border-solid);
        transition: background 0.15s;
    }
    .order-item:last-child { border-bottom: none; }
    .order-item:hover { background: var(--surface-low); }

    .order-item-top {
        display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;
    }
    .order-id   { font-size: 13px; font-weight: 700; color: var(--text); }
    .order-total { font-size: 13px; font-weight: 700; color: var(--primary); }

    .order-item-bot {
        display: flex; align-items: center; justify-content: space-between;
    }
    .order-date { font-size: 11px; color: var(--text-muted); }

    .order-badge {
        display: inline-flex; padding: 2px 9px; border-radius: 999px;
        font-size: 10px; font-weight: 700; white-space: nowrap;
    }
    .badge-pending   { background: #faeeda; color: #854f0b; }
    .badge-confirmed { background: var(--primary-fixed); color: var(--primary); }
    .badge-delivered { background: var(--success-bg); color: var(--success); }
    .badge-cancelled { background: var(--error-bg); color: var(--error); }

    .orders-empty {
        text-align: center; padding: 40px 20px; color: var(--text-muted); font-size: 13px;
    }

    /* ── MOBILE ── */
    @media (max-width: 768px) {
        .profile-page {
            grid-template-columns: 1fr;
            padding: 20px 16px;
            gap: 16px;
        }
        .orders-sidebar { position: static; }
        .profile-grid { grid-template-columns: 1fr; }
        .profile-field.full { grid-column: 1; }
    }
</style>
@endpush

@section('content')
<div class="profile-page">

    {{-- ── LEFT: Forma ── --}}
    <div class="profile-left">

        <div class="profile-header">
            <div class="profile-avatar">{{ strtoupper(substr($user->name, 0, 1)) }}</div>
            <div>
                <div class="profile-name">{{ $user->name }} {{ $user->surname }}</div>
                <div class="profile-email">{{ $user->email }}</div>
            </div>
        </div>

        @if(session('success'))
            <div class="alert-success">
                <span class="material-symbols-outlined" style="font-size:17px;">check_circle</span>
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="alert-error">
                <span class="material-symbols-outlined" style="font-size:17px;">error</span>
                {{ session('error') }}
            </div>
        @endif

        {{-- Forma kryesore --}}
        <form method="POST" action="{{ route('profile.update') }}">
            @csrf

            {{-- Të dhënat personale --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">person</span> Të dhënat personale
                </div>
                <div class="profile-grid">
                    <div class="profile-field">
                        <label>Emri</label>
                        <input type="text" name="name" placeholder="Emri" value="{{ old('name', $user->name) }}" required />
                        @error('name')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Mbiemri</label>
                        <input type="text" name="surname" placeholder="Mbiemri" value="{{ old('surname', $user->surname ?? '') }}" />
                    </div>
                    <div class="profile-field full">
                        <label>Telefoni</label>
                        <input type="text" name="phone" placeholder="+383 4X XXX XXX" value="{{ old('phone', $user->phone ?? '') }}" />
                    </div>
                </div>
            </div>

            {{-- Adresa --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">location_on</span> Adresa e dorëzimit
                </div>
                <div class="profile-grid">
                    <div class="profile-field full">
                        <label>Adresa</label>
                        <input type="text" name="address_line_1" placeholder="Rr. Nënë Tereza, Nr. 10" value="{{ old('address_line_1', $address->address_line_1 ?? '') }}" />
                    </div>
                    <div class="profile-field">
                        <label>Qyteti</label>
                        <input type="text" name="city" placeholder="Prishtinë" value="{{ old('city', $address->city ?? '') }}" />
                    </div>
                    <div class="profile-field">
                        <label>Kodi Postar</label>
                        <input type="text" name="postal_code" placeholder="10000" value="{{ old('postal_code', $address->postal_code ?? '') }}" />
                    </div>
                    <div class="profile-field full">
                        <label>Shteti</label>
                        <input type="text" name="country" placeholder="Kosovë" value="{{ old('country', $address->country ?? 'Kosovë') }}" />
                    </div>
                </div>
            </div>

            {{-- Ndrysho passwordin (brenda së njëjtës formë) --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">lock</span> Ndrysho fjalëkalimin
                </div>
                <div class="profile-grid">
                    <div class="profile-field full">
                        <label>Fjalëkalimi aktual</label>
                        <input type="password" name="current_password" placeholder="••••••••" />
                        @error('current_password')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Fjalëkalimi i ri</label>
                        <input type="password" name="password" placeholder="••••••••" />
                        @error('password')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Përsërit fjalëkalimin</label>
                        <input type="password" name="password_confirmation" placeholder="••••••••" />
                    </div>
                </div>
                <p style="font-size:11.5px; color:var(--text-muted); margin-top:10px;">
                    Lëre bosh nëse nuk dëshiron të ndryshosh fjalëkalimin.
                </p>
            </div>

            <button type="submit" class="profile-btn">
                <span class="material-symbols-outlined" style="font-size:18px;">save</span>
                Ruaj ndryshimet
            </button>
        </form>

    </div>

    {{-- ── RIGHT: Orders sidebar ── --}}
    <div class="orders-sidebar">
        <div class="orders-sidebar-header">
            <div class="orders-sidebar-title">
                <span class="material-symbols-outlined">shopping_bag</span>
                Porositë e mia
            </div>
            @if(isset($orders) && $orders->count() > 0)
                <span class="orders-count-badge">{{ $orders->count() }}</span>
            @endif
        </div>

        <div class="orders-sidebar-body">
            @if(isset($orders) && $orders->count() > 0)
                @foreach($orders as $order)
                    <div class="order-item">
                        <div class="order-item-top">
                            <span class="order-id">#{{ $order->id }}</span>
                            <span class="order-total">{{ number_format($order->total_amount, 2) }} €</span>
                        </div>
                        <div class="order-item-bot">
                            <span class="order-date">{{ $order->created_at->format('d M Y') }}</span>
                            <span class="order-badge badge-{{ $order->status ?? 'pending' }}">
                                {{ match($order->status ?? 'pending') {
                                    'pending'   => 'Në pritje',
                                    'confirmed' => 'Konfirmuar',
                                    'delivered' => 'Dorëzuar',
                                    'cancelled' => 'Anuluar',
                                    default     => ucfirst($order->status)
                                } }}
                            </span>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="orders-empty">
                    <span class="material-symbols-outlined" style="font-size:36px; display:block; margin-bottom:8px; color:var(--text-muted);">shopping_bag</span>
                    Nuk keni asnjë porosi ende.
                </div>
            @endif
        </div>
    </div>

</div>
@endsection