    @extends('layouts.app')

    @section('title', 'Produktet')
    @section('page-title', 'Produktet')

    @section('breadcrumb')
        <a href="{{ url('/') }}">Dashboard</a>
        <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
        <span>Produktet</span>
    @endsection

    @push('head')
    @push('styles')
<style>
/* ══ LIGHT MODE OVERRIDE ══ */
:root {
    --bg:        #f5f5f7;
    --surface:   #ffffff;
    --surface2:  #f0f0f5;
    --border:    rgba(0,0,0,0.08);
    --border-h:  rgba(0,0,0,0.15);
    --text:      #1d1d1f;
    --text-muted:#8e8e93;
    --accent:    #e63946;
    --accent2:   #c9860a;
    --accent3:   #1a7a4a;
    --grad:      linear-gradient(135deg,#e63946 0%,#c1121f 100%);
    --grad2:     linear-gradient(135deg,#f5c518 0%,#e0a800 100%);
}

body, .main, .page-content { background:#f5f5f7 !important; color:#1d1d1f !important; }

/* Sidebar */
.sidebar { background:#ffffff !important; border-right:1px solid rgba(0,0,0,0.08) !important; }
.sidebar-nav a { color:#6e6e73 !important; }
.sidebar-nav a:hover { background:#f5f5f7 !important; color:#1d1d1f !important; }
.sidebar-nav a.active { background:rgba(124,111,255,0.1) !important; color:#7c6fff !important; }
.sidebar-nav a.active i { color:#7c6fff !important; }
.sidebar-label { color:#aeaeb2 !important; }
.sidebar-logo-text { color:#1d1d1f !important; }
.sidebar-footer a { color:#aeaeb2 !important; }

/* Topbar */
.topbar { background:rgba(255,255,255,0.9) !important; border-bottom:1px solid rgba(0,0,0,0.08) !important; }
.topbar-breadcrumb, .topbar-breadcrumb a { color:#8e8e93 !important; }
.topbar-breadcrumb span { color:#6e6e73 !important; }
.topbar-page-title { color:#1d1d1f !important; }
.topbar-icon-btn, .topbar-hamburger {
    background:#ffffff !important;
    border-color:rgba(0,0,0,0.1) !important;
    color:#6e6e73 !important;
}

/* Page */
.page-wrap { background:#f5f5f7; }
.breadcrumb-row a { color:#8e8e93 !important; }
.breadcrumb-row span { color:#6e6e73 !important; }
.page-title { color:#1d1d1f !important; }
.page-title span { color:#e63946 !important; }

/* Stat cards */
.stat-card {
    background:#ffffff !important;
    border-color:rgba(0,0,0,0.08) !important;
}
.stat-card:hover { box-shadow:0 8px 24px rgba(0,0,0,0.08); }
.stat-card::after { opacity:0.15; }
.stat-value { color:#1d1d1f !important; }
.stat-label { color:#1d1d1f !important; }
.stat-sub   { color:#8e8e93 !important; }
.stat-card.red    .stat-icon { background:rgba(230,57,70,0.1)  !important; }
.stat-card.gold   .stat-icon { background:rgba(245,197,24,0.1) !important; }
.stat-card.teal   .stat-icon { background:rgba(0,212,170,0.1)  !important; color:#1a7a4a !important; }
.stat-card.purple .stat-icon { background:rgba(124,58,237,0.1) !important; }

/* Cards */
.card { background:#ffffff !important; border-color:rgba(0,0,0,0.08) !important; }
.card-header { border-bottom-color:rgba(0,0,0,0.06) !important; }
.card-title { color:#1d1d1f !important; }

/* Featured cards */
.feat-card { background:#f9f9fb !important; border-color:rgba(0,0,0,0.08) !important; }
.feat-card:hover { box-shadow:0 16px 40px rgba(0,0,0,0.12) !important; }
.feat-img { background:#f0f0f5 !important; }
.feat-meta { color:#8e8e93 !important; }
.feat-name { color:#1d1d1f !important; }
.feat-price { color:#e63946 !important; }

/* Search */
.search-wrap input {
    background:#f5f5f7 !important;
    border-color:rgba(0,0,0,0.1) !important;
    color:#1d1d1f !important;
}
.search-wrap input::placeholder { color:#aeaeb2 !important; }
.search-wrap i { color:#8e8e93 !important; }

/* Buttons */
.btn-ghost {
    color:#6e6e73 !important;
    border-color:rgba(0,0,0,0.1) !important;
    background:transparent !important;
}
.btn-ghost:hover {
    background:#f5f5f7 !important;
    border-color:rgba(0,0,0,0.2) !important;
    color:#1d1d1f !important;
}
.btn-danger {
    background:rgba(230,57,70,0.08) !important;
    border-color:rgba(230,57,70,0.2) !important;
    color:#e63946 !important;
}
.btn-danger:hover { background:rgba(230,57,70,0.15) !important; }

/* Table */
thead tr { background:#f9f9fb !important; }
thead th { color:#aeaeb2 !important; }
tbody tr { border-bottom-color:rgba(0,0,0,0.05) !important; }
tbody tr:hover { background:#fafafa !important; }
tbody td { color:#6e6e73 !important; }

.thumb { background:#f5f5f7 !important; border-color:rgba(0,0,0,0.08) !important; color:#aeaeb2 !important; }
.prod-name { color:#1d1d1f !important; }
.prod-sku  { color:#8e8e93 !important; }
.price { color:#e63946 !important; }

/* Badges */
.badge-success { background:rgba(26,122,74,0.1) !important; color:#1a7a4a !important; border-color:rgba(26,122,74,0.2) !important; }
.badge-warning { background:rgba(201,134,10,0.1) !important; color:#c9860a !important; border-color:rgba(201,134,10,0.2) !important; }
.badge-danger  { background:rgba(230,57,70,0.1)  !important; color:#e63946 !important; border-color:rgba(230,57,70,0.2) !important; }
.badge-muted   { background:rgba(0,0,0,0.04) !important; color:#8e8e93 !important; border-color:rgba(0,0,0,0.08) !important; }

.star-yes { color:#c9860a !important; }
.star-no  { color:#d1d1d6 !important; }

/* Empty state */
.empty-state { color:#8e8e93 !important; }
.empty-icon { background:#f5f5f7 !important; border-color:rgba(0,0,0,0.08) !important; }
.empty-state h3 { color:#1d1d1f !important; }

/* Pagination */
.pag-btn { color:#6e6e73 !important; border-color:rgba(0,0,0,0.1) !important; background:#ffffff !important; }
.pag-btn:hover { background:#f5f5f7 !important; border-color:rgba(0,0,0,0.2) !important; color:#1d1d1f !important; }
.pag-active { background:linear-gradient(135deg,#e63946,#c1121f) !important; color:#fff !important; border-color:transparent !important; }
.pag-disabled { opacity:0.3 !important; }
.pag-info { color:#8e8e93 !important; }
.pagination-wrap { border-top-color:rgba(0,0,0,0.06) !important; }

/* Mobile cards */
.mobile-product-card { border-bottom-color:rgba(0,0,0,0.06) !important; }
.mobile-product-card:hover { background:#fafafa !important; }
.mobile-thumb { background:#f5f5f7 !important; border-color:rgba(0,0,0,0.08) !important; color:#aeaeb2 !important; }
.mobile-name  { color:#1d1d1f !important; }
.mobile-meta  { color:#8e8e93 !important; }
.mobile-price { color:#e63946 !important; }

/* Checkbox */
input[type="checkbox"] { accent-color:#e63946; }

/* Section icons */
.section-icon { opacity:0.9; }
</style>
@endpush
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    @endpush

    @push('styles')
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

    :root {
        --bg:        #0d0d12;
        --surface:   #13131a;
        --surface2:  #1a1a24;
        --border:    rgba(255,255,255,0.07);
        --border-h:  rgba(255,255,255,0.15);
        --text:      #f0f0f5;
        --text-muted:#6b6b80;
        --accent:    #e63946;
        --accent2:   #f5c518;
        --accent3:   #00d4aa;
        --grad:      linear-gradient(135deg, #e63946 0%, #c1121f 100%);
        --grad2:     linear-gradient(135deg, #f5c518 0%, #e0a800 100%);
        --grad3:     linear-gradient(135deg, #00d4aa 0%, #008f72 100%);
        --grad4:     linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%);
        --shadow:    0 8px 32px rgba(0,0,0,0.4);
        --radius:    14px;
        --radius-sm: 8px;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        background: var(--bg);
        color: var(--text);
        font-family: 'DM Sans', sans-serif;
        font-size: 14px;
        line-height: 1.6;
    }

    /* ── PAGE WRAPPER ── */
    .page-wrap { padding: 32px; max-width: 1440px; margin: 0 auto; }

    /* ── PAGE HEADER ── */
    .page-header {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        margin-bottom: 32px;
        gap: 16px;
    }
    .page-header-left {}
    .breadcrumb-row {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        color: var(--text-muted);
        margin-bottom: 8px;
        letter-spacing: 0.5px;
    }
    .breadcrumb-row a { color: var(--text-muted); text-decoration: none; transition: color .2s; }
    .breadcrumb-row a:hover { color: var(--accent); }
    .breadcrumb-row i { font-size: 8px; }
    .page-title {
    font-family: 'Inter', sans-serif;
        font-size: 36px;
        font-weight: 800;
        letter-spacing: -1px;
        line-height: 1;
        color: var(--text);
    }
    .page-title span { color: var(--accent); }

    /* ── BUTTONS ── */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 9px 18px;
        border-radius: var(--radius-sm);
        font-family: 'DM Sans', sans-serif;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        border: none;
        text-decoration: none;
        transition: all .2s;
        white-space: nowrap;
    }
    .btn-primary {
        background: var(--grad);
        color: #fff;
        box-shadow: 0 4px 16px rgba(230,57,70,0.35);
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(230,57,70,0.45); }
    .btn-ghost {
        background: transparent;
        color: var(--text-muted);
        border: 1px solid var(--border);
    }
    .btn-ghost:hover { border-color: var(--border-h); color: var(--text); background: var(--surface2); }
    .btn-danger {
        background: rgba(230,57,70,0.12);
        color: var(--accent);
        border: 1px solid rgba(230,57,70,0.2);
    }
    .btn-danger:hover { background: rgba(230,57,70,0.22); border-color: var(--accent); }
    .btn-sm { padding: 6px 10px; font-size: 12px; border-radius: 6px; }
    .btn-icon { padding: 7px 9px; }

    /* ── STAT CARDS ── */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 28px;
    }
    .stat-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 22px 24px;
        position: relative;
        overflow: hidden;
        transition: transform .2s, border-color .2s;
    }
    .stat-card:hover { transform: translateY(-3px); border-color: var(--border-h); }
    .stat-card::before {
        content: '';
        position: absolute;
        inset: 0;
        opacity: 0.06;
        pointer-events: none;
    }
    .stat-card::after {
        content: '';
        position: absolute;
        top: -30px; right: -30px;
        width: 100px; height: 100px;
        border-radius: 50%;
        filter: blur(30px);
        opacity: 0.25;
        pointer-events: none;
    }
    .stat-card.red::after  { background: var(--accent); }
    .stat-card.gold::after { background: var(--accent2); }
    .stat-card.teal::after { background: var(--accent3); }
    .stat-card.purple::after { background: #7c3aed; }
    .stat-card.red   { border-top: 2px solid var(--accent); }
    .stat-card.gold  { border-top: 2px solid var(--accent2); }
    .stat-card.teal  { border-top: 2px solid var(--accent3); }
    .stat-card.purple{ border-top: 2px solid #7c3aed; }

    .stat-icon {
        width: 38px; height: 38px;
        border-radius: 9px;
        display: flex; align-items: center; justify-content: center;
        font-size: 16px;
        margin-bottom: 14px;
    }
    .stat-card.red   .stat-icon { background: rgba(230,57,70,0.15);  color: var(--accent);  }
    .stat-card.gold  .stat-icon { background: rgba(245,197,24,0.15); color: var(--accent2); }
    .stat-card.teal  .stat-icon { background: rgba(0,212,170,0.15);  color: var(--accent3); }
    .stat-card.purple .stat-icon { background: rgba(124,58,237,0.15);color: #7c3aed; }

.stat-value {
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: -0.5px;
    color: var(--text);
    margin-bottom: 4px;
}
    .stat-label { font-size: 13px; font-weight: 500; color: var(--text); margin-bottom: 2px; }
    .stat-sub   { font-size: 11px; color: var(--text-muted); }

    /* ── CARDS ── */
    .card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        overflow: hidden;
        margin-bottom: 24px;
    }
    .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 18px 24px;
        border-bottom: 1px solid var(--border);
        gap: 16px;
        flex-wrap: wrap;
    }
    .card-header-left { display: flex; align-items: center; gap: 10px; }
 .card-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--text);
    letter-spacing: -0.2px;
}
    .section-icon {
        width: 32px; height: 32px;
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px;
    }

    /* ── FEATURED GRID ── */
    .featured-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
        gap: 16px;
        padding: 20px 24px;
    }
    .feat-card {
        background: var(--surface2);
        border: 1px solid var(--border);
        border-radius: 12px;
        overflow: hidden;
        transition: transform .25s, border-color .25s, box-shadow .25s;
        cursor: pointer;
    }
    .feat-card:hover {
        transform: translateY(-5px);
        border-color: var(--accent2);
        box-shadow: 0 16px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(245,197,24,0.15);
    }
    .feat-img {
        height: 150px;
        background: var(--bg);
        display: flex; align-items: center; justify-content: center;
        position: relative;
        overflow: hidden;
    }
    .feat-img img { width:100%;height:100%;object-fit:cover; transition: transform .4s; }
    .feat-card:hover .feat-img img { transform: scale(1.06); }
    .feat-img .no-img { font-size: 36px; color: var(--border); }
    .feat-badge {
        position: absolute; top: 8px; right: 8px;
        background: var(--grad2);
        color: #0a0a0f;
        font-size: 9px; font-weight: 800;
        padding: 3px 8px;
        border-radius: 20px;
        letter-spacing: 0.8px;
        display: flex; align-items: center; gap: 4px;
    }
    .feat-body { padding: 14px; }
    .feat-meta {
        font-size: 10px;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin-bottom: 6px;
    }
    .feat-name {
    font-family: 'Inter', sans-serif;
        font-size: 14px; font-weight: 700;
        color: var(--text);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        margin-bottom: 12px;
    }
    .feat-footer { display: flex; align-items: center; justify-content: space-between; }
    .feat-price {
    font-family: 'Inter', sans-serif;
        font-size: 20px; font-weight: 800;
        color: var(--accent);
        letter-spacing: -0.5px;
    }

    /* ── SEARCH BAR ── */
    .search-wrap {
        position: relative;
        min-width: 240px;
    }
    .search-wrap i {
        position: absolute;
        left: 12px; top: 50%;
        transform: translateY(-50%);
        color: var(--text-muted);
        font-size: 13px;
        pointer-events: none;
    }
    .search-wrap input {
        width: 100%;
        background: var(--surface2);
        border: 1px solid var(--border);
        border-radius: 8px;
        color: var(--text);
        font-family: 'DM Sans', sans-serif;
        font-size: 13px;
        padding: 8px 12px 8px 36px;
        outline: none;
        transition: border-color .2s, box-shadow .2s;
    }
    .search-wrap input::placeholder { color: var(--text-muted); }
    .search-wrap input:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(230,57,70,0.12);
    }

    /* ── TABLE ── */
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    thead tr {
        background: var(--surface2);
        border-bottom: 1px solid var(--border);
    }
    th {
        padding: 11px 16px;
    font-family: 'Inter', sans-serif;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: var(--text-muted);
        text-align: left;
        white-space: nowrap;
    }
    tbody tr {
        border-bottom: 1px solid var(--border);
        transition: background .15s;
    }
    tbody tr:last-child { border-bottom: none; }
    tbody tr:hover { background: rgba(255,255,255,0.025); }
    td { padding: 13px 16px; vertical-align: middle; }

    /* ── THUMB ── */
    .thumb {
        width: 44px; height: 44px;
        border-radius: 8px;
        overflow: hidden;
        background: var(--surface2);
        border: 1px solid var(--border);
        display: flex; align-items: center; justify-content: center;
        color: var(--text-muted);
        font-size: 16px;
        flex-shrink: 0;
    }
    .thumb img { width:100%;height:100%;object-fit:cover; }

    /* ── PRODUCT NAME CELL ── */
    .prod-name { font-weight: 600; font-size: 14px; color: var(--text); }
    .prod-sku  { font-size: 11px; color: var(--text-muted); margin-top: 2px; font-family: monospace; letter-spacing: 0.5px; }

    /* ── PRICE ── */
.price {
    font-size: 14px;
    font-weight: 700;
    color: var(--text);
}

.feat-price {
    font-size: 15px;
    font-weight: 700;
    color: var(--text);
    letter-spacing: 0;
}
    /* ── BADGES ── */
    .badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    .badge-success { background: rgba(0,212,170,0.12); color: var(--accent3); border: 1px solid rgba(0,212,170,0.2); }
    .badge-warning { background: rgba(245,197,24,0.12); color: var(--accent2); border: 1px solid rgba(245,197,24,0.2); }
    .badge-danger  { background: rgba(230,57,70,0.12);  color: var(--accent);  border: 1px solid rgba(230,57,70,0.2); }
    .badge-muted   { background: rgba(255,255,255,0.05); color: var(--text-muted); border: 1px solid var(--border); }

    /* ── STAR ── */
    .star-yes { color: var(--accent2); font-size: 15px; }
    .star-no  { color: var(--border);  font-size: 15px; }

    /* ── EMPTY STATE ── */
    .empty-state {
        text-align: center;
        padding: 64px 24px;
        color: var(--text-muted);
    }
    .empty-icon {
        width: 64px; height: 64px;
        border-radius: 16px;
        background: var(--surface2);
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 28px;
        margin-bottom: 16px;
        border: 1px solid var(--border);
    }
    .empty-state h3 {     font-family: 'Inter', sans-serif;
 font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 6px; }
    .empty-state p  { font-size: 13px; margin-bottom: 20px; }
    .empty-state a  { color: var(--accent); text-decoration: none; font-weight: 600; }

    /* ── PAGINATION ── */
    .pagination-wrap {
        padding: 16px 24px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: center;
        align-items: center;
    }
    /* Hide "Showing X to Y of Z" text & old Previous/Next text row */
    .pagination-wrap nav > div:first-child,
    .pagination-wrap nav > p { display: none !important; }

    .pagination-wrap nav {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .pagination-wrap nav a,
    .pagination-wrap nav button {
        display: inline-flex; align-items: center; justify-content: center;
        min-width: 36px; height: 36px;
        border-radius: 8px;
        font-size: 13px;
        font-family: 'DM Sans', sans-serif;
        padding: 0 10px;
        text-decoration: none;
        cursor: pointer;
        transition: all .2s;
        color: var(--text-muted);
        border: 1px solid var(--border);
        background: transparent;
    }
    .pagination-wrap nav a:hover,
    .pagination-wrap nav button:hover {
        color: var(--text);
        border-color: var(--border-h);
        background: var(--surface2);
    }
    .pagination-wrap nav span[aria-current="page"] > span {
        display: inline-flex; align-items: center; justify-content: center;
        min-width: 36px; height: 36px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 700;
        padding: 0 10px;
        background: var(--grad);
        color: #fff;
        border: none;
    }
    .pagination-wrap nav span:not([aria-current]) > span {
        display: inline-flex; align-items: center; justify-content: center;
        min-width: 36px; height: 36px;
        border-radius: 8px;
        font-size: 13px;
        color: var(--text-muted);
        border: 1px solid var(--border);
    }

    /* ── Custom pagination buttons ── */
    .pag-inner {
        display: flex; align-items: center; gap: 4px; flex-wrap: wrap; justify-content: center;
        margin-bottom: 6px;
    }
    .pag-info {
        text-align: center;
        font-size: 12px;
        color: var(--text-muted);
    }
    .pag-btn {
        display: inline-flex; align-items: center; justify-content: center;
        min-width: 36px; height: 36px;
        border-radius: 8px;
        font-size: 13px;
        font-family: 'DM Sans', sans-serif;
        padding: 0 10px;
        text-decoration: none;
        cursor: pointer;
        transition: all .2s;
        color: var(--text-muted);
        border: 1px solid var(--border);
        background: transparent;
    }
    .pag-btn:hover { color: var(--text); border-color: var(--border-h); background: var(--surface2); }
    .pag-active {
        background: var(--grad) !important;
        color: #fff !important;
        border-color: transparent !important;
        font-weight: 700;
        cursor: default;
    }
    .pag-disabled { opacity: 0.35; cursor: not-allowed; pointer-events: none; }
    .pag-dots { border-color: transparent; cursor: default; }
    .pag-dots:hover { background: transparent; border-color: transparent; color: var(--text-muted); }

    .pagination-wrap { flex-direction: column; gap: 6px; }

    /* ── ACTIONS COL ── */
    .actions { display: flex; gap: 6px; align-items: center; }

    /* ══════════════════════════════════════
        RESPONSIVE
    ══════════════════════════════════════ */

    /* ── Tablet: 1024px ── */
    /* ── MOBILE LIST (hidden by default on desktop, shown via media query) ── */
    /* NOTE: This rule is placed BEFORE media queries intentionally */
    .mobile-list { display: none; }

    @media (max-width: 1024px) {
        .page-wrap { padding: 24px 20px; }
        .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 14px; }
        .featured-grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }
    }

    /* ── Tablet narrow: 768px ── */
    @media (max-width: 768px) {
        .page-wrap { padding: 16px; }
      .page-title {
    font-size: 24px;
    font-weight: 800;
    letter-spacing: -0.5px;
    line-height: 1;
    color: var(--text);
}
        /* Header stacks */
        .page-header { flex-direction: column; align-items: flex-start; gap: 12px; margin-bottom: 20px; }
        .page-header .btn-primary { width: 100%; justify-content: center; }

        /* Card header stacks */
        .card-header { flex-direction: column; align-items: flex-start; gap: 12px; padding: 14px 16px; }
        .card-header > div:last-child { width: 100%; }
        .card-header > div:last-child .search-wrap { flex: 1; min-width: 0; }
        .card-header > div:last-child { display: flex; gap: 8px; }
        .search-wrap { min-width: 0; width: 100%; }

        /* Stats 2 col */
        .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 16px; }
        .stat-value { font-size: 32px; letter-spacing: -1.5px; }
        .stat-card { padding: 16px; }

        /* Featured scrollable row on mobile */
        .featured-grid {
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        padding: 14px 16px;
        gap: 12px;
        }

        /* TABLE → MOBILE CARDS */
        .table-wrap { display: none !important; }
        .mobile-list { display: block !important; }
    }

    /* ── Phone: 480px ── */
    @media (max-width: 480px) {
        .page-wrap { padding: 12px; }
        .page-title { font-size: 24px; letter-spacing: -0.5px; }
        .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
        .stat-value { font-size: 28px; }
        .stat-label { font-size: 12px; }
        .stat-sub   { display: none; }
        .stat-card  { padding: 14px 12px; }
        .card-header { padding: 12px; }
        .card-title  { font-size: 15px; }
        .featured-grid {
        grid-template-columns: repeat(2, 1fr);
        padding: 12px;
        gap: 10px;
        }
        .feat-img { height: 120px; }
    }

    /* ── Very small: 360px ── */
    @media (max-width: 360px) {
        .stats-grid { grid-template-columns: 1fr 1fr; }
        .featured-grid { grid-template-columns: 1fr; }
    }

    .mobile-product-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border-bottom: 1px solid var(--border);
        transition: background .15s;
    }
    .mobile-product-card:last-child { border-bottom: none; }
    .mobile-product-card:hover { background: rgba(255,255,255,0.02); }

    .mobile-thumb {
        width: 52px; height: 52px;
        border-radius: 10px;
        overflow: hidden;
        background: var(--surface2);
        border: 1px solid var(--border);
        display: flex; align-items: center; justify-content: center;
        color: var(--text-muted);
        font-size: 20px;
        flex-shrink: 0;
    }
    .mobile-thumb img { width:100%;height:100%;object-fit:cover; }

    .mobile-info { flex: 1; min-width: 0; }
    .mobile-name {
    font-family: 'Inter', sans-serif;
        font-size: 14px; font-weight: 700;
        color: var(--text);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        margin-bottom: 3px;
    }
    .mobile-meta {
        font-size: 11px; color: var(--text-muted);
        display: flex; align-items: center; gap: 6px; flex-wrap: wrap;
        margin-bottom: 6px;
    }
    .mobile-meta span { display: flex; align-items: center; gap: 3px; }
    .mobile-row {
        display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
    }
    .mobile-price {
            font-family: 'Inter', sans-serif;

        font-size: 16px; font-weight: 800;
        color: var(--accent);
        letter-spacing: -0.5px;
    }

    .mobile-actions {
        display: flex;
        flex-direction: column;
        gap: 5px;
        flex-shrink: 0;
    }
    .mobile-actions .btn { padding: 7px 9px; font-size: 12px; }
    </style>
    @endpush

    @section('content')
    <div class="page-wrap">

    {{-- PAGE HEADER --}}
    <div class="page-header">
        <div class="page-header-left">
            <div class="breadcrumb-row">
                <a href="{{ url('/') }}">Dashboard</a>
                <i class="fa-solid fa-chevron-right"></i>
                <span>Produktet</span>
            </div>
<h1 class="page-title">Produktet</h1>
        </div>
    
    </div>

    {{-- STATS --}}
    <div class="stats-grid">
        <div class="stat-card red">
            <div class="stat-icon"><i class="fa-solid fa-box"></i></div>
            <div class="stat-value">{{ $products->total() ?? $products->count() }}</div>
            <div class="stat-label">Totali i Produkteve</div>
            <div class="stat-sub">Produktë aktivë në sistem</div>
        </div>
       
        <div class="stat-card teal">
            <div class="stat-icon"><i class="fa-solid fa-tag"></i></div>
            <div class="stat-value">{{ $categories->count() ?? '—' }}</div>
            <div class="stat-label">Kategoritë</div>
            <div class="stat-sub">Kategori aktive</div>
        </div>
        <div class="stat-card purple">
            <div class="stat-icon"><i class="fa-solid fa-certificate"></i></div>
            <div class="stat-value">{{ $brands->count() ?? '—' }}</div>
            <div class="stat-label">Brendet</div>
            <div class="stat-sub">Brende të regjistruara</div>
        </div>
    </div>

    

    {{-- ALL PRODUCTS TABLE --}}
    <div class="card">
        <div class="card-header">
            <div class="card-header-left">
                <div class="section-icon" style="background:rgba(230,57,70,0.12);color:var(--accent);">
                    <i class="fa-solid fa-list"></i>
                </div>
                <span class="card-title">Të Gjithë Produktet</span>
            </div>
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <div class="search-wrap">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="searchInput" placeholder="Kërko produkt..." oninput="filterTable()">
        </div>

    <form id="bulkDeleteForm" action="{{ route('admin.products.bulk-delete') }}" method="POST" style="display:none;">
        @csrf
        @method('DELETE')
        <div id="selectedProductsContainer"></div>
    </form>

        <button type="button" class="btn btn-danger" id="bulkDeleteBtn" onclick="submitBulkDelete()" style="display:none;">
            <i class="fa-solid fa-trash"></i> Fshi të zgjedhurat
        </button>

        <a href="{{ url('/admin/products/create') }}" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Shto
        </a>
    </div>
        </div>

        <div class="table-wrap">
            <table id="productsTable">
                <thead>
                    <tr>
                        <th style="width:40px;">
                    <input type="checkbox" id="selectAll">
                        </th>
                        <th>#</th>
                        <th>Foto</th>
                        <th>Emri</th>
                        <th>Kategoria</th>
                        <th>Brendi</th>
                        <th>Çmimi</th>
                        <th>Stock</th>
                        <th>Statusi</th>
                        <th>Veprimet</th>
                    </tr>
                </thead>
            <tbody>
    @forelse($products as $product)
    <tr>
        {{-- CHECKBOX --}}
        <td>
            <input type="checkbox" class="row-check" value="{{ $product->id }}">
        </td>

        {{-- ID --}}
        <td style="color:var(--text-muted);font-size:12px;font-family:monospace;">
            #{{ $product->id }}
        </td>

        {{-- IMAGE --}}
        <td>
    <div class="thumb">
        @php $tImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first(); @endphp
        @if($tImg)
            <img src="{{ asset('storage/'.$tImg->image_path) }}">
        @else
            <i class="fa-solid fa-box"></i>
        @endif
    </div>
        </td>

        {{-- NAME --}}
    <td>
        <div class="prod-name">{{ $product->name }}</div>
        @if($product->variants && $product->variants->count() > 0)
            <div style="font-size:10px;color:var(--text-muted);margin-top:3px;">
                <i class="fa-solid fa-palette" style="font-size:9px;"></i>
                {{ $product->variants->unique('color_name')->count() }} ngjyra ·
                {{ $product->variants->count() }} variante
            </div>
        @endif
    </td>

        {{-- CATEGORY --}}
        <td>{{ $product->category->name ?? '—' }}</td>

        {{-- BRAND --}}
        <td>{{ $product->brand->name ?? '—' }}</td>

        {{-- PRICE --}}
        <td>
            <span class="price">{{ number_format($product->price, 2) }} €</span>
        </td>

        {{-- STOCK --}}
     <td>
    <a href="{{ url('/admin/stock?product='.$product->id) }}" style="text-decoration:none;">
        @if(($product->stock ?? 0) > 10)
            <span class="badge badge-success">{{ $product->stock }}</span>
        @elseif(($product->stock ?? 0) > 0)
            <span class="badge badge-warning">{{ $product->stock }}</span>
        @else
            <span class="badge badge-danger">Skadon</span>
        @endif
    </a>
</td>

   

        {{-- STATUS --}}
        <td>
            @if($product->is_active ?? true)
                <span class="badge badge-success">Aktiv</span>
            @else
                <span class="badge badge-muted">Joaktiv</span>
            @endif
        </td>

        {{-- ACTIONS --}}
        <td>
            <div class="actions">
                <a href="{{ url('/admin/products/'.$product->id) }}" class="btn btn-ghost btn-sm btn-icon">
                    <i class="fa-solid fa-eye"></i>
                </a>
                <a href="{{ url('/admin/products/'.$product->id.'/edit') }}" class="btn btn-ghost btn-sm btn-icon">
                    <i class="fa-solid fa-pen"></i>
                </a>
                <form action="{{ url('/admin/products/'.$product->id) }}" method="POST" onsubmit="return confirm('Fshi produktin?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-danger btn-sm btn-icon">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
            </div>
        </td>
    </tr>
    @empty
    <tr>
        {{-- ⚠️ FIX colspan --}}
        <td colspan="11">
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-box-open"></i></div>
                <h3>Nuk ka produkte ende</h3>
            </div>
        </td>
    </tr>
    @endforelse
    </tbody>
            </table>
        </div>

        {{-- MOBILE CARD LIST (visible on ≤768px) --}}
        <div class="mobile-list">
            @forelse($products as $product)
            <div class="mobile-product-card">
                {{-- Thumb --}}
            <div class="mobile-thumb">
        @php $mImg = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first(); @endphp
        @if($mImg)
            <img src="{{ asset('storage/'.$mImg->image_path) }}" alt="">
        @else
            <i class="fa-solid fa-box"></i>
        @endif
    </div>

                {{-- Info --}}
                <div class="mobile-info">
                    <div class="mobile-name">
                        @if($product->featured)
                            <i class="fa-solid fa-star" style="color:var(--accent2);font-size:10px;margin-right:4px;"></i>
                        @endif
                        {{ $product->name }}
                    </div>
                    <div class="mobile-meta">
                        <span><i class="fa-solid fa-tag" style="font-size:9px;"></i> {{ $product->category->name ?? '—' }}</span>
                        <span style="color:var(--border);">·</span>
                        <span>{{ $product->brand->name ?? '—' }}</span>
                    </div>
                    <div class="mobile-row">
                        <span class="mobile-price">{{ number_format($product->price, 2) }} €</span>
                        @if(($product->stock ?? 0) > 10)
                            <span class="badge badge-success" style="font-size:10px;padding:2px 7px;">
                                <i class="fa-solid fa-circle" style="font-size:5px;"></i> {{ $product->stock }}
                            </span>
                        @elseif(($product->stock ?? 0) > 0)
                            <span class="badge badge-warning" style="font-size:10px;padding:2px 7px;">
                                <i class="fa-solid fa-circle" style="font-size:5px;"></i> {{ $product->stock }}
                            </span>
                        @else
                            <span class="badge badge-danger" style="font-size:10px;padding:2px 7px;">Skadon</span>
                        @endif
                        @if($product->is_active ?? true)
                            <span class="badge badge-success" style="font-size:10px;padding:2px 7px;">Aktiv</span>
                        @else
                            <span class="badge badge-muted" style="font-size:10px;padding:2px 7px;">Joaktiv</span>
                        @endif
                    </div>
                </div>

                {{-- Actions --}}
                <div class="mobile-actions">
                    <a href="{{ url('/admin/products/'.$product->id) }}" class="btn btn-ghost btn-sm btn-icon" title="Shiko">
                        <i class="fa-solid fa-eye"></i>
                    </a>
                    <a href="{{ url('/admin/products/'.$product->id.'/edit') }}" class="btn btn-ghost btn-sm btn-icon" title="Edito">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <form action="{{ url('/admin/products/'.$product->id) }}" method="POST" onsubmit="return confirm('Fshi produktin?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Fshi">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
            @empty
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-box-open"></i></div>
                <h3>Nuk ka produkte ende</h3>
                <p>Shto produktin e parë për të filluar.</p>
                <a href="{{ url('/admin/products/create') }}" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Shto Produkt
                </a>
            </div>
            @endforelse
        </div>

        @if(method_exists($products, 'hasPages') && $products->hasPages())
        <div class="pagination-wrap">
            <div class="pag-inner">
                @if($products->onFirstPage())
                    <span class="pag-btn pag-disabled"><i class="fa-solid fa-chevron-left"></i></span>
                @else
                    <a href="{{ $products->previousPageUrl() }}" class="pag-btn"><i class="fa-solid fa-chevron-left"></i></a>
                @endif

                @foreach($products->getUrlRange(1, $products->lastPage()) as $page => $url)
                    @if($page == $products->currentPage())
                        <span class="pag-btn pag-active">{{ $page }}</span>
                    @elseif($page == 1 || $page == $products->lastPage() || abs($page - $products->currentPage()) <= 2)
                        <a href="{{ $url }}" class="pag-btn">{{ $page }}</a>
                    @elseif(abs($page - $products->currentPage()) == 3)
                        <span class="pag-btn pag-dots">&#8230;</span>
                    @endif
                @endforeach

                @if($products->hasMorePages())
                    <a href="{{ $products->nextPageUrl() }}" class="pag-btn"><i class="fa-solid fa-chevron-right"></i></a>
                @else
                    <span class="pag-btn pag-disabled"><i class="fa-solid fa-chevron-right"></i></span>
                @endif
            </div>
            <div class="pag-info">
                Shfaqen {{ $products->firstItem() }}&ndash;{{ $products->lastItem() }} nga {{ $products->total() }}
            </div>
        </div>
        
        @endif
    </div>

    </div>{{-- /page-wrap --}}
    @endsection

    @push('scripts')
    <script>
    // Search filter — works on desktop table AND mobile list
    function filterTable() {
        const q = document.getElementById('searchInput').value.toLowerCase();
        // Desktop table rows
        document.querySelectorAll('#productsTable tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
        // Mobile cards
        document.querySelectorAll('.mobile-product-card').forEach(card => {
            card.style.display = card.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    }

    // Responsive toggle — JS backup in case CSS media query fails
    // (e.g. missing viewport meta in parent layout)
    function applyResponsive() {
        const isMobile = window.innerWidth <= 768;
        const tableWrap = document.querySelector('.table-wrap');
        const mobileList = document.querySelector('.mobile-list');
        if (!tableWrap || !mobileList) return;
        if (isMobile) {
            tableWrap.style.display = 'none';
            mobileList.style.display = 'block';
        } else {
            tableWrap.style.display = '';
            mobileList.style.display = 'none';
        }
    }

    // Run on load and on resize
    applyResponsive();
    window.addEventListener('resize', applyResponsive);
    function updateBulkDeleteButton() {
        const checked = document.querySelectorAll('.row-check:checked');
        const btn = document.getElementById('bulkDeleteBtn');
        if (!btn) return;

        if (checked.length > 0) {
            btn.style.display = 'inline-flex';
            btn.innerHTML = `<i class="fa-solid fa-trash"></i> Fshi të zgjedhurat (${checked.length})`;
        } else {
            btn.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        const selectAll = document.getElementById('selectAll');
        const rowChecks = document.querySelectorAll('.row-check');

        if (selectAll) {
            selectAll.addEventListener('change', function () {
                rowChecks.forEach(ch => ch.checked = selectAll.checked);
                updateBulkDeleteButton();
            });
        }

        rowChecks.forEach(ch => {
            ch.addEventListener('change', function () {
                const all = document.querySelectorAll('.row-check');
                const checked = document.querySelectorAll('.row-check:checked');

                if (selectAll) {
                    selectAll.checked = all.length > 0 && all.length === checked.length;
                }

                updateBulkDeleteButton();
            });
        });
    });

    function submitBulkDelete() {
        const checked = document.querySelectorAll('.row-check:checked');
        if (!checked.length) return;

        if (!confirm('A je i sigurt që dëshiron t’i fshish produktet e zgjedhura?')) {
            return;
        }

        const container = document.getElementById('selectedProductsContainer');
        const form = document.getElementById('bulkDeleteForm');

        container.innerHTML = '';

        checked.forEach(ch => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'product_ids[]';
            input.value = ch.value;
            container.appendChild(input);
        });

        form.submit();
    }
    const selectAll = document.getElementById('select-all');

    if (selectAll) {
        selectAll.addEventListener('change', function () {
            document.querySelectorAll('.row-check').forEach(cb => {
                cb.checked = this.checked;
            });
        });
    }
    </script>
    @endpush