@extends('client.layout')

@section('title', 'Produktet — ShopZone')

@push('styles')
<style>
    .shop-wrap {
        padding: 0 5%;
        max-width: 1400px;
        margin: 0 auto;
    }

    /* ── PAGE HEADER ── */
    .shop-header {
        margin-bottom: 36px;
    }

    .shop-header h1 {
        font-family: 'Syne', sans-serif;
        font-size: 36px;
        font-weight: 800;
        letter-spacing: -1px;
        margin-bottom: 6px;
    }

    .shop-header h1 span {
        background: linear-gradient(135deg, var(--accent), var(--accent2));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .shop-header p { color: var(--text-muted); font-size: 14px; }

    /* ── FILTERS BAR ── */
.filters-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 28px;
    flex-wrap: nowrap;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    padding-bottom: 4px;
}
.filters-bar::-webkit-scrollbar { display: none; }

.filters-left {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
}

.filter-chip {
    padding: 8px 14px;
    border-radius: 30px;
    background: var(--surface);
    border: 1px solid var(--border);
    color: var(--text-soft);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    white-space: nowrap;
    transition: border-color 0.2s, color 0.2s, background 0.2s;
    flex-shrink: 0;
}
.filter-chip:hover { border-color: #5ecece; color: #5ecece; }
.filter-chip.active { background: #5ecece; border-color: #5ecece; color: white; }

.filter-sep {
    width: 1px;
    height: 24px;
    background: var(--border);
    flex-shrink: 0;
}

.sort-wrapper {
    flex-shrink: 0;
    margin-left: auto;
    padding-left: 8px;
}

.sort-select {
    padding: 8px 32px 8px 12px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    color: var(--text);
    font-family: 'Outfit', sans-serif;
    font-size: 13px;
    outline: none;
    cursor: pointer;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236e6e90'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 6px center;
    background-size: 18px;
    white-space: nowrap;
}
@media (max-width: 600px) {
    .filters-bar {
        flex-direction: column;
        align-items: stretch;
        overflow-x: visible;
        gap: 8px;
    }

    .filters-left {
        display: flex;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
        gap: 8px;
        padding-bottom: 2px;
    }
    .filters-left::-webkit-scrollbar { display: none; }

    .filter-sep { display: none; }

    .sort-wrapper {
        margin-left: 0;
        padding-left: 0;
    }

    .sort-select {
        width: 100%;
        background: var(--surface);
    }
}
    /* ── PRODUCT GRID ── */
    .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
        gap: 18px;
    }

    .product-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        text-decoration: none;
        color: inherit;
        display: flex;
        flex-direction: column;
        transition: all 0.25s ease;
        position: relative;
        animation: fadeUp 0.4s ease both;
    }

    .product-card:hover {
        transform: translateY(-5px);
        border-color: rgba(124,111,255,0.35);
        box-shadow: 0 16px 44px rgba(0,0,0,0.35);
    }

    .product-img {
        width: 100%;
        aspect-ratio: 1;
        overflow: hidden;
        position: relative;
        background: var(--surface2);
    }

    .product-img img {
        width: 100%; height: 100%;
        object-fit: cover;
        transition: transform 0.4s ease;
    }

    .product-card:hover .product-img img { transform: scale(1.06); }

    .product-img-placeholder {
        width: 100%; height: 100%;
        display: flex; align-items: center; justify-content: center;
        color: var(--border);
        font-size: 44px;
    }

    .product-badges {
        position: absolute;
        top: 10px; left: 10px;
        display: flex; flex-direction: column; gap: 5px;
    }

    .badge {
        display: inline-block;
        padding: 3px 9px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.5px;
    }

    .badge-featured { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: white; }
    .badge-sale { background: rgba(0,229,160,0.15); border: 1px solid rgba(0,229,160,0.3); color: var(--accent3); }

    .product-info {
        padding: 14px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }

    .product-cat {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: var(--accent);
        margin-bottom: 5px;
    }

    .product-brand {
        font-size: 10px;
        color: var(--text-muted);
        margin-left: 6px;
    }

    .product-name {
        font-family: 'Syne', sans-serif;
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
        margin-bottom: 10px;
        flex: 1;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .product-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
    }

    .product-price {
        font-family: 'Syne', sans-serif;
        font-size: 18px;
        font-weight: 800;
        color: var(--text);
    }

    .product-price .old {
        font-size: 11px;
        color: var(--text-muted);
        text-decoration: line-through;
        font-family: 'Outfit', sans-serif;
        font-weight: 400;
        display: block;
        line-height: 1;
    }

    .add-btn {
        width: 34px; height: 34px;
        border-radius: 8px;
        background: var(--accent);
        border: none;
        color: white;
        font-size: 13px;
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all 0.2s;
        flex-shrink: 0;
    }

    .add-btn:hover { background: var(--accent-h); transform: scale(1.1); }
    .add-btn.added { background: var(--accent3); }

    /* ── EMPTY ── */
    .empty-state {
        grid-column: 1 / -1;
        text-align: center;
        padding: 80px 20px;
        color: var(--text-muted);
    }

    .empty-state i {
        font-size: 52px;
        display: block;
        margin-bottom: 16px;
        opacity: 0.3;
    }

    .empty-state h3 {
        font-family: 'Syne', sans-serif;
        font-size: 20px;
        color: var(--text-soft);
        margin-bottom: 8px;
    }

    /* ── PAGINATION ── */
    .pagination-wrap {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-top: 48px;
    }

    .page-btn {
        width: 38px; height: 38px;
        border-radius: 10px;
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-soft);
        text-decoration: none;
        display: flex; align-items: center; justify-content: center;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s;
    }

    .page-btn:hover { border-color: var(--accent); color: var(--accent); }
    .page-btn.active { background: var(--accent); border-color: var(--accent); color: white; }

    @keyframes fadeUp {
        from { opacity:0; transform: translateY(16px); }
        to   { opacity:1; transform: translateY(0); }
    }

    @media (max-width: 640px) {
        .products-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
        .filters-bar { gap: 6px; }
        .sort-select { margin-left: 0; }
    }
    .product-colors {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
    margin-bottom: 10px;
}

.product-color-dot {
    width: 13px;
    height: 13px;
    border-radius: 50%;
    border: 1px solid rgba(0,0,0,0.14);
    display: inline-block;
}

.pm-wish-btn {
    position: absolute;
    top: 10px; right: 10px;
    width: 32px; height: 32px;
    border-radius: 50%;
    background: rgba(255,255,255,0.18);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.30);
    display: flex; align-items: center; justify-content: center;
    font-size: 13px;
    color: white;
    cursor: pointer;
    transition: all 0.22s cubic-bezier(.4,0,.2,1);
    z-index: 3;
    text-shadow: 0 1px 3px rgba(0,0,0,0.35);
}
.pm-wish-btn:hover {
    background: rgba(255,255,255,0.30);
    border-color: rgba(255,255,255,0.50);
    transform: scale(1.10);
}
.pm-wish-btn.saved {
    background: #ff3b30;
    border-color: #ff3b30;
    color: white;
    text-shadow: none;
}
.pm-wish-btn.saved:hover {
    background: #e02d22;
    border-color: #e02d22;
    transform: scale(1.10);
}
@keyframes heartPop {
    0%   { transform: scale(1); }
    40%  { transform: scale(1.40); }
    70%  { transform: scale(0.88); }
    100% { transform: scale(1); }
}
.pm-wish-btn.pop { animation: heartPop 0.32s cubic-bezier(.4,0,.2,1) forwards; }
/* ── WISHLIST CARDS ── */
#wishlistGrid .product-card {
    max-width: 100%;
}

#wishlistGrid .product-img {
    aspect-ratio: 1;
    max-height: 220px;
}

@media (max-width: 768px) {
    .shop-wrap {
        padding-bottom: 0 !important;
    }
}
</style>
@endpush

@section('content')

<div class="shop-wrap">

    {{-- HEADER --}}
    <div class="shop-header">
        <h1>
            @if(request('search'))
                Rezultatet për "<span>{{ request('search') }}</span>"
            @elseif(request('featured'))
                Favoritet <span>Favoritet</span>
            @elseif(request('category') && $activeCategory)
                Kategoria: <span>{{ $activeCategory->name }}</span>
            @else
                Të gjitha <span>Produktet</span>
            @endif
        </h1>
        <p>{{ $products->total() }} produkte gjithsej</p>
    </div>

    {{-- FILTERS --}}
{{-- FILTERS --}}
<div class="filters-bar">
    <div class="filters-left">
        <a href="{{ url('/shop') }}" class="filter-chip {{ !request('category') && !request('featured') ? 'active' : '' }}">
            Të gjitha
        </a>
        <a href="{{ url('/shop?featured=1') }}" class="filter-chip {{ request('featured') ? 'active' : '' }}">
            <i class="fa-solid fa-star" style="font-size:11px;"></i> Favoritet
        </a>
        <div class="filter-sep"></div>
        @foreach($categories as $cat)
            <a href="{{ url('/shop?category='.$cat->id) }}" class="filter-chip {{ request('category') == $cat->id ? 'active' : '' }}">
                {{ $cat->name }}
            </a>
        @endforeach
    </div>

    <div class="sort-wrapper">
        <form action="{{ url('/shop') }}" method="GET" style="display:flex;">
            @if(request('category')) <input type="hidden" name="category" value="{{ request('category') }}"> @endif
            @if(request('featured')) <input type="hidden" name="featured" value="1"> @endif
            <select name="sort" class="sort-select" onchange="this.form.submit()">
                <option value="">Rendit sipas...</option>
                <option value="price_asc"  {{ request('sort')=='price_asc'  ? 'selected':'' }}>Çmimi: i ulët - i lartë</option>
                <option value="price_desc" {{ request('sort')=='price_desc' ? 'selected':'' }}>Çmimi: i lartë - i ulët</option>
                <option value="newest"     {{ request('sort')=='newest'     ? 'selected':'' }}>Më të rinjtë</option>
                <option value="name_asc"   {{ request('sort')=='name_asc'   ? 'selected':'' }}>Emri: A-Z</option>
            </select>
        </form>
    </div>
</div>
{{-- WISHLIST --}}
@if(request('featured'))
<div id="wishlistSection" style="display:none; margin-bottom:40px;">
 
    <div class="products-grid" id="wishlistGrid"></div>
</div>

@endif

    {{-- GRID --}}
    <div class="products-grid" id="mainProductsGrid">
 @forelse($products as $i => $product)
@php
    $firstVariant = $product->variants?->first();

    // Gjithmonë merr foton kryesore nga galeria (is_primary = true)
    $primaryImg = $product->images?->firstWhere('is_primary', true)
               ?? $product->images?->first();

    $prodSrc = null;
    if ($primaryImg) {
        // Foto kryesore nga galeria ka prioritet
        $prodSrc = asset('storage/' . $primaryImg->image_path);
    } elseif ($firstVariant && !empty($firstVariant->image_path)) {
        // Fallback: foto e variantit të parë nëse nuk ka galeri
        $prodSrc = asset('storage/' . $firstVariant->image_path);
    }
    $hasSale = false;
    $finalPrice = 0;
    $oldPrice = null;

    if ($firstVariant) {
        $hasSale = $firstVariant->sale_price && $firstVariant->sale_price < $firstVariant->price;
        $finalPrice = $hasSale ? $firstVariant->sale_price : $firstVariant->price;
        $oldPrice = $hasSale ? $firstVariant->price : null;
    } else {
        $hasSale = $product->sale_price && $product->sale_price < $product->price;
        $finalPrice = $hasSale ? $product->sale_price : $product->price;
        $oldPrice = $hasSale ? $product->price : null;
    }

    $colors = $product->variants
        ? $product->variants->filter(fn($v) => $v->color_name)->unique('color_name')->values()
        : collect();
@endphp

<a href="{{ url('/shop/'.$product->id) }}" class="product-card" style="animation-delay: {{ $i * 0.04 }}s">
    <div class="product-img">
@if($prodSrc)
    <img src="{{ $prodSrc }}" alt="{{ $product->name }}" loading="lazy">
@else
    <div class="product-img-placeholder"><i class="fa-solid fa-box"></i></div>
@endif
 <button class="pm-wish-btn"
            data-id="{{ $product->id }}"
            data-name="{{ addslashes($product->name) }}"
            data-price="{{ number_format($finalPrice, 2) }}"
            data-img="{{ $prodSrc ?? '' }}"
            data-url="{{ url('/shop/'.$product->id) }}"
            data-cat="{{ $product->category->name ?? '' }}"
            onclick="event.preventDefault(); toggleWish(this)">
        <i class="fa-regular fa-heart"></i>
    </button>

                <div class="product-badges">
                    @if($product->featured)
                        <span class="badge badge-featured"><i class="fa-solid fa-star" style="font-size:9px;"></i> Top</span>
                    @endif
                     @if($hasSale)
    <span class="badge badge-sale">SALE</span>
@endif
                </div>
            </div>
            <div class="product-info">
                <div>
                    <span class="product-cat">{{ $product->category->name ?? '—' }}</span>
                    <span class="product-brand">{{ $product->brand->name ?? '' }}</span>
                </div>
              <div class="product-name">{{ $product->name }}</div>

@if($colors->count() > 0)
    <div class="product-colors">
        @foreach($colors as $color)
            <span class="product-color-dot"
                  title="{{ $color->color_name }}"
                  style="background: {{ $color->color_hex ?? '#ccc' }};"></span>
        @endforeach
    </div>
@endif

<div class="product-footer">
                <div class="product-price">
    @if($oldPrice)
        <span class="old">{{ number_format($oldPrice, 2) }} €</span>
    @endif
    {{ number_format($finalPrice, 2) }} €
</div>
<button class="add-btn" id="btn-{{ $product->id }}"
    onclick="event.preventDefault(); addToCart({{ $product->id }}, this, {{ $firstVariant->id ?? 'null' }})">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </a>
        @empty
        <div class="empty-state">
            <i class="fa-solid fa-box-open"></i>
            <h3>Nuk u gjetën produkte</h3>
            <p>Provo të ndryshosh filtrat ose kërkon diçka tjetër.</p>
            <a href="{{ url('/shop') }}" class="btn btn-outline" style="margin-top:20px;display:inline-flex;">Pastro filtrat</a>
        </div>
        @endforelse
    </div>

    {{-- PAGINATION --}}
    @if($products->hasPages())
    <div class="pagination-wrap">
        @if($products->onFirstPage())
            <span class="page-btn" style="opacity:0.3;cursor:default;"><i class="fa-solid fa-chevron-left"></i></span>
        @else
            <a href="{{ $products->previousPageUrl() }}" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a>
        @endif

        @foreach($products->getUrlRange(1, $products->lastPage()) as $page => $url)
            <a href="{{ $url }}" class="page-btn {{ $page == $products->currentPage() ? 'active' : '' }}">{{ $page }}</a>
        @endforeach

        @if($products->hasMorePages())
            <a href="{{ $products->nextPageUrl() }}" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a>
        @else
            <span class="page-btn" style="opacity:0.3;cursor:default;"><i class="fa-solid fa-chevron-right"></i></span>
        @endif
    </div>
    @endif

</div>

@endsection
@push('scripts')
<script>
function addToCart(id, btn, variantId) {
    variantId = variantId || null;
    var icon = btn.querySelector('i');
    if (icon) icon.className = 'fa-solid fa-spinner fa-spin';

    var payload = { product_id: id, quantity: 1 };
    if (variantId) payload.variant_id = variantId;

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (!data.success) return;
        refreshCartUI(data);
        if (icon) icon.className = 'fa-solid fa-check';
        btn.style.background = '#34c759';
        openCartUIOnly();
        setTimeout(function() {
            if (icon) icon.className = 'fa-solid fa-plus';
            btn.style.background = '';
        }, 1800);
    })
    .catch(function(err) {
        console.error('Cart error:', err);
        if (icon) icon.className = 'fa-solid fa-plus';
    });
}
document.addEventListener('DOMContentLoaded', function() {
    renderWishlist();

    const wish  = getWish();
    const items = Object.values(wish);
    const isFavoritetPage = window.location.search.includes('featured=1');

    if (isFavoritetPage) {
        var mainGrid = document.getElementById('mainProductsGrid');
        if (mainGrid) mainGrid.remove();

        var pagination = document.querySelector('.pagination-wrap');
        if (pagination) pagination.remove();

        var shopHeader = document.querySelector('.shop-header p');
        if (shopHeader) shopHeader.remove();

        var shopWrap = document.querySelector('.shop-wrap');
        if (shopWrap) {
            shopWrap.style.paddingBottom = '0';
            shopWrap.style.marginBottom = '0';
        }

        if (items.length === 0) {
            var section = document.getElementById('wishlistSection');
            if (section) {
                section.style.display = 'block';
                section.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#6e6e73;">'
                    + '<i class="fa-regular fa-heart" style="font-size:48px;display:block;margin-bottom:12px;opacity:0.3;"></i>'
                    + '<h3 style="font-size:18px;font-weight:700;margin-bottom:6px;color:#1a1c1d;">Nuk ke favoritet ende</h3>'
                    + '<p style="font-size:14px;">Kliko zemrën te produktet për t\'i shtuar këtu.</p>'
                    + '</div>';
            }
        }
    } else {
        var empty = document.getElementById('emptyState');
        if (empty && items.length > 0) {
            empty.style.display = 'none';
        }
    }
});
</script>
@endpush