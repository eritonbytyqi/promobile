<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
 public function index()
{
    $settings = Setting::all()->pluck('value', 'key');

    if (!empty($settings['company_locations'])) {
        $settings['company_locations'] = json_decode($settings['company_locations'], true);
    }

    return view('admin.settings', compact('settings'));
}

   public function update(Request $request)
{
    $data = $request->except(['_token', 'section']);

    foreach ($data as $key => $value) {
        if ($key === 'locations') {
            $locations = collect($value)
                ->map(function ($item) {
                    return [
                        'name' => $item['name'] ?? '',
                        'phone' => $item['phone'] ?? '',
                        'address_full' => $item['address_full'] ?? '',
                        'address_short' => $item['address_short'] ?? '',
                    ];
                })
                ->filter(function ($item) {
                    return !empty($item['name']) ||
                           !empty($item['phone']) ||
                           !empty($item['address_full']) ||
                           !empty($item['address_short']);
                })
                ->values()
                ->toArray();

            Setting::updateOrCreate(
                ['key' => 'company_locations'],
                ['value' => json_encode($locations, JSON_UNESCAPED_UNICODE)]
            );

            continue;
        }

        Setting::updateOrCreate(
            ['key' => $key],
            ['value' => is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : $value]
        );
    }

    return back()->with('success', 'Cilësimet u ruajtën!');
}
}