@extends('layouts.app')

@section('title', 'Bannerat')
@section('page-title', 'Bannerat')

@push('styles')
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>
    /* ── Banner Preview Stage ── */
    .banner-stage {
        border-radius: 16px;
        overflow: hidden;
        position: relative;
        height: 240px;
        display: flex;
        align-items: center;
        padding: 2rem 2.5rem;
        transition: background .3s;
        background-color: #0a0a1a;
    }

    .banner-bg-img {
        position: absolute;
        inset: 0;
        background-size: cover;
        background-position: center;
        opacity: .35;
        transition: opacity .3s;
    }

    .banner-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg, rgba(0,0,0,.75) 0%, rgba(0,0,0,.05) 100%);
    }

    .no-img-hint {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none;
    }
    .no-img-hint span {
        font-size: 12px;
        color: rgba(255,255,255,.25);
    }

    .banner-content-preview {
        position: relative;
        z-index: 2;
        max-width: 480px;
    }

    .bp-badge-new {
        display: inline-block;
        padding: 4px 13px;
        border-radius: 999px;
        background: rgba(255,255,255,.13);
        border: 1px solid rgba(255,255,255,.22);
        color: #fff;
        font-size: 12px;
        font-weight: 500;
        margin-bottom: .75rem;
        font-family: 'DM Sans', sans-serif;
    }

    .bp-title-new {
        font-family: 'Syne', sans-serif;
        font-weight: 800;
        font-size: 2rem;
        color: #fff;
        line-height: 1.15;
        margin-bottom: .45rem;
    }

    .bp-sub-new {
        font-size: 14px;
        color: rgba(255,255,255,.7);
        margin-bottom: 1.3rem;
        font-family: 'DM Sans', sans-serif;
    }

    .bp-btns {
        display: flex;
        gap: 10px;
    }

    .bp-btn-primary {
        padding: 9px 22px;
        border-radius: 8px;
        background: #fff;
        color: #0a0a1a;
        font-weight: 700;
        font-size: 13px;
        border: none;
        font-family: 'DM Sans', sans-serif;
    }

    .bp-btn-secondary {
        padding: 9px 22px;
        border-radius: 8px;
        background: rgba(255,255,255,.1);
        color: #fff;
        font-size: 13px;
        border: 1px solid rgba(255,255,255,.28);
        font-family: 'DM Sans', sans-serif;
    }

    /* ── Color Swatches ── */
    .swatch-row {
        display: flex;
        gap: 6px;
        margin-top: 8px;
        flex-wrap: wrap;
    }
    .color-swatch {
        width: 26px;
        height: 26px;
        border-radius: 6px;
        cursor: pointer;
        border: 2px solid transparent;
        transition: transform .15s, border-color .15s;
    }
    .color-swatch:hover { transform: scale(1.15); }
    .color-swatch.active { border-color: rgba(255,255,255,.5); transform: scale(1.1); }

    /* ── Badge Presets ── */
    .badge-presets {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 6px;
    }
    .badge-preset {
        padding: 3px 10px;
        border-radius: 999px;
        border: 1px solid var(--border);
        font-size: 11px;
        cursor: pointer;
        color: var(--text-muted);
        background: transparent;
        transition: border-color .15s, color .15s;
    }
    .badge-preset:hover {
        border-color: var(--text-muted);
        color: var(--text);
    }
</style>
@endpush

@section('content')
<div class="pf-wrap">

    <div class="pf-header">
        <div>
            <div class="pf-breadcrumb">
                <a href="{{ url('/') }}">Dashboard</a>
                <i class="fa-solid fa-chevron-right"></i>
                <span>Bannerat</span>
            </div>
            <h1 class="pf-title">Menaxho <span>Bannerat</span></h1>
        </div>
    </div>

    @if(session('success'))
        <div style="margin-bottom:16px;padding:12px 14px;border-radius:10px;background:rgba(0,212,170,0.1);border:1px solid rgba(0,212,170,0.25);color:#b9ffef;">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('admin.banners.store') }}" method="POST" enctype="multipart/form-data" id="bannerForm">
        @csrf

        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <div class="card-title-icon" style="background:rgba(245,197,24,0.12);color:var(--accent2);">
                        <i class="fa-solid fa-fire"></i>
                    </div>
                    Oferta / Banner
                </div>
            </div>

            <div class="card-body">

                {{-- ── PREVIEW ── --}}
                <div class="form-group">
                    <label class="form-label">Pamja paraprake</label>
                    <div class="banner-stage" id="bannerPreview"
                         style="background-color:{{ old('banner_bg_color','#0a0a1a') }};">
                        <div class="banner-bg-img" id="previewBg"></div>
                        <div class="banner-overlay"></div>
                        <div class="no-img-hint" id="noImgHint"><span>Ngarko foto për sfond</span></div>
                        <div class="banner-content-preview">
                            <div class="bp-badge-new" id="previewBadge">{{ old('banner_badge','⚡ Oferta javore') }}</div>
                            <div class="bp-title-new" id="previewTitle">{{ old('banner_title','Titulli i bannerit') }}</div>
                            <div class="bp-sub-new"   id="previewSub">{{ old('banner_subtitle','Përshkrimi i shkurtër...') }}</div>
                            <div class="bp-btns">
                                <div class="bp-btn-primary"   id="previewBtn1">{{ old('banner_btn_primary_text','Buy Now') }}</div>
                                <div class="bp-btn-secondary" id="previewBtn2">{{ old('banner_btn_secondary_text','Shiko detajet') }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ── TITULLI & NËNTITULLI ── --}}
                <div class="form-row" style="grid-template-columns:1fr 1fr;">
                    <div class="form-group">
                        <label class="form-label">Titulli</label>
                        <input type="text" name="banner_title" class="form-control"
                               value="{{ old('banner_title') }}"
                               placeholder="p.sh. iPhone 15 Pro"
                               oninput="document.getElementById('previewTitle').textContent=this.value||'Titulli i bannerit'">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Nëntitulli</label>
                        <input type="text" name="banner_subtitle" class="form-control"
                               value="{{ old('banner_subtitle') }}"
                               placeholder="Performancë premium"
                               oninput="document.getElementById('previewSub').textContent=this.value||'Përshkrimi i shkurtër...'">
                    </div>
                </div>

                {{-- ── BADGE, FOTO, NGJYRA ── --}}
                <div class="form-row" style="grid-template-columns:1fr 1fr 200px;">
                    <div class="form-group">
                        <label class="form-label">Badge Teksti</label>
                        <input type="text" name="banner_badge" class="form-control"
                               value="{{ old('banner_badge') }}"
                               placeholder="⚡ Oferta javore"
                               oninput="document.getElementById('previewBadge').textContent=this.value||'⚡ Oferta javore'">
                        <div class="badge-presets">
                            <span class="badge-preset" onclick="setBadge('⚡ Oferta javore')">⚡ Oferta javore</span>
                            <span class="badge-preset" onclick="setBadge('🔥 Hot deal')">🔥 Hot deal</span>
                            <span class="badge-preset" onclick="setBadge('✨ I ri')">✨ I ri</span>
                            <span class="badge-preset" onclick="setBadge('🎯 Limituar')">🎯 Limituar</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Foto e Bannerit</label>
                        <input type="file" name="banner_image" class="form-control"
                               accept="image/*" onchange="previewBannerImage(this)">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Ngjyra e Sfondit</label>
                        <div class="color-picker-row">
                            <input type="color" name="banner_bg_color" id="bgColorPicker"
                                   value="{{ old('banner_bg_color','#0a0a1a') }}"
                                   oninput="document.getElementById('bannerPreview').style.backgroundColor=this.value;document.getElementById('bgColorText').value=this.value">
                            <input type="text" id="bgColorText" class="form-control"
                                   value="{{ old('banner_bg_color','#0a0a1a') }}" placeholder="#0a0a1a"
                                   oninput="document.getElementById('bgColorPicker').value=this.value;document.getElementById('bannerPreview').style.backgroundColor=this.value">
                        </div>
                        <div class="swatch-row">
                            <div class="color-swatch active" style="background:#0a0a1a;" onclick="setSwatchColor('#0a0a1a',this)"></div>
                            <div class="color-swatch"        style="background:#1a0a2e;" onclick="setSwatchColor('#1a0a2e',this)"></div>
                            <div class="color-swatch"        style="background:#0d2137;" onclick="setSwatchColor('#0d2137',this)"></div>
                            <div class="color-swatch"        style="background:#1a1200;" onclick="setSwatchColor('#1a1200',this)"></div>
                            <div class="color-swatch"        style="background:#1a0010;" onclick="setSwatchColor('#1a0010',this)"></div>
                            <div class="color-swatch"        style="background:#0a1a0a;" onclick="setSwatchColor('#0a1a0a',this)"></div>
                        </div>
                    </div>
                </div>

                {{-- ── PRODUKTI ── --}}
                <div class="form-group">
                    <label class="form-label">Lidhe me Produkt</label>
                    <select name="product_id" class="form-select">
                        <option value="">-- Pa produkt specifik --</option>
                        @foreach($products as $product)
                            <option value="{{ $product->id }}" {{ old('product_id') == $product->id ? 'selected' : '' }}>
                                {{ $product->name }}
                            </option>
                        @endforeach
                    </select>
                    <small style="color:var(--text-muted);font-size:12px;">
                        Nëse zgjedh produkt, linkat gjenerohen automatikisht.
                    </small>
                </div>

                {{-- ── BUTONAT ── --}}
                <div class="form-row" style="grid-template-columns:1fr 1fr;">
                    <div class="form-group">
                        <label class="form-label">Butoni Kryesor — Teksti</label>
                        <input type="text" name="banner_btn_primary_text" class="form-control"
                               value="{{ old('banner_btn_primary_text','Buy Now') }}"
                               oninput="document.getElementById('previewBtn1').textContent=this.value||'Buy Now'">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Butoni Dytësor — Teksti</label>
                        <input type="text" name="banner_btn_secondary_text" class="form-control"
                               value="{{ old('banner_btn_secondary_text','Shiko detajet') }}"
                               oninput="document.getElementById('previewBtn2').textContent=this.value||'Shiko detajet'">
                    </div>
                </div>

                {{-- ── SORT ── --}}
                <div class="form-group" style="max-width:160px;">
                    <label class="form-label">Rendi (sort)</label>
                    <input type="number" name="banner_sort" class="form-control"
                           value="{{ old('banner_sort',0) }}" placeholder="0">
                </div>

                <button type="submit" class="btn btn-warning btn-full">
                    <i class="fa-solid fa-fire"></i> Krijo Bannerin
                </button>
            </div>
        </div>
    </form>

    {{-- ── BANNERAT EKZISTUES ── --}}
    <div class="card" style="margin-top:24px;">
        <div class="card-header">
            <div class="card-title">Bannerat ekzistues</div>
        </div>
        <div class="card-body">
            @forelse($banners as $banner)
                <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);gap:16px;">
                    <div>
                        <div style="font-weight:700;">{{ $banner->title ?: 'Pa titull' }}</div>
                        <div style="font-size:12px;color:var(--text-muted);">
                            {{ $banner->btn_primary_text }} → {{ $banner->btn_primary_url }}
                        </div>
                    </div>

                    <form action="{{ route('admin.banners.destroy', $banner->id) }}" method="POST" onsubmit="return confirm('Me e fshi këtë banner?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger-soft btn-sm">
                            <i class="fa-solid fa-trash"></i> Fshi
                        </button>
                    </form>
                </div>
            @empty
                <div style="color:var(--text-muted);">Nuk ka bannera ende.</div>
            @endforelse
        </div>
    </div>

</div>

{{-- ── OFERTA SPECIALE ── --}}
<div class="card" style="margin-top:24px;">
    <div class="card-header">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(0,188,212,0.12);color:#00bcd4;">
                <i class="fa-solid fa-tag"></i>
            </div>
            Oferta Speciale (Bento Grid)
        </div>
    </div>
    <div class="card-body">
<form action="{{ route('admin.banners.offer') }}" method="POST">
                @csrf
            <div class="form-row" style="grid-template-columns:1fr 1fr;">
                <div class="form-group">
                    <label class="form-label">Titulli i Ofertës</label>
                    <input type="text" name="offer_title" class="form-control"
                           value="{{ cache('offer_title', 'Oferta Speciale') }}"
                           placeholder="p.sh. Deri -50% Zbritje">
                </div>
                <div class="form-group">
                    <label class="form-label">Nëntitulli</label>
                    <input type="text" name="offer_subtitle" class="form-control"
                           value="{{ cache('offer_subtitle', 'Zbulo produktet me zbritje dhe oferta ekskluzive.') }}"
                           placeholder="Përshkrimi i shkurtër...">
                </div>
            </div>
            <div class="form-row" style="grid-template-columns:1fr 1fr;">
                <div class="form-group">
                    <label class="form-label">Teksti i Linkut</label>
                    <input type="text" name="offer_link_text" class="form-control"
                           value="{{ cache('offer_link_text', 'Shiko ofertat →') }}"
                           placeholder="Shiko ofertat →">
                </div>
                <div class="form-group">
                    <label class="form-label">URL (lini bosh për /shop?featured=1)</label>
                    <input type="text" name="offer_url" class="form-control"
                           value="{{ cache('offer_url', '') }}"
                           placeholder="/shop?featured=1">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-save"></i> Ruaj Ofertën
            </button>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function previewBannerImage(input) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = ev => {
        const bg = document.getElementById('previewBg');
        if (bg) {
            bg.style.backgroundImage = `url('${ev.target.result}')`;
            document.getElementById('noImgHint').style.display = 'none';
        }
    };
    reader.readAsDataURL(input.files[0]);
}

function setSwatchColor(hex, el) {
    document.getElementById('bgColorPicker').value = hex;
    document.getElementById('bgColorText').value   = hex;
    document.getElementById('bannerPreview').style.backgroundColor = hex;
    document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
    el.classList.add('active');
}

function setBadge(txt) {
    const input = document.querySelector('input[name="banner_badge"]');
    if (input) input.value = txt;
    document.getElementById('previewBadge').textContent = txt;
}
</script>
@endpush