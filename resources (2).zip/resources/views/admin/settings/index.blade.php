@extends('layouts.admin')

@section('title', 'Cilësimet — ProMobile Admin')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/admin/settings.css') }}">
@endpush
@section('content')
<div class="sw">

    {{-- Page header --}}
    <div class="sw-head">
        <h1>Cilësimet</h1>
        <p>Menaxho të gjitha informacionet e faqes nga një vend.</p>
    </div>

    @if(session('success'))

    @endif

    {{-- Tabs --}}
    <div class="sw-tabs">
        <button class="sw-tab active" onclick="swTab('contact', this)">
            <span >contacts</span> Kontakti & Kompania
        </button>
        <button class="sw-tab" onclick="swTab('terms', this)">
            <span >gavel</span> Kushtet
        </button>
        <button class="sw-tab" onclick="swTab('privacy', this)">
            <span >shield</span> Privatësia
        </button>
    </div>

    {{-- ═══════════════ PANEL: CONTACT ═══════════════ --}}
    <div class="sw-panel active" id="panel-contact">
        <form method="POST" action="/admin/settings">
            @csrf
            <input type="hidden" name="section" value="contact">

            {{-- Email --}}
            <div class="sw-section">
                <div class="sw-section-head">
                    
                    <span class="label">Email</span>
                </div>
                <div class="sw-section-body">
                    <div class="sw-grid2">
                        <div class="sw-field">
                            <label>Email Kryesor</label>
                            <input type="email" name="company_email"
                                   value="{{ $settings['company_email'] ?? '' }}"
                                   placeholder="info@promobile.com">
                        </div>
                        <div class="sw-field">
                            <label>Email Support</label>
                            <input type="email" name="company_email2"
                                   value="{{ $settings['company_email2'] ?? '' }}"
                                   placeholder="support@promobile.com">
                        </div>
                    </div>
                </div>
            </div>

            {{-- Telefoni --}}
            <div class="sw-section">
                <div class="sw-section-head">
                    
                    <span class="label">Telefoni</span>
                </div>
                <div class="sw-section-body">
                    <div class="sw-grid2">
                        <div class="sw-field">
                            <label>Telefoni 1</label>
                            <input type="text" name="company_phone"
                                   value="{{ $settings['company_phone'] ?? '' }}"
                                   placeholder="+383 44 000 000">
                        </div>
                        <div class="sw-field">
                            <label>Telefoni 2</label>
                            <input type="text" name="company_phone2"
                                   value="{{ $settings['company_phone2'] ?? '' }}"
                                   placeholder="+383 44 000 001">
                        </div>
                    </div>
                </div>
            </div>

            {{-- Lokacionet --}}
            <div class="sw-section">
                <div class="sw-section-head">
                   
                    <span class="label">Lokacionet</span>
                </div>
                <div class="sw-section-body">
                    <p class="sw-hint">Shto një ose më shumë lokacione për faqen Kontakt.</p>

                    @php
                        $locations = old('locations');
                        if (!$locations) {
                            $locations = !empty($settings['company_locations'])
                                ? $settings['company_locations']
                                : [['name' => '', 'phone' => '', 'address_full' => '', 'address_short' => '']];
                        }
                    @endphp

                    <div id="locationsWrap">
                        @foreach($locations as $i => $loc)
                        <div class="loc-card" data-index="{{ $i }}">
                            <div class="loc-head">
                                <div class="loc-label">
                                    <span>Lokacioni</span>
                                    <span class="loc-badge loc-number">{{ $i + 1 }}</span>
                                </div>
                                <button type="button" class="btn-remove" onclick="removeLoc(this)">
                                    <span class="material-symbols-outlined"></span> Largo
                                </button>
                            </div>

                            <div class="sw-grid2 mb12">
                                <div class="sw-field">
                                    <label>Emri / Qyteti</label>
                                    <input type="text"
                                           name="locations[{{ $i }}][name]"
                                           value="{{ $loc['name'] ?? '' }}"
                                           placeholder="Prishtinë">
                                </div>
                                <div class="sw-field">
                                    <label>Telefoni</label>
                                    <input type="text"
                                           name="locations[{{ $i }}][phone]"
                                           value="{{ $loc['phone'] ?? '' }}"
                                           placeholder="+383 44 000 000">
                                </div>
                            </div>

                            <div class="sw-field mb10">
                                <label>Adresa e Plotë</label>
                                <input type="text"
                                       class="loc-addr-full"
                                       name="locations[{{ $i }}][address_full]"
                                       value="{{ $loc['address_full'] ?? '' }}"
                                       placeholder="Rr. Nënë Tereza, Nr.15, Prishtinë"
                                       oninput="updateLocMap(this)">
                            </div>

                            <div class="sw-field">
                                <label>Adresa e Shkurtër</label>
                                <input type="text"
                                       name="locations[{{ $i }}][address_short]"
                                       value="{{ $loc['address_short'] ?? '' }}"
                                       placeholder="Prishtinë, Kosovë">
                            </div>

                            <div class="map-preview loc-map-wrap"
                                 style="{{ !empty($loc['address_full']) ? '' : 'display:none' }}">
                                <iframe class="loc-map-iframe"
                                        src="{{ !empty($loc['address_full']) ? 'https://maps.google.com/maps?q='.urlencode($loc['address_full']).'&output=embed' : '' }}"
                                        loading="lazy"></iframe>
                            </div>
                        </div>
                        @endforeach
                    </div>

                    <button type="button" class="btn-add-loc" onclick="addLoc()">
                        Shto Lokacion
                    </button>
                </div>
            </div>

            {{-- Orët e punës --}}
            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-teal">
                    </div>
                    <span class="label">Orët e Punës</span>
                </div>
                <div class="sw-section-body">
                    <div class="sw-grid3">
                        <div class="sw-field">
                            <label>E Hënë — E Premte</label>
                            <input type="text" name="hours_weekdays"
                                   value="{{ $settings['hours_weekdays'] ?? '' }}"
                                   placeholder="09:00 — 18:00">
                        </div>
                        <div class="sw-field">
                            <label>E Shtunë</label>
                            <input type="text" name="hours_saturday"
                                   value="{{ $settings['hours_saturday'] ?? '' }}"
                                   placeholder="10:00 — 15:00">
                        </div>
                        <div class="sw-field">
                            <label>E Diel</label>
                            <input type="text" name="hours_sunday"
                                   value="{{ $settings['hours_sunday'] ?? '' }}"
                                   placeholder="Mbyllur">
                        </div>
                    </div>
                </div>
            </div>

            {{-- Social --}}
            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-pink">
                    </div>
                    <span class="label">Rrjetet Sociale</span>
                </div>
                <div class="sw-section-body">
                    <div class="sw-grid3">
                        <div class="sw-field">
                            <label>Instagram URL</label>
                            <input type="text" name="social_instagram"
                                   value="{{ $settings['social_instagram'] ?? '' }}"
                                   placeholder="https://instagram.com/...">
                        </div>
                        <div class="sw-field">
                            <label>Facebook URL</label>
                            <input type="text" name="social_facebook"
                                   value="{{ $settings['social_facebook'] ?? '' }}"
                                   placeholder="https://facebook.com/...">
                        </div>
                        <div class="sw-field">
                            <label>WhatsApp Nr.</label>
                            <input type="text" name="social_whatsapp"
                                   value="{{ $settings['social_whatsapp'] ?? '' }}"
                                   placeholder="+383 4X XXX XXX">
                        </div>
                    </div>
                </div>
                <div class="sw-save-row">
                    <button type="submit" class="btn-save">
                         Ruaj Ndryshimet
                    </button>
                </div>
            </div>
        </form>
    </div>

    {{-- ═══════════════ PANEL: TERMS ═══════════════ --}}
    <div class="sw-panel" id="panel-terms">
        <form method="POST" action="/admin/settings">
            @csrf
            <input type="hidden" name="section" value="terms">

            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-teal">
                    </div>
                    <span class="label">Data e Përditësimit</span>
                </div>
                <div class="sw-section-body">
                    <div class="date-narrow">
                        <div class="sw-field">
                            <label>Data (shfaqet te header i faqes)</label>
                            <input type="date" name="terms_updated"
                                   value="{{ $settings['terms_updated'] ?? '' }}">
                        </div>
                    </div>
                </div>
            </div>

            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-purple">
                    </div>
                    <span class="label">Përmbajtja e Kushteve</span>
                </div>
                <div class="sw-section-body">
                    <div id="terms_editor"></div>
                </div>
                <div class="sw-save-row">
                    <button type="submit" class="btn-save" id="terms_submit">
                       Ruaj Kushtet
                    </button>
                </div>
            </div>
            <textarea name="terms_content" style="display:none"></textarea>
        </form>
    </div>

    {{-- ═══════════════ PANEL: PRIVACY ═══════════════ --}}
    <div class="sw-panel" id="panel-privacy">
        <form method="POST" action="/admin/settings">
            @csrf
            <input type="hidden" name="section" value="privacy">

            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-amber">
                    </div>
                    <span class="label">Data e Përditësimit</span>
                </div>
                <div class="sw-section-body">
                    <div class="date-narrow">
                        <div class="sw-field">
                            <label>Data (shfaqet te header i faqes)</label>
                            <input type="date" name="privacy_updated"
                                   value="{{ $settings['privacy_updated'] ?? '' }}">
                        </div>
                    </div>
                </div>
            </div>

            <div class="sw-section">
                <div class="sw-section-head">
                    <div class="sw-section-icon si-pink">
                    </div>
                    <span class="label">Përmbajtja e Privatësisë</span>
                </div>
                <div class="sw-section-body">
                    <div id="privacy_editor"></div>
                </div>
                <div class="sw-save-row">
                    <button type="submit" class="btn-save" id="privacy_submit">
                        Ruaj Privatësinë
                    </button>
                </div>
            </div>
            <textarea name="privacy_content" style="display:none"></textarea>
        </form>
    </div>

</div>
@endsection

@push('scripts')
<link href="https://cdn.quilljs.com/1.3.7/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>
@endpush
