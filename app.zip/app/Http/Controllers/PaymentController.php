<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Refund;

class PaymentController extends Controller
{
public function __construct()
{
    \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
}
public function createIntent(Request $request)
{
    try {
        $request->validate([
            'order_id' => 'required|exists:orders,id',
        ]);

        $order = Order::findOrFail($request->order_id);

        $intent = PaymentIntent::create([
            'amount'   => (int) ($order->total_amount * 100),
            'currency' => 'eur',
            'metadata' => [
                'order_id'     => $order->id,
                'order_number' => $order->order_number,
            ],
        ]);

        $order->update(['payment_intent_id' => $intent->id]);

        return response()->json([
            'client_secret' => $intent->client_secret,
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'error' => $e->getMessage()
        ], 500);
    }
}
    // Krijo PaymentIntent dhe kthe client_secret
   

    // Konfirmo pagesën pas Stripe
 public function confirm(Request $request)
{
    try {
        $order = Order::findOrFail($request->order_id);

        $intent = PaymentIntent::retrieve($request->payment_intent_id);

        if ($intent->status === 'succeeded') {
       $order->update([
    'status'            => 'pending', // ← pending, jo confirmed
    'payment_intent_id' => $request->payment_intent_id,
]);

            return response()->json(['success' => true]);
        }

        return response()->json(['success' => false, 'message' => 'Pagesa nuk u krye.'], 400);

    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
}
    // Refund — kur admini anulon porosinë
   
public function refund(Request $request, Order $order)
{
    if (!$order->payment_intent_id) {
        return back()->with('error', 'Kjo porosi nuk ka pagesë online për t\'u kthyer.');
    }
 
    try {
        // Nëse refund_all ose nuk ka items të zgjedhura
        if ($request->refund_all || !$request->has('items')) {
            // Kthe të gjithën
            Refund::create([
                'payment_intent' => $order->payment_intent_id,
            ]);
            $order->update(['status' => 'cancelled']);
            return back()->with('success', 'U kthye e gjithë pagesa prej ' . number_format($order->total_amount, 2) . ' € te klienti!');
        }
 
        // Refund i pjesshëm — llogarit shumën
        $refundAmount = 0;
        foreach ($request->items as $itemId => $data) {
            $qty = (int) ($data['quantity'] ?? 0);
            $price = (float) ($data['unit_price'] ?? 0);
            if ($qty > 0 && $price > 0) {
                $refundAmount += $qty * $price;
            }
        }
 
        if ($refundAmount <= 0) {
            return back()->with('error', 'Zgjedh të paktën 1 copë për të kthyer!');
        }
 
        if ($refundAmount > $order->total_amount) {
            return back()->with('error', 'Shuma e kthimit nuk mund të jetë më e madhe se totali i porosisë!');
        }
 
        // Krijo refund të pjesshëm te Stripe (në cents)
        Refund::create([
            'payment_intent' => $order->payment_intent_id,
            'amount'         => (int) ($refundAmount * 100),
        ]);
 
        // Nëse kthehet e gjithë shuma → cancelled, përndryshe → partially_refunded
        $newStatus = $refundAmount >= $order->total_amount ? 'cancelled' : 'confirmed';
        $order->update(['status' => $newStatus]);
 
        return back()->with('success', 'U kthyen ' . number_format($refundAmount, 2) . ' € te klienti me sukses!');
 
    } catch (\Exception $e) {
        return back()->with('error', 'Gabim gjatë kthimit: ' . $e->getMessage());
    }
}
 
    public function page($orderId)
{
    $order = \App\Models\Order::with('items.product')->findOrFail($orderId);
    return view('client.Order.stripe-payment', compact('order'));
}
}