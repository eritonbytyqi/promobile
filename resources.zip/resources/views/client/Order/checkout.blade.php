@extends('client.layout')

@section('title', 'Checkout — ProMobile')

@push('styles')
<style>
    .checkout-wrap {
        max-width: 1200px;
        margin: 0 auto;
        padding: 48px 5%;
    }

    .checkout-title {
        font-size: 32px;
        font-weight: 800;
        letter-spacing: -0.8px;
        color: var(--text);
        margin-bottom: 36px;
    }

    .checkout-grid {
        display: grid;
        grid-template-columns: 1.2fr 1fr;
        gap: 32px;
        align-items: start;
    }

    .checkout-left { display: flex; flex-direction: column; gap: 24px; }

    .checkout-section {
        background: var(--surface);
        border-radius: 24px;
        padding: 28px;
        border: 1px solid var(--border-solid);
    }

    .checkout-section-title {
        display: flex; align-items: center; gap: 10px;
        font-size: 15px; font-weight: 700; color: var(--text);
        margin-bottom: 22px;
    }
    .checkout-section-title i { color: var(--primary-cont); font-size: 15px; }

    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group.full { grid-column: 1 / -1; }

    .form-label {
        font-size: 10px; font-weight: 700;
        letter-spacing: 1.2px; text-transform: uppercase; color: var(--text-muted);
    }

    .form-input {
        padding: 12px 16px;
        background: var(--surface-low);
        border: 1.5px solid transparent;
        border-radius: 12px;
        font-family: 'Inter', sans-serif;
        font-size: 14px; color: var(--text);
        outline: none; transition: all 0.2s;
        width: 100%;
    }
    .form-input:focus {
        background: var(--surface);
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(0,89,181,0.1);
    }
    .form-input::placeholder { color: var(--text-muted); }
    .form-input:read-only {
        background: var(--surface-low);
        color: var(--text-soft);
        cursor: default;
        border-color: transparent;
    }

    /* Auth info banner */
    .auth-info-banner {
        display: flex; align-items: center; gap: 10px;
        background: var(--primary-fixed);
        border: 1px solid var(--primary-dim);
        border-radius: 12px;
        padding: 12px 16px;
        margin-bottom: 20px;
        font-size: 13px; color: var(--primary);
        font-weight: 500;
    }
    .auth-info-banner .material-symbols-outlined { font-size: 18px; flex-shrink: 0; }

    /* Guest login prompt */
    .guest-prompt {
        background: var(--surface-low);
        border: 1px solid var(--border-solid);
        border-radius: 16px;
        padding: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
    }
    .guest-prompt-text { font-size: 13px; color: var(--text-soft); line-height: 1.5; }
    .guest-prompt-text strong { color: var(--text); display: block; font-size: 14px; margin-bottom: 2px; }
    .guest-prompt-btn {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 9px 18px; background: var(--primary); color: white;
        border-radius: var(--radius-full); font-size: 13px; font-weight: 700;
        text-decoration: none; white-space: nowrap; flex-shrink: 0;
        transition: opacity 0.2s;
    }
    .guest-prompt-btn:hover { opacity: 0.85; }

    /* Right column */
    .checkout-right { position: sticky; top: 88px; }

    .order-summary {
        background: var(--surface);
        border-radius: 24px;
        padding: 28px;
        border: 1px solid var(--border-solid);
        display: flex; flex-direction: column; gap: 20px;
    }

    .order-summary-title {
        font-size: 18px; font-weight: 800; color: var(--text); letter-spacing: -0.3px;
    }

    .order-items { display: flex; flex-direction: column; gap: 14px; }

    .order-item { display: flex; align-items: center; gap: 14px; }

    .order-item-img {
        width: 60px; height: 60px; border-radius: 14px;
        overflow: hidden; background: var(--surface-low); flex-shrink: 0;
    }
    .order-item-img img { width: 100%; height: 100%; object-fit: cover; }
    .order-item-img-ph {
        width: 100%; height: 100%;
        display: flex; align-items: center; justify-content: center;
        color: var(--text-muted); font-size: 22px;
    }

    .order-item-info { flex: 1; min-width: 0; }
    .order-item-name {
        font-size: 13px; font-weight: 700; color: var(--text);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 3px;
    }
    .order-item-qty { font-size: 12px; color: var(--text-muted); }
    .order-item-price { font-size: 14px; font-weight: 800; color: var(--text); white-space: nowrap; }

    .order-divider { height: 1px; background: var(--border-solid); }

    .order-totals { display: flex; flex-direction: column; gap: 10px; }
    .order-row {
        display: flex; justify-content: space-between; align-items: center;
        font-size: 13px; color: var(--text-muted);
    }
    .order-row span:last-child { color: var(--text); font-weight: 500; }
    .order-row.shipping span:last-child { color: var(--success); font-weight: 700; }
    .order-row.total { font-size: 16px; font-weight: 800; color: var(--text); margin-top: 4px; }
    .order-row.total span:last-child { font-size: 22px; font-weight: 800; color: var(--primary); }

    /* Payment method */
    .payment-method {
        background: var(--surface-low);
        border-radius: 16px;
        padding: 18px;
    }
    .payment-method-title {
        font-size: 13px; font-weight: 700; color: var(--text); margin-bottom: 12px;
    }
    .payment-options { display: flex; flex-direction: column; gap: 8px; }
    .payment-option {
        display: flex; align-items: center; gap: 10px;
        padding: 12px 14px;
        background: var(--surface);
        border: 1.5px solid var(--border-solid);
        border-radius: 12px; cursor: pointer;
        transition: border-color 0.2s;
    }
    .payment-option input[type=radio] { accent-color: var(--primary); width: 16px; height: 16px; }
    .payment-option label { font-size: 13px; font-weight: 600; color: var(--text); cursor: pointer; display: flex; align-items: center; gap: 8px; }
    .payment-option:has(input:checked) { border-color: var(--primary); background: var(--primary-fixed); }

    .checkout-btn {
        width: 100%; padding: 16px;
        background: var(--text); color: white; border: none;
        border-radius: 14px; font-family: 'Inter', sans-serif;
        font-size: 15px; font-weight: 700; cursor: pointer;
        display: flex; align-items: center; justify-content: center; gap: 10px;
        transition: opacity 0.2s, transform 0.2s;
    }
    .checkout-btn:hover { opacity: 0.85; transform: translateY(-1px); }

    .secure-badge {
        display: flex; align-items: center; justify-content: center; gap: 6px;
        font-size: 11px; color: var(--text-muted); font-weight: 500;
    }

    .checkout-empty {
        text-align: center; padding: 80px 20px;
    }
    .checkout-empty i { font-size: 52px; color: var(--text-muted); display: block; margin-bottom: 16px; }
    .checkout-empty h2 { font-size: 20px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
    .checkout-empty p { font-size: 14px; color: var(--text-muted); margin-bottom: 24px; }
    .checkout-empty a {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 12px 24px; background: var(--text); color: white;
        border-radius: 999px; font-size: 14px; font-weight: 700; text-decoration: none;
    }

    @media (max-width: 900px) {
        .checkout-grid { grid-template-columns: 1fr; }
        .checkout-right { position: static; }
    }
    @media (max-width: 540px) {
        .form-grid-2 { grid-template-columns: 1fr; }
        .guest-prompt { flex-direction: column; align-items: flex-start; }
        .checkout-wrap { padding: 24px 16px; }
    }
</style>
@endpush

@section('content')
<div class="checkout-wrap">

    @if(count($cart) === 0)
        <div class="checkout-empty">
            <i class="fa-solid fa-bag-shopping"></i>
            <h2>Shporta është bosh</h2>
            <p>Shto produkte para se të vazhdosh me checkout.</p>
            <a href="{{ url('/shop') }}">
                <i class="fa-solid fa-arrow-left"></i>
                Shko te produktet
            </a>
        </div>

    @else

        <h1 class="checkout-title">Checkout</h1>
<form method="POST" action="{{ route('checkout.place') }}">
        @csrf

        <div class="checkout-grid">

            {{-- ── LEFT ── --}}
            <div class="checkout-left">

                {{-- Guest prompt ose auth banner --}}
                @guest
                    <div class="guest-prompt">
                        <div class="guest-prompt-text">
                            <strong>Keni llogari?</strong>
                            Kyçuni për të plotësuar automatikisht të dhënat tuaja dhe për të ruajtur porositë.
                        </div>
                        <a href="{{ route('login') }}" class="guest-prompt-btn">
                            <span class="material-symbols-outlined" style="font-size:16px;">login</span>
                            Kyçu
                        </a>
                    </div>
                @else
                    <div class="auth-info-banner">
                        <span class="material-symbols-outlined">verified_user</span>
                        Të dhënat u plotësuan automatikisht nga profili juaj.
                        <a href="{{ route('profile.index') }}" style="color:var(--primary);font-weight:700;margin-left:auto;text-decoration:none;font-size:12px;">Ndrysho</a>
                    </div>
                @endguest

                {{-- Informacioni i dërgimit --}}
                <div class="checkout-section">
                    <div class="checkout-section-title">
                        <i class="fa-solid fa-truck"></i>
                        Informacioni i dërgimit
                    </div>

                    <div class="form-grid-2">
                        @auth
                        @php $address = \App\Models\UserAddress::where('user_id', auth()->id())->where('is_default',1)->first(); @endphp
                        <div class="form-group">
                            <label class="form-label">Emri i plotë</label>
                            <input type="text" name="customer_name" class="form-input"
                                   value="{{ auth()->user()->name . ' ' . auth()->user()->surname }}"
                                   placeholder="Emri Mbiemri" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="customer_email" class="form-input"
                                   value="{{ auth()->user()->email }}"
                                   placeholder="email@example.com" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Telefoni</label>
                            <input type="tel" name="customer_phone" class="form-input"
                                   value="{{ auth()->user()->phone ?? '' }}"
                                   placeholder="+383 44 000 000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Qyteti</label>
                            <input type="text" name="city" class="form-input"
                                   value="{{ $address->city ?? '' }}"
                                   placeholder="Prishtinë">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="shipping_address" class="form-input"
                                   value="{{ $address->address_line_1 ?? '' }}"
                                   placeholder="Rruga, numri...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kodi Postar</label>
                            <input type="text" name="postal_code" class="form-input"
                                   value="{{ $address->postal_code ?? '' }}"
                                   placeholder="10000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Shteti</label>
                            <input type="text" name="country" class="form-input"
                                   value="{{ $address->country ?? 'Kosovë' }}"
                                   placeholder="Kosovë">
                        </div>
                        @else
                        <div class="form-group">
                            <label class="form-label">Emri i plotë</label>
                            <input type="text" name="customer_name" class="form-input" placeholder="Emri Mbiemri" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="customer_email" class="form-input" placeholder="email@example.com" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Telefoni</label>
                            <input type="tel" name="customer_phone" class="form-input" placeholder="+383 44 000 000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Qyteti</label>
                            <input type="text" name="city" class="form-input" placeholder="Prishtinë">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="shipping_address" class="form-input" placeholder="Rruga, numri...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kodi Postar</label>
                            <input type="text" name="postal_code" class="form-input" placeholder="10000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Shteti</label>
                            <input type="text" name="country" class="form-input" placeholder="Kosovë">
                        </div>
                        @endauth
                    </div>
                </div>

                {{-- Mënyra e pagesës --}}
                <div class="checkout-section">
                    <div class="checkout-section-title">
                        <i class="fa-solid fa-wallet"></i>
                        Mënyra e pagesës
                    </div>
                    <div class="payment-options">
                        <div class="payment-option">
                            <input type="radio" name="payment_method" id="cash" value="cash" checked>
                            <label for="cash">
                                <i class="fa-solid fa-money-bill-wave" style="color:#34c759;"></i>
                                Para në dorë (Cash on delivery)
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" name="payment_method" id="bank" value="bank">
                            <label for="bank">
                                <i class="fa-solid fa-building-columns" style="color:var(--primary);"></i>
                                Transfertë bankare
                            </label>
                        </div>
                    </div>
                </div>

            </div>

            {{-- ── RIGHT: Order Summary ── --}}
            <div class="checkout-right">
                <div class="order-summary">

                    <div class="order-summary-title">Përmbledhja e porosisë</div>

                    <div class="order-items">
                        @foreach($cart as $key => $item)
                        <div class="order-item">
                            <div class="order-item-img">
                                @if($item['image'])
                                    <img src="{{ $item['image'] }}" alt="{{ $item['name'] }}">
                                @else
                                    <div class="order-item-img-ph"><i class="fa-solid fa-box"></i></div>
                                @endif
                            </div>
                            <div class="order-item-info">
                                <div class="order-item-name">{{ $item['name'] }}</div>
                                <div class="order-item-qty">Sasia: {{ $item['quantity'] }}</div>
                            </div>
                            <div class="order-item-price">
                                {{ number_format($item['price'] * $item['quantity'], 2) }} €
                            </div>
                        </div>
                        @endforeach
                    </div>

                    <div class="order-divider"></div>

                    <div class="order-totals">
                        <div class="order-row">
                            <span>Nëntotali</span>
                            <span>{{ number_format($total, 2) }} €</span>
                        </div>
                        <div class="order-row shipping">
                            <span>Dërgesa</span>
                            <span><i class="fa-solid fa-truck" style="font-size:11px;"></i> Falas</span>
                        </div>
                        <div class="order-divider"></div>
                        <div class="order-row total">
                            <span>Totali</span>
                            <span>{{ number_format($total, 2) }} €</span>
                        </div>
                    </div>

                    <button type="submit" class="checkout-btn">
                        <i class="fa-solid fa-check" style="font-size:13px;"></i>
                        Përfundo porosinë
                    </button>

                    <div class="secure-badge">
                        <i class="fa-solid fa-shield-halved" style="font-size:12px;"></i>
                        Transaksion i sigurt
                    </div>

                </div>
            </div>

        </div>
        </form>

    @endif
</div>
@endsection