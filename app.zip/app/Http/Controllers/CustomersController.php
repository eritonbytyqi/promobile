<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Order;

class CustomersController extends Controller
{
  public function index()
{
    $customers = \App\Models\User::where('role', 'customer')
        ->orderByDesc('created_at')
        ->paginate(20);

    // shto numrin e porosive për secilin klient
    $customers->getCollection()->transform(function ($customer) {
        $customer->orders_count_custom = \App\Models\Order::where('customer_email', $customer->email)->count();
        return $customer;
    });

    return view('customers.index', compact('customers'));
}
  public function orders($customerId)
{
    $customer = User::findOrFail($customerId);

    $orders = \App\Models\Order::where('customer_email', $customer->email)
        ->orderByDesc('created_at')
        ->paginate(15);

    return view('customers.orders', compact('customer', 'orders'));
}
}