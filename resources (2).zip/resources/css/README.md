# CSS Structure — MobiShop

## Organizimi

```
resources/css/
│
├── admin/
│   ├── layout.css        ← GJITHMONË i ngarkuar (sidebar, topbar, cards, forms, tables...)
│   ├── products.css      ← Vetëm te views/admin/products/*
│   ├── orders.css        ← Vetëm te views/admin/orders/*
│   ├── banners.css       ← Vetëm te views/admin/banners/*
│   ├── stock.css         ← Vetëm te views/admin/stock/*
│   ├── customers.css     ← Vetëm te views/admin/customers/*
│   ├── categories.css    ← Vetëm te views/admin/categories/*
│   ├── brands.css        ← Vetëm te views/admin/brands/*
│   └── settings.css      ← Vetëm te views/admin/settings/*
│
└── shop/
    ├── layout.css        ← GJITHMONË i ngarkuar (navbar, cart, footer, responsive...)
    ├── home.css          ← Vetëm te shop/pages/home.blade.php
    ├── products.css      ← Vetëm te shop/pages/products.blade.php
    ├── product-detail.css← Vetëm te shop/pages/product-detail.blade.php
    ├── checkout.css      ← Vetëm te shop/order/checkout.blade.php
    ├── payment.css       ← Vetëm te shop/order/stripe-payment.blade.php
    ├── order-success.css ← Vetëm te shop/order/success.blade.php
    ├── auth.css          ← Vetëm te shop/auth/*
    ├── profile.css       ← Vetëm te shop/profile/*
    ├── contact.css       ← Vetëm te shop/pages/contact.blade.php
    ├── static.css        ← Vetëm te terms.blade.php & privacy.blade.php
    └── partials.css      ← Vetëm kur ngarkon hero-carousel
```

## Si ta përdorësh

### Layout i ngarkuar automatikisht (layouts/admin.blade.php):
```html
<link rel="stylesheet" href="{{ asset('css/admin/layout.css') }}">
@stack('styles')
```

### Në çdo view specifike — shto @push('styles'):
```blade
@extends('layouts.admin')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/admin/products.css') }}">
@endpush

@section('content')
    ...
@endsection
```

## Kopjimi te public/

Kopjo të gjithë folderin `resources/css/` te `public/css/`:
```
public/
└── css/
    ├── admin/
    │   ├── layout.css
    │   ├── products.css
    │   └── ...
    └── shop/
        ├── layout.css
        ├── home.css
        └── ...
```

Ose nëse përdor **Vite**, shto në `vite.config.js`:
```js
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/admin/layout.css',
                'resources/css/shop/layout.css',
                // shto per-page CSS sipas nevojës
            ],
            refresh: true,
        }),
    ],
});
```
