@extends('client.layout')

@section('title', $product->name . ' — ProMobile')

@push('styles')
<link href="https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --pm-bg: #f5f5f7;
    --pm-surface: #ffffff;
    --pm-surface2: #f5f5f7;
    --pm-border: rgba(0,0,0,0.08);
    --pm-text: #1d1d1f;
    --pm-text-secondary: #6e6e73;
    --pm-blue: #0071e3;
    --pm-blue-dark: #0077ed;
    --pm-dark: #1d1d1f;
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--pm-bg); color: var(--pm-text); font-family: -apple-system, 'SF Pro Display', 'Helvetica Neue', sans-serif; }

.pm-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

/* ── BACK ── */
.pm-back {
    display: inline-flex; align-items: center; gap: 6px;
    color: var(--pm-blue); text-decoration: none;
    font-size: 14px; font-weight: 500;
    padding: 24px 0 16px; transition: opacity 0.2s;
}
.pm-back:hover { opacity: 0.7; }

/* ── MAIN GRID ── */
.pm-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 80px; align-items: start;
    padding: 24px 0 80px;
}

/* ── GALLERY ── */
.pm-gallery { position: sticky; top: 100px; }

.pm-img-main {
    background: var(--pm-surface);
    border-radius: 28px; overflow: hidden;
    aspect-ratio: 1;
    display: flex; align-items: center; justify-content: center;
    cursor: zoom-in; position: relative;
}
.pm-img-main img {
    width: 100%; height: 100%; object-fit: cover;
    transition: transform 0.5s cubic-bezier(.4,0,.2,1), opacity 0.2s;
}
.pm-img-main img.switching { opacity: 0; transform: scale(0.97); }
.pm-img-main:hover img { transform: scale(1.03); }
.pm-img-placeholder { font-size: 80px; color: #ccc; display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; }

.pm-thumbs { display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; }
.pm-thumb {
    width: 72px; height: 72px; border-radius: 14px;
    overflow: hidden; border: 2px solid transparent;
    background: var(--pm-surface); cursor: pointer;
    transition: all 0.2s; padding: 0;
}
.pm-thumb img { width: 100%; height: 100%; object-fit: cover; }
.pm-thumb.active { border-color: var(--pm-blue); }
.pm-thumb:hover { transform: translateY(-2px); }

/* ── INFO ── */
.pm-info { display: flex; flex-direction: column; gap: 0; }

.pm-title {
    font-size: clamp(32px, 4vw, 48px);
    font-weight: 800; letter-spacing: -1.5px;
    line-height: 1.05; color: var(--pm-dark);
    margin-bottom: 12px;
}
.pm-desc {
    font-size: 16px; color: var(--pm-text-secondary);
    line-height: 1.7; margin-bottom: 28px; font-weight: 400;
}

/* ── PRICE ── */
.pm-price-wrap {
    display: flex; align-items: baseline; gap: 12px;
    margin-bottom: 32px;
}
.pm-price { font-size: 36px; font-weight: 700; color: var(--pm-dark); transition: all 0.2s; }
.pm-price-old { font-size: 20px; color: var(--pm-text-secondary); text-decoration: line-through; }
.pm-price-badge { padding: 3px 10px; border-radius: 20px; background: #e8f4e8; color: #1a7a1a; font-size: 13px; font-weight: 600; }

/* ── SECTIONS ── */
.pm-section { margin-bottom: 28px; }
.pm-section-label {
    font-size: 13px; font-weight: 700;
    color: var(--pm-text-secondary);
    text-transform: uppercase; letter-spacing: 1px;
    margin-bottom: 14px;
    display: flex; align-items: center; gap: 8px;
}
.pm-section-label span {
    font-size: 14px; font-weight: 500;
    color: var(--pm-dark); letter-spacing: 0; text-transform: none;
}

/* ── NGJYRAT ── */
.pm-colors { display: flex; gap: 14px; flex-wrap: wrap; }
.pm-color { display: flex; flex-direction: column; align-items: center; gap: 6px; cursor: pointer; }
.pm-color-dot {
    width: 32px; height: 32px; border-radius: 50%;
    outline: 2px solid transparent; outline-offset: 3px;
    transition: all 0.2s;
    display: flex; align-items: center; justify-content: center;
    position: relative;
}
.pm-color:hover .pm-color-dot { transform: scale(1.1); }
.pm-color.active .pm-color-dot { outline-color: var(--pm-blue); }
.pm-color-check { position: absolute; color: white; font-size: 13px; opacity: 0; transition: opacity 0.2s; text-shadow: 0 1px 3px rgba(0,0,0,0.5); }
.pm-color.active .pm-color-check { opacity: 1; }
.pm-color-label { font-size: 11px; color: var(--pm-text-secondary); font-weight: 500; }
.pm-color.active .pm-color-label { color: var(--pm-blue); font-weight: 600; }

/* ── STORAGE ── */
.pm-storages { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.pm-storage {
    padding: 16px 18px; border-radius: 16px;
    border: 2px solid var(--pm-border);
    background: var(--pm-surface);
    cursor: pointer; transition: all 0.2s; text-align: left;
}
.pm-storage:hover { border-color: rgba(0,113,227,0.3); }
.pm-storage.active { border-color: var(--pm-blue); background: rgba(0,113,227,0.04); }
.pm-storage.out { opacity: 0.38; cursor: not-allowed; position: relative; }
.pm-storage.out::after {
    content: 'Jashtë stoku';
    position: absolute; bottom: calc(100% + 8px); left: 50%;
    transform: translateX(-50%);
    background: #1d1d1f; color: white; font-size: 11px; font-weight: 500;
    padding: 5px 10px; border-radius: 8px; white-space: nowrap;
    opacity: 0; pointer-events: none; transition: opacity 0.2s;
}
.pm-storage.out:hover::after { opacity: 1; }
.pm-storage-name { font-size: 16px; font-weight: 700; color: var(--pm-dark); display: block; margin-bottom: 3px; }
.pm-storage.active .pm-storage-name { color: var(--pm-blue); }
.pm-storage-price { font-size: 12px; color: var(--pm-text-secondary); }
.pm-storage.active .pm-storage-price { color: var(--pm-blue); }

/* ── TOAST ── */
.pm-toast {
    display: flex; align-items: center; gap: 10px;
    padding: 12px 16px; border-radius: 12px;
    background: var(--pm-surface2); border: 1px solid var(--pm-border);
    font-size: 13px; color: var(--pm-text-secondary);
    margin-bottom: 24px; transition: all 0.25s;
}
.pm-toast.ok { background: #f0f8f0; border-color: rgba(26,122,26,0.2); color: #1a7a1a; }

/* ── SPECS ── */
.pm-specs {
    background: var(--pm-surface); border-radius: 18px;
    overflow: hidden; margin-bottom: 24px;
    border: 1px solid var(--pm-border);
}
.pm-specs-head {
    padding: 14px 20px; border-bottom: 1px solid var(--pm-border);
    font-size: 11px; font-weight: 700; letter-spacing: 1px;
    text-transform: uppercase; color: var(--pm-text-secondary);
    display: flex; align-items: center; gap: 8px;
}
.pm-spec-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 11px 20px; border-bottom: 1px solid var(--pm-border); font-size: 14px;
}
.pm-spec-row:last-child { border-bottom: none; }
.pm-spec-row .sk { color: var(--pm-text-secondary); }
.pm-spec-row .sv { font-weight: 600; color: var(--pm-dark); text-align: right; }

/* ── DETAILS ── */
.pm-details {
    background: var(--pm-surface); border-radius: 18px;
    overflow: hidden; margin-bottom: 28px;
    border: 1px solid var(--pm-border);
}
.pm-details-head {
    padding: 14px 20px; border-bottom: 1px solid var(--pm-border);
    font-size: 11px; font-weight: 700; letter-spacing: 1px;
    text-transform: uppercase; color: var(--pm-text-secondary);
}
.pm-detail-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 11px 20px; border-bottom: 1px solid var(--pm-border); font-size: 14px;
}
.pm-detail-row:last-child { border-bottom: none; }
.pm-detail-row .dk { color: var(--pm-text-secondary); }
.pm-detail-row .dv { font-weight: 600; color: var(--pm-dark); text-align: right; }

/* ── STOCK ── */
.pm-stock {
    display: flex; align-items: center; gap: 8px;
    font-size: 14px; color: var(--pm-text-secondary); margin-bottom: 28px;
}
.pm-stock-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.pm-stock-dot.in  { background: #34c759; box-shadow: 0 0 8px rgba(52,199,89,0.5); }
.pm-stock-dot.low { background: #ff9500; }
.pm-stock-dot.out { background: #8e8e93; }

/* ── BUTTON ── */
/* ── BUTTON ── */
.pm-btn-primary {
    display: flex; align-items: center; justify-content: center; gap: 10px;
    width: 100%; padding: 17px; border-radius: 980px;
    background: #00bcd4; color: white; border: none;
    font-size: 16px; font-weight: 600; cursor: pointer;
    text-decoration: none; transition: all 0.3s ease;
    box-shadow: 0 4px 16px rgba(0,188,212,0.35); margin-bottom: 12px;
}
.pm-btn-primary:hover { background: #ff9800; transform: translateY(-1px); box-shadow: 0 8px 24px rgba(255,152,0,0.4); color: white; }
.pm-btn-primary.disabled { background: #e5e5ea; color: #8e8e93; cursor: not-allowed; box-shadow: none; transform: none !important; pointer-events: none; }
.pm-btn-primary.success { background: #34c759 !important; box-shadow: 0 4px 16px rgba(52,199,89,0.4) !important; pointer-events: none; }

/* ── POPUP ── */
.pm-popup-overlay {
    display: none; position: fixed; inset: 0; z-index: 99999;
    background: rgba(0,0,0,0.5); backdrop-filter: blur(8px);
    align-items: center; justify-content: center;
}
.pm-popup-overlay.open { display: flex; }
.pm-popup-box {
    background: #ffffff; border-radius: 28px; padding: 40px 36px 32px;
    max-width: 420px; width: calc(100% - 48px);
    text-align: center; position: relative;
    animation: popIn 0.3s cubic-bezier(.34,1.56,.64,1);
}
@keyframes popIn { from{opacity:0;transform:scale(0.85);}to{opacity:1;transform:scale(1);} }
.pm-popup-icon { width: 64px; height: 64px; border-radius: 50%; background: #f0fff4; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 28px; }
.pm-popup-title { font-size: 22px; font-weight: 800; color: #1d1d1f; letter-spacing: -0.5px; margin-bottom: 8px; }
.pm-popup-sub { font-size: 15px; color: #6e6e73; margin-bottom: 28px; line-height: 1.5; }
.pm-popup-btns { display: flex; flex-direction: column; gap: 10px; }
.pm-popup-btn-primary {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    padding: 15px; border-radius: 980px;
    background: #0071e3; color: white; border: none;
    font-size: 15px; font-weight: 600; cursor: pointer;
    text-decoration: none; transition: all 0.2s;
}
.pm-popup-btn-primary:hover { background: #0077ed; transform: translateY(-1px); color: white; }
.pm-popup-btn-secondary {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    padding: 15px; border-radius: 980px;
    background: #f5f5f7; color: #1d1d1f; border: none;
    font-size: 15px; font-weight: 600; cursor: pointer;
    text-decoration: none; transition: all 0.2s;
}
.pm-popup-btn-secondary:hover { background: #e8e8ed; }
.pm-popup-close { position: absolute; top: 16px; right: 16px; width: 32px; height: 32px; border-radius: 50%; background: #f5f5f7; border: none; cursor: pointer; font-size: 14px; color: #6e6e73; display: flex; align-items: center; justify-content: center; }
.pm-popup-close:hover { background: #e8e8ed; }
/* ── DELIVERY ── */
.pm-delivery { display: flex; justify-content: space-between; align-items: center; padding: 16px 0; border-top: 1px solid var(--pm-border); margin-top: 8px; }
.pm-delivery-item { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--pm-text-secondary); font-weight: 500; }

/* ── RELATED ── */
.pm-related { padding: 60px 0; }
.pm-related-title { font-size: 28px; font-weight: 800; letter-spacing: -0.5px; margin-bottom: 24px; }
.pm-related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px,1fr)); gap: 16px; }
.pm-related-card { background: var(--pm-surface); border-radius: 20px; overflow: hidden; text-decoration: none; color: inherit; transition: all 0.25s; border: 1px solid var(--pm-border); }
.pm-related-card:hover { transform: translateY(-4px); box-shadow: 0 12px 40px rgba(0,0,0,0.1); }
.pm-related-img { aspect-ratio: 1; background: var(--pm-surface2); overflow: hidden; }
.pm-related-img img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s; }
.pm-related-card:hover .pm-related-img img { transform: scale(1.05); }
.pm-related-img-ph { width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:40px; }
.pm-related-info { padding: 16px; }
.pm-related-name { font-size: 14px; font-weight: 600; margin-bottom: 5px; white-space:nowrap;overflow:hidden;text-overflow:ellipsis; }
.pm-related-price { font-size: 16px; font-weight: 700; color: var(--pm-dark); }

/* ── LIGHTBOX ── */
.pm-lightbox { display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.9);backdrop-filter:blur(20px);align-items:center;justify-content:center;cursor:zoom-out; }
.pm-lightbox.open { display:flex; }
.pm-lightbox img { max-width:90vw;max-height:90vh;object-fit:contain;border-radius:16px; }
.pm-lb-close { position:absolute;top:20px;right:20px;width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.15);border:none;color:white;font-size:18px;display:flex;align-items:center;justify-content:center;cursor:pointer; }
.pm-lb-nav { position:absolute;top:50%;transform:translateY(-50%);width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,0.15);border:none;color:white;font-size:16px;display:flex;align-items:center;justify-content:center;cursor:pointer; }
.pm-lb-prev { left:20px; } .pm-lb-next { right:20px; }
@keyframes lbIn { from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);} }

@media (max-width: 768px) {
    .pm-grid { grid-template-columns:1fr; gap:32px; }
    .pm-gallery { position:static; }
    .pm-storages { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
    .pm-related-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }

    .pm-related-card { border-radius: 14px; }

    .pm-related-img { aspect-ratio: 1; }

    .pm-related-info { padding: 10px; }

    .pm-related-name {
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 3px;
    }

    .pm-related-price { font-size: 14px; }

    .pm-related { padding: 32px 0; }

    .pm-related-title { font-size: 20px; margin-bottom: 16px; }
}
</style>
@endpush

@section('content')

@php
$variants      = $product->variants ?? collect();
$variantImages = $product->variantImages ?? collect();
$hasVariants   = $variants->count() > 0;
$images        = $product->images ?? collect();
$specs         = $product->specs ?? collect();

$garancia = $specs->firstWhere('spec_key', 'Garancia');
$dergesa  = $specs->firstWhere('spec_key', 'Dërgesa');

$variantGroups = $variants->groupBy(function ($v) {
    return strtolower(trim(($v->color_hex ?? ''))) . '||' . strtolower(trim(($v->color_name ?? '')));
});

$variantImageGroups = $variantImages->groupBy(function ($img) {
    return strtolower(trim(($img->color_hex ?? ''))) . '||' . strtolower(trim(($img->color_name ?? '')));
});

$allColorKeys = $variantGroups->keys()->merge($variantImageGroups->keys())->unique();

$colorGroups = $allColorKeys->map(function ($key) use ($variantGroups, $variantImageGroups) {
    [$hex, $name] = array_pad(explode('||', $key, 2), 2, '');

    $groupVariants = $variantGroups->get($key, collect());
    $groupImages   = $variantImageGroups->get($key, collect());

    $imgs = $groupImages
        ->sortBy([
            ['is_primary', 'desc'],
            ['sort_order', 'asc'],
            ['id', 'asc'],
        ])
        ->pluck('image_path')
        ->filter()
        ->unique()
        ->values()
        ->map(fn($p) => asset('storage/' . $p))
        ->toArray();

$storages = $groupVariants->map(fn($v) => [
    'id'          => $v->id,
    'storage'     => $v->storage ?? '',
    'price'       => (float)($v->price ?? 0),
    'base_price'  => (float)($v->base_price ?? 0),
    'extra_price' => (float)($v->extra_price ?? 0),
    'sale_price'  => $v->sale_price !== null ? (float)$v->sale_price : null,
    'stock'       => (int)($v->stock ?? 0),
])->values()->toArray();

    return [
        'color_hex'  => $hex,
        'color_name' => $name,
        'images'     => $imgs,
        'storages'   => $storages,
    ];
})->values();

/* fotot bazë të produktit */
$productImages = $images->sortByDesc('is_primary')->values();

/* foto fillestare = fotoja kryesore e produktit */
$mainSrc = null;
$primary = $productImages->firstWhere('is_primary', true) ?? $productImages->first();

if ($primary) {
    $mainSrc = asset('storage/' . $primary->image_path);
} elseif (!empty($product->image)) {
    $mainSrc = asset('storage/' . $product->image);
}

/* çmimi fillestar */
/* çmimi fillestar — merr nga varianti i parë me stok, ose varianti i parë */
$firstVariant = $variants->first();

$basePrice    = $product->price ?? 0;
$baseOldPrice = ($product->sale_price && $product->sale_price < $product->price)
                ? $product->price
                : null;
$basePrice    = $baseOldPrice ? $product->sale_price : $basePrice;

/* stock fillestar */
$initStock = (int)($product->stock ?? 0);
$hasVariants = $variants->count() > 0 && $colorGroups->count() > 0;

@endphp

<div class="pm-wrap">

    <a href="{{ url('/shop') }}" class="pm-back">
        <i class="fa-solid fa-chevron-left" style="font-size:12px;"></i>
        Produktet
    </a>

    <div class="pm-grid">

        {{-- ═══════════ GALERIA ═══════════ --}}
        <div class="pm-gallery">
            <div class="pm-img-main" id="mainImgWrap">
                @if($mainSrc)
                    <img id="mainImg" src="{{ $mainSrc }}" alt="{{ $product->name }}">
                @else
                    <div class="pm-img-placeholder"><i class="fa-solid fa-box"></i></div>
                @endif
            </div>

            {{-- Thumbs të produktit bazë --}}
            @if($productImages->count() > 1)
            <div class="pm-thumbs" id="productThumbs">
                @foreach($productImages as $i => $img)
                <button type="button"
                        class="pm-thumb {{ $i === 0 ? 'active' : '' }}"
                        onclick="switchImage(this, '{{ asset('storage/'.$img->image_path) }}')">
                    <img src="{{ asset('storage/'.$img->image_path) }}" alt="foto {{ $i+1 }}" loading="lazy">
                </button>
                @endforeach
            </div>
            @endif

            {{-- Thumbs të variantit aktiv --}}
            <div id="colorGallerySection" style="display:none;">
                <div class="pm-thumbs" id="colorGallery"></div>
            </div>
        </div>

        {{-- ═══════════ INFO ═══════════ --}}
        <div class="pm-info">

            <h1 class="pm-title">{{ $product->name }}</h1>

            @if($product->description)
                <p class="pm-desc">{{ $product->description }}</p>
            @endif

            {{-- ── ÇMIMI ── --}}
            <div class="pm-price-wrap">
                <div class="pm-price" id="priceMain">
                    {{ number_format($basePrice, 2) }} €
                </div>
                <div class="pm-price-old" id="priceOld" style="{{ $baseOldPrice ? '' : 'display:none;' }}">
                    @if($baseOldPrice){{ number_format($baseOldPrice, 2) }} €@endif
                </div>
                <span class="pm-price-badge" id="priceBadge" style="{{ $baseOldPrice ? '' : 'display:none;' }}">
                    @if($baseOldPrice)-{{ round((($baseOldPrice - $basePrice) / $baseOldPrice) * 100) }}%@endif
                </span>
            </div>

            {{-- ── STOCK ── --}}
            <div class="pm-stock">
                <span class="pm-stock-dot {{ $initStock > 10 ? 'in' : ($initStock > 0 ? 'low' : 'out') }}" id="stockDot"></span>
                <span id="stockText">
                    @if($initStock > 10) Në stok — {{ $initStock }} të mbetur
                    @elseif($initStock > 0) Vetëm {{ $initStock }} të mbetur!
                    @else Jashtë stoku
                    @endif
                </span>
            </div>

            {{-- ══════════ VARIANT SELECTORS ══════════ --}}
            @if($hasVariants)
            <div class="pm-toast" id="variantToast">
                <i class="fa-solid fa-hand-pointer" style="color:var(--pm-blue);flex-shrink:0;"></i>
                <span id="variantToastText">Zgjedh ngjyrën dhe storage-in për çmimin e saktë</span>
            </div>

            {{-- ── NGJYRAT ── --}}
            @if($colorGroups->count() > 0)
            <div class="pm-section">
                <div class="pm-section-label">
                    Finish. <span id="colorLabel">Zgjidh ngjyrën tënde.</span>
                </div>
                <div class="pm-colors">
                    @foreach($colorGroups as $cg)
                    <div class="pm-color"
                         data-color="{{ $cg['color_name'] }}"
                         onclick="selectColor(this, '{{ $cg['color_name'] }}')">
                        <div class="pm-color-dot" style="background:{{ $cg['color_hex'] ?? '#ccc' }};">
                            <i class="fa-solid fa-check pm-color-check"></i>
                        </div>
                        <span class="pm-color-label">{{ $cg['color_name'] }}</span>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif

            {{-- ── STORAGE ── --}}
            <div class="pm-section" id="storageSection" style="display:none;">
                <div class="pm-section-label">
                    Storage. <span id="storageLabel">Sa hapësirë të nevojitet?</span>
                </div>
                <div class="pm-storages" id="storageGrid"></div>
            </div>

            @endif {{-- /hasVariants --}}

            {{-- ── BUTONI ── --}}
        {{-- ── BUTONI ── --}}
<div style="display:flex;gap:10px;align-items:center;margin-bottom:12px;">
    <button id="orderBtn" type="button" class="pm-btn-primary" style="margin-bottom:0;flex:1;" onclick="addCurrentProductToCart(this)">
        <i class="fa-solid fa-bag-shopping"></i>
        <span id="orderBtnText">Shto në shportë</span>
    </button>

    <button id="detailWishBtn" type="button"
            data-id="{{ $product->id }}"
            data-name="{{ addslashes($product->name) }}"
            data-price="{{ number_format($basePrice, 2) }}"
            data-img="{{ $mainSrc ?? '' }}"
            data-url="{{ url('/shop/'.$product->id) }}"
            data-cat="{{ $product->category->name ?? '' }}"
            onclick="toggleWish(this)"
            style="
                width:54px; height:54px; flex-shrink:0;
                border-radius:50%;
                background:#f5f5f7;
                border:1px solid rgba(0,0,0,0.1);
                display:flex; align-items:center; justify-content:center;
                font-size:20px; color:#ccc;
                cursor:pointer;
                transition:all 0.22s cubic-bezier(.4,0,.2,1);
            ">
        <i class="fa-regular fa-heart"></i>
    </button>
</div>
            {{-- ── DELIVERY ── --}}
            <div class="pm-delivery">
                <div class="pm-delivery-item">
                    <i class="fa-solid fa-truck" style="color:var(--pm-blue);"></i>
                    {{ $dergesa ? $dergesa->spec_value : 'Dërgesa Falas' }}
                </div>
                @if($garancia)
                <div class="pm-delivery-item">
                    <i class="fa-solid fa-shield-halved" style="color:var(--pm-blue);"></i>
                    Garanci {{ $garancia->spec_value }}
                </div>
                @endif
            </div>

            {{-- ── SPECS ── --}}
            @if($specs->count() > 0)
            <div class="pm-specs">
                <div class="pm-specs-head">
                    <i class="fa-solid fa-list-check"></i>
                    Karakteristikat Teknike
                </div>
                @foreach($specs as $spec)
                <div class="pm-spec-row">
                    <span class="sk">{{ $spec->spec_key }}</span>
                    <span class="sv">{{ $spec->spec_value }}</span>
                </div>
                @endforeach
            </div>
            @endif

            {{-- ── DETAJE ── --}}
            <div class="pm-details">
                <div class="pm-details-head">Detajet e Produktit</div>
                @if($product->category)
                <div class="pm-detail-row">
                    <span class="dk">Kategoria</span>
                    <span class="dv">{{ $product->category->name }}</span>
                </div>
                @endif
                @if($product->brand)
                <div class="pm-detail-row">
                    <span class="dk">Brendi</span>
                    <span class="dv">{{ $product->brand->name }}</span>
                </div>
                @endif
                @if(!$hasVariants)
                <div class="pm-detail-row">
                    <span class="dk">Stoku</span>
                    <span class="dv">
                        @if(($product->stock ?? 0) > 0) {{ $product->stock }} copë
                        @else <span style="color:#ff3b30;">Jashtë stoku</span>
                        @endif
                    </span>
                </div>
                @endif
                <div class="pm-detail-row">
                    <span class="dk">Statusi</span>
                    <span class="dv">
                        @if($product->is_active)
                            <span style="color:#34c759;">● Aktiv</span>
                        @else
                            <span style="color:#8e8e93;">Joaktiv</span>
                        @endif
                    </span>
                </div>
            </div>

        </div>
        {{-- /INFO --}}
    </div>

    {{-- ═══ RELATED ═══ --}}
    @if(isset($related) && $related->count() > 0)
    <div class="pm-related">
        <h2 class="pm-related-title">Aksesore të rekomanduar</h2>
        <div class="pm-related-grid">
            @foreach($related as $rel)
            @php
                $relImg = $rel->images?->firstWhere('is_primary', true) ?? $rel->images?->first();
                $relSrc = $relImg ? asset('storage/'.$relImg->image_path)
                        : ($rel->image ? asset('storage/'.$rel->image) : null);
                $relGroup = $rel->variants?->first();
                $relPrice = $relGroup
                    ? (($relGroup->sale_price && $relGroup->sale_price < $relGroup->price) ? $relGroup->sale_price : $relGroup->price)
                    : (($rel->sale_price && $rel->sale_price < $rel->price) ? $rel->sale_price : $rel->price);
            @endphp
            <a href="{{ url('/shop/'.$rel->id) }}" class="pm-related-card">
                <div class="pm-related-img">
                    @if($relSrc)
                        <img src="{{ $relSrc }}" alt="{{ $rel->name }}" loading="lazy">
                    @else
                        <div class="pm-related-img-ph"><i class="fa-solid fa-box"></i></div>
                    @endif
                </div>
                <div class="pm-related-info">
                    <div class="pm-related-name">{{ $rel->name }}</div>
                    <div class="pm-related-price">{{ number_format($relPrice, 2) }} €</div>
                </div>
            </a>
            @endforeach
        </div>
    </div>
    @endif

</div>
{{-- LIGHTBOX --}}
<div class="pm-lightbox" id="lightbox">
    <button class="pm-lb-close" onclick="closeLightbox()"><i class="fa-solid fa-xmark"></i></button>
    <button class="pm-lb-nav pm-lb-prev" onclick="lbNav(-1)" id="lbPrev" style="display:none;"><i class="fa-solid fa-chevron-left"></i></button>
    <button class="pm-lb-nav pm-lb-next" onclick="lbNav(1)"  id="lbNext" style="display:none;"><i class="fa-solid fa-chevron-right"></i></button>
    <img id="lbImg" src="" alt="" style="animation:lbIn 0.25s ease;">
</div>

{{-- POPUP --}}
<div class="pm-popup-overlay" id="cartPopup">
    <div class="pm-popup-box">
        <button class="pm-popup-close" onclick="closeCartPopup()"><i class="fa-solid fa-xmark"></i></button>
        <div class="pm-popup-icon">✓</div>
        <div class="pm-popup-title">U shtua në shportë!</div>
        <div class="pm-popup-sub">Produkti u shtua me sukses. Çfarë dëshiron të bësh tani?</div>
        <div class="pm-popup-btns">
            <a href="/checkout" class="pm-popup-btn-primary">
                <i class="fa-solid fa-credit-card"></i>
                Vazhdo me pagesën
            </a>
            <button class="pm-popup-btn-secondary" onclick="closeCartPopup()">
                <i class="fa-solid fa-arrow-left"></i>
                Vazhdo blerjen
            </button>
               {{-- SHTO KËTË --}}
    <div style="border-top:1px solid #f0f0f0; margin-top:8px; padding-top:12px; text-align:center;">
        @auth
            <a href="{{ route('profile.index') }}" style="
                display:inline-flex; align-items:center; gap:6px;
                font-size:13px; font-weight:600; color:var(--primary);
                text-decoration:none;
            ">
                <span class="material-symbols-outlined" style="font-size:16px;">person</span>
                Shiko porositë & profilin tim
            </a>
        @else
            <p style="font-size:12px; color:#6e6e73; margin-bottom:8px;">
                Kyçu për të ruajtur porositë dhe të dhënat tuaja
            </p>
            <a href="{{ route('login') }}" style="
                display:inline-flex; align-items:center; gap:6px;
                padding:8px 18px; background:var(--primary);
                color:white; border-radius:999px;
                font-size:13px; font-weight:700; text-decoration:none;
            ">
                <span class="material-symbols-outlined" style="font-size:15px;">login</span>
                Kyçu tani
            </a>
        @endauth
    </div>
</div>
        </div>
    </div>
</div>

@endsection
@push('scripts')
<script>
const colorGroups = @json($colorGroups);
const PRODUCT_ID = {{ $product->id }};
const BASE_PRICE = {{ (float) $basePrice }};
const BASE_OLD   = {!! $baseOldPrice ? (float)$baseOldPrice : 'null' !!};
const BASE_STOCK = {{ (int)($product->stock ?? 0) }};

let selColorName = null;
let selVariantId = null;

function getGroup(colorName) {
    if (!colorName) return null;
    return colorGroups.find(g => g.color_name === colorName) || null;
}

function getStorage(group, variantId) {
    if (!group || !variantId) return null;
    return group.storages.find(s => s.id == variantId) || null;
}

function selectColor(el, name) {
    if (selColorName === name && el.classList.contains('active')) {
        selColorName = null;
        selVariantId = null;
        el.classList.remove('active');
        renderStorages(null);
        renderColorGallery(null);
        refreshUI();
        return;
    }

    selColorName = name;
    selVariantId = null;

    const orderBtn = document.getElementById('orderBtn');
    orderBtn.classList.remove('success');
    document.getElementById('orderBtnText').textContent = 'Shto në shportë';

    document.querySelectorAll('.pm-color').forEach(c => c.classList.remove('active'));
    el.classList.add('active');

    const lbl = document.getElementById('colorLabel');
    if (lbl) lbl.textContent = name;

    const group = getGroup(name);
    const firstAvail = group?.storages?.find(s => s.stock > 0) || group?.storages?.[0] || null;
    if (firstAvail) selVariantId = firstAvail.id;

    renderStorages(group);
    renderColorGallery(group);

    document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));

    if (group && group.images.length > 0) switchMainImgDirect(group.images[0]);

    refreshUI();
}

function selectStorage(el) {
    const variantId = parseInt(el.dataset.variantId);
    if (!variantId) return;

    selVariantId = variantId;

    const orderBtn = document.getElementById('orderBtn');
    orderBtn.classList.remove('success');
    document.getElementById('orderBtnText').textContent = 'Shto në shportë';

    document.querySelectorAll('.pm-storage').forEach(s => s.classList.remove('active'));
    el.classList.add('active');

    const group = getGroup(selColorName);
    const storage = group?.storages?.find(s => s.id === variantId);
    const lbl = document.getElementById('storageLabel');
    if (lbl && storage) lbl.textContent = storage.storage || '';

    refreshUI();
}

function renderStorages(group) {
    const grid    = document.getElementById('storageGrid');
    const section = document.getElementById('storageSection');
    if (!grid || !section) return;

    const storages = (group?.storages || []).filter(s => s.storage && s.storage.trim() !== '');

    if (!group || !storages.length) {
        section.style.display = 'none';
        grid.innerHTML = '';
        return;
    }

    section.style.display = '';
    grid.innerHTML = '';

    storages.forEach((sv, i) => {
        const totalPrice = sv.sale_price ?? sv.price;
        const extra      = sv.extra_price ?? 0;
        const isOut      = sv.stock <= 0;
        const isActive   = sv.id === selVariantId || (!selVariantId && i === 0);

        const btn = document.createElement('div');
        btn.className = 'pm-storage' + (isActive ? ' active' : '') + (isOut ? ' out' : '');
        btn.dataset.storage   = sv.storage;
        btn.dataset.variantId = sv.id;

        btn.innerHTML = `
            <span class="pm-storage-name">${sv.storage}</span>
            <span class="pm-storage-price">${
                isOut ? 'Jashtë stoku' : (extra > 0 ? '+' + extra.toFixed(2) + ' €' : 'Bazë')
            }</span>
        `;

        if (!isOut) btn.addEventListener('click', () => selectStorage(btn));

        grid.appendChild(btn);
    });
}

function renderColorGallery(group) {
    const section = document.getElementById('colorGallerySection');
    const gallery = document.getElementById('colorGallery');
    if (!section || !gallery) return;

    gallery.innerHTML = '';
    const imgs = group?.images || [];

    if (!group || imgs.length === 0) {
        section.style.display = 'none';
        return;
    }

    section.style.display = '';

    imgs.forEach((src, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pm-thumb' + (i === 0 ? ' active' : '');
        btn.innerHTML = `<img src="${src}" alt="foto ${i + 1}" loading="lazy">`;

        btn.addEventListener('click', () => {
            document.querySelectorAll('#colorGallery .pm-thumb').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            switchMainImgDirect(src);
        });

        gallery.appendChild(btn);
    });
}

function switchImage(btn, src) {
    document.querySelectorAll('#colorGallery .pm-thumb').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    switchMainImgDirect(src);
    currentIdx = allProductSrcs.indexOf(src);
    if (currentIdx < 0) currentIdx = 0;
}

function switchMainImgDirect(src) {
    const img = document.getElementById('mainImg');
    if (!img) return;
    img.classList.add('switching');
    setTimeout(() => {
        img.src = src;
        img.onload = () => img.classList.remove('switching');
        setTimeout(() => img.classList.remove('switching'), 400);
    }, 150);
}

const allProductSrcs = [
    @foreach($productImages as $img)
        '{{ asset('storage/'.$img->image_path) }}',
    @endforeach
    @foreach($colorGroups as $cg)
        @foreach($cg['images'] as $imgSrc)
            '{{ $imgSrc }}',
        @endforeach
    @endforeach
];
let currentIdx = 0;

function refreshUI() {
    const group   = getGroup(selColorName);
    const storage = getStorage(group, selVariantId);
        const basePrice  = group?.storages?.[0]?.base_price ?? BASE_PRICE;

     const extraPrice = storage?.extra_price ?? 0;
    const finalPrice = storage
        ? (storage.sale_price ?? (basePrice + extraPrice))
        : BASE_PRICE;
    const stock = storage ? storage.stock : BASE_STOCK;

    const priceEl = document.getElementById('priceMain');
    priceEl.style.opacity = '0';
    const hasSelection = storage !== null;
 setTimeout(() => {
    const hasVariants = colorGroups.length > 0;
    if (hasSelection) {
        priceEl.innerHTML = finalPrice.toFixed(2) + ' €';
    } else if (hasVariants) {
        priceEl.innerHTML = '<span style="font-size:16px;font-weight:500;color:#6e6e73;letter-spacing:0;margin-right:4px;">nga</span>' + finalPrice.toFixed(2) + ' €';
    } else {
        priceEl.innerHTML = finalPrice.toFixed(2) + ' €';
    }
    priceEl.style.opacity = '1';
}, 150);

   const oldEl   = document.getElementById('priceOld');
const badgeEl = document.getElementById('priceBadge');
if (BASE_OLD) {
    const pct = Math.round(((BASE_OLD - finalPrice) / BASE_OLD) * 100);
    oldEl.textContent = BASE_OLD.toFixed(2) + ' €';
    oldEl.style.display = '';
    badgeEl.textContent = '-' + pct + '%';
    badgeEl.style.display = '';
} else {
    oldEl.style.display = 'none';
    badgeEl.style.display = 'none';
}

    const dot = document.getElementById('stockDot');
    const txt = document.getElementById('stockText');
    dot.className = 'pm-stock-dot';
    if (stock > 10) {
        dot.classList.add('in');
        txt.textContent = 'Në stok — ' + stock + ' të mbetur';
    } else if (stock > 0) {
        dot.classList.add('low');
        txt.textContent = 'Vetëm ' + stock + ' të mbetur!';
    } else {
        dot.classList.add('out');
        txt.textContent = 'Jashtë stoku';
    }

    const btn    = document.getElementById('orderBtn');
    const btnTxt = document.getElementById('orderBtnText');
    if (stock <= 0) {
        btn.classList.add('disabled');
        btnTxt.textContent = 'Jashtë Stoku';
    } else {
        btn.classList.remove('disabled');
        btnTxt.textContent = 'Shto në shportë';
    }

    const toast    = document.getElementById('variantToast');
    const toastTxt = document.getElementById('variantToastText');
    if (!toast) return;

    if (!group) {
        toast.classList.remove('ok');
        toastTxt.innerHTML = 'Zgjedh ngjyrën për të parë fotot, storage dhe çmimin e variantit';
        return;
    }

    if (storage) {
        toast.classList.add('ok');
        const parts = [];
        if (group?.color_name) parts.push(group.color_name);
        if (storage.storage)   parts.push(storage.storage);
        toastTxt.innerHTML = '✓ ' + parts.join(' · ') + ' — <strong>' + finalPrice.toFixed(2) + ' €</strong>';
    } else {
        toast.classList.remove('ok');
        toastTxt.innerHTML = '✓ ' + (group?.color_name || 'Ngjyra') + ' — zgjidh storage';
    }
}

const lb    = document.getElementById('lightbox');
const lbImg = document.getElementById('lbImg');

document.getElementById('mainImgWrap')?.addEventListener('click', () => {
    const src = document.getElementById('mainImg')?.src;
    if (!src) return;
    lbImg.src = src;
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
    const many = allProductSrcs.length > 1;
    document.getElementById('lbPrev').style.display = many ? 'flex' : 'none';
    document.getElementById('lbNext').style.display = many ? 'flex' : 'none';
});

function closeLightbox() {
    lb.classList.remove('open');
    document.body.style.overflow = '';
}

function lbNav(dir) {
    currentIdx = (currentIdx + dir + allProductSrcs.length) % allProductSrcs.length;
    lbImg.style.opacity = '0';
    setTimeout(() => {
        lbImg.src = allProductSrcs[currentIdx];
        lbImg.style.opacity = '1';
    }, 150);
}

lb?.addEventListener('click', e => { if (e.target === lb) closeLightbox(); });

document.addEventListener('keydown', e => {
    if (!lb?.classList.contains('open')) return;
    if (e.key === 'Escape')     closeLightbox();
    if (e.key === 'ArrowRight') lbNav(1);
    if (e.key === 'ArrowLeft')  lbNav(-1);
});

function addCurrentProductToCart(button) {
    const group   = getGroup(selColorName);
    const storage = getStorage(group, selVariantId);
    const payload = { product_id: PRODUCT_ID, quantity: 1 };
    if (storage) payload.variant_id = storage.id;

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            document.getElementById('cartPopup').classList.add('open');
            document.body.style.overflow = 'hidden';
            button.classList.add('success');
            document.getElementById('orderBtnText').textContent = 'U shtua ✓';

            if (typeof openCart === 'function') openCart();
            if (data.cart_html && document.getElementById('csBody'))
                document.getElementById('csBody').innerHTML = data.cart_html;
            if (typeof data.cart_count !== 'undefined') {
                const badge = document.getElementById('csCountBadge');
                if (badge) {
                    badge.textContent = data.cart_count;
                    badge.style.display = data.cart_count > 0 ? '' : 'none';
                }
            }
            if (typeof data.cart_total !== 'undefined') {
                const total = document.getElementById('csTotal');
                if (total) total.textContent = data.cart_total + ' €';
            }
        }
    })
    .catch(console.error);
}

function closeCartPopup() {
    document.getElementById('cartPopup').classList.remove('open');
    document.body.style.overflow = '';
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('priceMain').style.transition = 'opacity 0.15s';
    refreshUI();
    document.getElementById('cartPopup')?.addEventListener('click', function(e) {
        if (e.target === this) closeCartPopup();
    });

    // Inicializo zemrën
    const btn = document.getElementById('detailWishBtn');
    if (!btn) return;
    const wish = getWish();
    const id   = btn.dataset.id;
    if (wish[id]) {
        btn.querySelector('i').className = 'fa-solid fa-heart';
        btn.style.color = '#ff3b30';
        btn.style.background = 'rgba(255,59,48,0.08)';
        btn.style.borderColor = 'rgba(255,59,48,0.2)';
    }
});
(function() {
    const btn = document.getElementById('detailWishBtn');
    if (!btn) return;
    const wish = getWish();
    const id   = btn.dataset.id;
    if (wish[id]) {
        btn.querySelector('i').className = 'fa-solid fa-heart';
        btn.style.color = '#ff3b30';
        btn.style.background = 'rgba(255,59,48,0.08)';
        btn.style.borderColor = 'rgba(255,59,48,0.2)';
    }
})();
</script>
@endpush