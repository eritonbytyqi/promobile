@extends('layouts.admin')

@section('title', 'Klientët')
@section('page-title', 'Klientët')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/admin/customers.css') }}">
@endpush

@section('content')
@php
    $totalCustomers = $customers->total();
    $newThisMonth = $customers->getCollection()->filter(fn($c) => $c->created_at && $c->created_at->isCurrentMonth())->count();
    $withPhone = $customers->getCollection()->filter(fn($c) => !empty($c->phone))->count();
@endphp

<div class="customers-wrap">

    <div class="customers-stats">
        <div class="c-stat">
            <div class="c-stat-label">Gjithsej klientë</div>
            <div class="c-stat-value">{{ $totalCustomers }}</div>
        </div>

        <div class="c-stat">
            <div class="c-stat-label">Të rinj këtë muaj</div>
            <div class="c-stat-value">{{ $newThisMonth }}</div>
        </div>

        <div class="c-stat">
            <div class="c-stat-label">Me numër telefoni</div>
            <div class="c-stat-value">{{ $withPhone }}</div>
        </div>
    </div>

    <div class="customers-card">
        <div class="customers-head">
            <div>
                <div class="customers-title">Lista e Klientëve</div>
                <div class="customers-sub">Të gjithë përdoruesit me rolin customer.</div>
            </div>
        </div>

        @if($customers->count())
            <div class="customers-table-wrap">
                <table class="customers-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Klienti</th>
                            <th>Email</th>
                            <th>Telefoni</th>
                            <th>Data e regjistrimit</th>
                            <th>Porositë</th>
                            <th>Statusi</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach($customers as $c)
                            <tr>
       <td>
    {{ $c->orders_count_custom }}
</td>

                                <td>
                                    <div class="customer-main">
                                        <div class="customer-avatar">
                                            {{ strtoupper(substr($c->name ?? 'C', 0, 1)) }}
                                        </div>
                                        <div>
                                            <div class="customer-name">
                                                {{ $c->name }} {{ $c->surname ?? '' }}
                                            </div>
                                            <div class="customer-meta">
                                                Klient i regjistruar
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <div class="customer-email">{{ $c->email }}</div>
                                </td>

                                <td>
                                    @if(!empty($c->phone))
                                        <div class="customer-phone">{{ $c->phone }}</div>
                                    @else
                                        <div class="customer-phone muted">Pa numër</div>
                                    @endif
                                </td>

                                <td>
                                    <div class="customer-date">
                                        <div class="customer-date-main">
                                            {{ $c->created_at?->format('d.m.Y') }}
                                        </div>
                                        <div class="customer-date-sub">
                                            {{ $c->created_at?->format('H:i') }}
                                        </div>
                                    </div>
                                </td>
<td>
    <a href="{{ route('admin.customers.orders', $c->id) }}"
       class="btn btn-sm btn-ghost">
        <i class="fa-solid fa-box"></i> Porositë
    </a>
</td>
                                <td>
                                    <span class="customer-badge">Customer</span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap">
                {{ $customers->links() }}
            </div>
        @else
            <div class="empty-customers">
                <i class="fa-solid fa-users"></i>
                <div style="font-size:16px;font-weight:800;margin-bottom:6px;">Nuk ka klientë ende</div>
                <div style="font-size:13px;">Kur të regjistrohen përdorues me rolin customer, do të shfaqen këtu.</div>
            </div>
        @endif
    </div>

</div>
@endsection
