@extends('layouts.shop')

@section('title', 'Profili im – ProMobile')

@push('styles')
@endpush

@section('content')
<div class="profile-page">

    {{-- ── LEFT: Forma ── --}}
    <div class="profile-left">

        <div class="profile-header">
            <div class="profile-avatar">{{ strtoupper(substr($user->name, 0, 1)) }}</div>
            <div>
                <div class="profile-name">{{ $user->name }} {{ $user->surname }}</div>
                <div class="profile-email">{{ $user->email }}</div>
            </div>
        </div>

        @if(session('success'))
            <div class="alert-success">
                <span class="material-symbols-outlined" style="font-size:17px;">check_circle</span>
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="alert-error">
                <span class="material-symbols-outlined" style="font-size:17px;">error</span>
                {{ session('error') }}
            </div>
        @endif

        {{-- Forma kryesore --}}
        <form method="POST" action="{{ route('profile.update') }}">
            @csrf

            {{-- Të dhënat personale --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">person</span> Të dhënat personale
                </div>
                <div class="profile-grid">
                    <div class="profile-field">
                        <label>Emri</label>
                        <input type="text" name="name" placeholder="Emri" value="{{ old('name', $user->name) }}" required />
                        @error('name')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Mbiemri</label>
                        <input type="text" name="surname" placeholder="Mbiemri" value="{{ old('surname', $user->surname ?? '') }}" />
                    </div>
                    <div class="profile-field full">
                        <label>Telefoni</label>
                        <input type="text" name="phone" placeholder="+383 4X XXX XXX" value="{{ old('phone', $user->phone ?? '') }}" />
                    </div>
                </div>
            </div>

            {{-- Adresa --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">location_on</span> Adresa e dorëzimit
                </div>
                <div class="profile-grid">
                    <div class="profile-field full">
                        <label>Adresa</label>
                        <input type="text" name="address_line_1" placeholder="Rr. Nënë Tereza, Nr. 10" value="{{ old('address_line_1', $address->address_line_1 ?? '') }}" />
                    </div>
                    <div class="profile-field">
                        <label>Qyteti</label>
                        <input type="text" name="city" placeholder="Prishtinë" value="{{ old('city', $address->city ?? '') }}" />
                    </div>
                    <div class="profile-field">
                        <label>Kodi Postar</label>
                        <input type="text" name="postal_code" placeholder="10000" value="{{ old('postal_code', $address->postal_code ?? '') }}" />
                    </div>
                    <div class="profile-field full">
                        <label>Shteti</label>
                        <input type="text" name="country" placeholder="Kosovë" value="{{ old('country', $address->country ?? 'Kosovë') }}" />
                    </div>
                </div>
            </div>

            {{-- Ndrysho passwordin (brenda së njëjtës formë) --}}
            <div class="profile-card">
                <div class="profile-card-title">
                    <span class="material-symbols-outlined">lock</span> Ndrysho fjalëkalimin
                </div>
                <div class="profile-grid">
                    <div class="profile-field full">
                        <label>Fjalëkalimi aktual</label>
                        <input type="password" name="current_password" placeholder="••••••••" />
                        @error('current_password')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Fjalëkalimi i ri</label>
                        <input type="password" name="password" placeholder="••••••••" />
                        @error('password')<span class="field-error">{{ $message }}</span>@enderror
                    </div>
                    <div class="profile-field">
                        <label>Përsërit fjalëkalimin</label>
                        <input type="password" name="password_confirmation" placeholder="••••••••" />
                    </div>
                </div>
                <p style="font-size:11.5px; color:var(--text-muted); margin-top:10px;">
                    Lëre bosh nëse nuk dëshiron të ndryshosh fjalëkalimin.
                </p>
            </div>

            <button type="submit" class="profile-btn">
                <span class="material-symbols-outlined" style="font-size:18px;">save</span>
                Ruaj ndryshimet
            </button>
        </form>

    </div>

    {{-- ── RIGHT: Orders sidebar ── --}}
    <div class="orders-sidebar">
        <div class="orders-sidebar-header">
            <div class="orders-sidebar-title">
                <span class="material-symbols-outlined">shopping_bag</span>
                Porositë e mia
            </div>
            @if(isset($orders) && $orders->count() > 0)
                <span class="orders-count-badge">{{ $orders->count() }}</span>
            @endif
        </div>

        <div class="orders-sidebar-body">
            @if(isset($orders) && $orders->count() > 0)
                @foreach($orders as $order)
                    <div class="order-item">
                        <div class="order-item-top">
                            <span class="order-id">#{{ $order->id }}</span>
                            <span class="order-total">{{ number_format($order->total_amount, 2) }} €</span>
                        </div>
                        <div class="order-item-bot">
                            <span class="order-date">{{ $order->created_at->format('d M Y') }}</span>
                            <span class="order-badge badge-{{ $order->status ?? 'pending' }}">
                                {{ match($order->status ?? 'pending') {
                                    'pending'   => 'Në pritje',
                                    'confirmed' => 'Konfirmuar',
                                    'delivered' => 'Dorëzuar',
                                    'cancelled' => 'Anuluar',
                                    default     => ucfirst($order->status)
                                } }}
                            </span>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="orders-empty">
                    <span class="material-symbols-outlined" style="font-size:36px; display:block; margin-bottom:8px; color:var(--text-muted);">shopping_bag</span>
                    Nuk keni asnjë porosi ende.
                </div>
            @endif
        </div>
    </div>

</div>
@endsection
