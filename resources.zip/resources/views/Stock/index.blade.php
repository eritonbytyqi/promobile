@extends('layouts.app')

@section('title', 'Stoku')
@section('page-title', 'Stoku')

@section('breadcrumb')
    <a href="{{ url('/') }}">Dashboard</a>
    <i class="fa-solid fa-chevron-right" style="font-size:9px;"></i>
    <span>Stoku</span>
@endsection

@push('styles')
<style>

/* ══════════════════════════════
   LIGHT MODE OVERRIDE
══════════════════════════════ */
body, .main, .page-content {
    background: #f5f5f7 !important;
    color: #1d1d1f !important;
}
.sidebar {
    background: #ffffff !important;
    border-right: 1px solid rgba(0,0,0,0.08) !important;
}
.sidebar-nav a { color: #6e6e73 !important; }
.sidebar-nav a:hover { background: #f5f5f7 !important; color: #1d1d1f !important; }
.sidebar-nav a.active { background: rgba(124,111,255,0.1) !important; color: #7c6fff !important; }
.topbar {
    background: rgba(255,255,255,0.85) !important;
    border-bottom: 1px solid rgba(0,0,0,0.08) !important;
}
.topbar-breadcrumb, .topbar-breadcrumb a { color: #8e8e93 !important; }
.topbar-icon-btn {
    background: #ffffff !important;
    border-color: rgba(0,0,0,0.1) !important;
    color: #6e6e73 !important;
}
.topbar-hamburger {
    background: #ffffff !important;
    border-color: rgba(0,0,0,0.1) !important;
    color: #6e6e73 !important;
}
.sidebar-label { color: #aeaeb2 !important; }
.sidebar-footer a { color: #aeaeb2 !important; }
.sidebar-logo-text { color: #1d1d1f !important; }

/* ── STATS ── */
.st-stats {
    display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;
}
.st-stat {
    background:#ffffff;border:1px solid rgba(0,0,0,0.08);
    border-radius:12px;padding:14px 16px;
    display:flex;align-items:center;gap:12px;
}
.st-stat-icon {
    width:36px;height:36px;border-radius:9px;
    display:flex;align-items:center;justify-content:center;
    font-size:14px;flex-shrink:0;
}
.st-stat-num { font-family:'Syne',sans-serif;font-size:22px;font-weight:800;line-height:1;color:#1d1d1f; }
.st-stat-lbl { font-size:11px;color:#8e8e93;margin-top:2px; }

/* ── TOOLBAR ── */
.st-toolbar {
    display:flex;align-items:center;justify-content:space-between;
    gap:12px;margin-bottom:16px;flex-wrap:wrap;
}
.st-filters { display:flex;gap:6px;flex-wrap:wrap; }
.st-filter {
    padding:5px 14px;border-radius:20px;border:1px solid rgba(0,0,0,0.1);
    background:#ffffff;color:#6e6e73;font-size:12px;
    font-weight:500;cursor:pointer;text-decoration:none;transition:all 0.15s;
    display:inline-flex;align-items:center;gap:5px;
}
.st-filter:hover { border-color:#7c6fff;color:#7c6fff; }
.st-filter.active { background:#7c6fff;border-color:#7c6fff;color:white; }
.st-filter.warn.active { background:#ff9500;border-color:#ff9500;color:white; }
.st-filter.danger.active { background:#ff3b30;border-color:#ff3b30;color:white; }

.st-search { display:flex;gap:6px; }
.st-search input {
    padding:6px 12px;border-radius:8px;border:1px solid rgba(0,0,0,0.1);
    background:#ffffff;color:#1d1d1f;font-size:13px;
    outline:none;width:180px;transition:border-color 0.2s;
}
.st-search input:focus { border-color:#7c6fff; }
.st-search .btn { background:#7c6fff;color:white;border:none; }

/* ── ACCORDION CARDS ── */
.st-cards { display:flex;flex-direction:column;gap:8px; }

.st-card {
    background:#ffffff;
    border:1px solid rgba(0,0,0,0.08);
    border-radius:14px;
    overflow:hidden;
    transition:border-color 0.2s;
}
.st-card:hover { border-color:rgba(124,111,255,0.3); }
.st-card.open { border-color:rgba(124,111,255,0.5); }

.st-card-row {
    display:grid;
    grid-template-columns:40px 1fr auto auto auto;
    align-items:center;
    gap:14px;
    padding:14px 18px;
    cursor:pointer;
    user-select:none;
    transition:background 0.15s;
}
.st-card-row:hover { background:#f5f5f7; }
.st-card.open .st-card-row { background:#f5f5f7; }

.st-card-img {
    width:40px;height:40px;border-radius:9px;
    background:#f5f5f7;
    display:flex;align-items:center;justify-content:center;
    color:#d1d1d6;font-size:16px;overflow:hidden;flex-shrink:0;
}
.st-card-img img { width:100%;height:100%;object-fit:cover; }

.st-card-name { font-weight:700;font-size:14px;color:#1d1d1f; }
.st-card-sub  { font-size:11px;color:#8e8e93;margin-top:2px; }

.st-card-total {
    font-family:'Syne',sans-serif;
    font-size:20px;font-weight:800;
    white-space:nowrap;
}

.st-mini-badges { display:flex;gap:5px;flex-wrap:wrap; }
.st-mini-badge {
    padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600;
}
.st-mini-badge.ok  { background:rgba(52,199,89,0.12);color:#1a7a1a; }
.st-mini-badge.low { background:rgba(255,149,0,0.12);color:#a05a00; }
.st-mini-badge.out { background:rgba(255,59,48,0.12);color:#c0392b; }

.st-chevron {
    color:#8e8e93;font-size:12px;
    transition:transform 0.25s;flex-shrink:0;
}
.st-card.open .st-chevron { transform:rotate(180deg); }

.st-dropdown {
    display:none;
    border-top:1px solid rgba(0,0,0,0.06);
}
.st-card.open .st-dropdown { display:block; }

/* ── DESKTOP: header kolonave ── */
.st-drop-head {
    display:grid;
    grid-template-columns:18px 1fr 90px 110px 150px 70px;
    gap:12px;
    padding:8px 18px;
    background:#f9f9f9;
    border-bottom:1px solid rgba(0,0,0,0.06);
}
.st-drop-head span {
    font-size:10px;font-weight:700;letter-spacing:1px;
    text-transform:uppercase;color:#aeaeb2;
}

/* ── DESKTOP: rreshti variantit ── */
.st-var-row {
    display:grid;
    grid-template-columns:18px 1fr 90px 110px 150px 70px;
    gap:12px;
    align-items:center;
    padding:10px 18px;
    border-bottom:1px solid rgba(0,0,0,0.05);
    transition:background 0.15s;
}
.st-var-row:last-child { border-bottom:none; }
.st-var-row:hover { background:#fafafa; }

.st-simple-row {
    display:grid;
    grid-template-columns:1fr 90px 110px 150px 70px;
    gap:12px;
    align-items:center;
    padding:10px 18px;
    border-top:1px solid rgba(0,0,0,0.05);
}

.st-dot {
    width:14px;height:14px;border-radius:50%;
    border:1.5px solid rgba(0,0,0,0.1);flex-shrink:0;
}

.st-badge {
    padding:2px 9px;border-radius:20px;
    font-size:11px;font-weight:600;white-space:nowrap;display:inline-block;
}
.st-badge.ok  { background:rgba(52,199,89,0.12);color:#1a7a1a; }
.st-badge.low { background:rgba(255,149,0,0.12);color:#a05a00; }
.st-badge.out { background:rgba(255,59,48,0.12);color:#c0392b; }

.st-ctrl {
    display:flex;align-items:center;
    background:#f5f5f7;border:1px solid rgba(0,0,0,0.1);
    border-radius:8px;overflow:hidden;
}
.st-ctrl-btn {
    width:26px;height:30px;background:none;border:none;
    color:#8e8e93;cursor:pointer;font-size:10px;
    display:flex;align-items:center;justify-content:center;transition:all 0.15s;
}
.st-ctrl-btn:hover { background:rgba(0,0,0,0.06);color:#1d1d1f; }
.st-ctrl-inp {
    width:44px;height:30px;text-align:center;border:none;
    background:none;color:#1d1d1f;
    font-family:'Syne',sans-serif;font-size:14px;font-weight:700;outline:none;
}
.st-save {
    padding:5px 12px;border-radius:7px;background:#7c6fff;
    color:white;border:none;font-size:11px;font-weight:600;
    cursor:pointer;transition:all 0.15s;white-space:nowrap;
}
.st-save:hover { opacity:0.85; }
.st-save.saved { background:#34c759; }

/* Historia butoni */
a[href*="history"] {
    color:#8e8e93 !important;
    border-color:rgba(0,0,0,0.1) !important;
    background:#f5f5f7 !important;
}

/* ══════════════════════════════
   MOBILE
══════════════════════════════ */
@media (max-width: 768px) {
    .st-stats { grid-template-columns:repeat(2,1fr); gap:8px; }
    .st-stat  { padding:12px; }
    .st-stat-num { font-size:18px; }

    /* Toolbar stack */
    .st-toolbar { flex-direction:column; align-items:stretch; gap:10px; }
    .st-filters { justify-content:flex-start; }
    .st-filter  { font-size:11px; padding:5px 10px; }
    .st-search  { width:100%; }
    .st-search input { flex:1; width:100%; }

    /* Card header — stack në mobile */
    .st-card-row {
        grid-template-columns:36px 1fr auto;
        grid-template-rows:auto auto;
        gap:8px;
        padding:12px 14px;
    }

    /* Foto — rreshti 1, kolona 1 */
    .st-card-img { width:36px;height:36px; }

    /* Emri — rreshti 1, kolona 2 */
    .st-card-name { font-size:13px; }
    .st-card-sub  { font-size:10px; }

    /* Chevron — rreshti 1, kolona 3 */
    .st-chevron { grid-column:3; grid-row:1; }

    /* Total stoku — fshihet sepse shihet brenda */
    .st-card-total { display:none; }

    /* Mini badges — rreshti 2, span të gjitha kolonat */
    .st-mini-badges { grid-column:1/-1; }

    /* Historia — fshihet nga header, do ta tregojmë brenda */
    a[href*="history"] { display:none !important; }

    /* DROPDOWN MOBILE — stack si karta */
    .st-drop-head { display:none; }

    .st-var-row {
        display:flex;
        flex-direction:column;
        align-items:stretch;
        gap:10px;
        padding:14px;
        border-bottom:1px solid rgba(0,0,0,0.06);
    }

    /* Emri variantit + badge në një rresht */
    .st-var-row > div:nth-child(2) {
        display:flex;align-items:center;
        justify-content:space-between;
        flex-wrap:wrap;gap:6px;
    }

    /* Çmimi fshihet — shihet te header */
    .st-var-row > div:nth-child(3) { display:none; }

    /* Controls + Ruaj në një rresht */
    .st-var-row .st-ctrl { flex:1; }
    .st-var-row {
        display:grid;
        grid-template-columns:auto 1fr auto auto;
        grid-template-rows:auto auto;
        gap:8px 10px;
        padding:12px 14px;
    }

    /* Dot — col 1 row 1 */
    .st-var-row > div:nth-child(1) { grid-column:1; grid-row:1; align-self:center; }
    /* Emri — col 2-3 row 1 */
    .st-var-row > div:nth-child(2) { grid-column:2/4; grid-row:1; }
    /* Çmimi — fshij */
    .st-var-row > div:nth-child(3) { display:none; }
    /* Badge — col 4 row 1 */
    .st-var-row .st-badge { grid-column:4; grid-row:1; align-self:center; }
    /* Controls — col 1-3 row 2 */
    .st-var-row .st-ctrl { grid-column:1/4; grid-row:2; }
    /* Ruaj — col 4 row 2 */
    .st-var-row .st-save { grid-column:4; grid-row:2; }

    /* Simple row (pa variante) */
    .st-simple-row {
        display:grid;
        grid-template-columns:1fr auto auto;
        grid-template-rows:auto auto;
        gap:8px 10px;
        padding:12px 14px;
    }
    .st-simple-row > div:nth-child(1) { grid-column:1/-1; color:#8e8e93;font-size:12px; }
    .st-simple-row > div:nth-child(2) { display:none; }
    .st-simple-row .st-badge { grid-column:3; grid-row:2; align-self:center; }
    .st-simple-row .st-ctrl  { grid-column:1/3; grid-row:2; }
    .st-simple-row .st-save  { grid-column:3; grid-row:2; }

    /* Controls madhësi më e madhe */
    .st-ctrl { height:36px; }
    .st-ctrl-btn { width:32px;height:36px; }
    .st-ctrl-inp { width:50px;height:36px;font-size:16px; }
    .st-save { padding:0 12px;height:36px;font-size:12px; }
}

@media (max-width: 480px) {
    .st-stats { grid-template-columns:repeat(2,1fr); gap:6px; }
    .st-stat-num { font-size:16px; }
    .st-stat-lbl { font-size:10px; }
    .st-stat-icon { width:30px;height:30px;font-size:12px; }
    .st-card-row { padding:10px 12px; }
    .st-filter { font-size:10px; padding:4px 8px; }
}
</style>
@endpush

@section('content')

{{-- ── STATS ── --}}
<div class="st-stats">
    <div class="st-stat">
        <div class="st-stat-icon" style="background:rgba(124,111,255,0.1);color:var(--accent);">
            <i class="fa-solid fa-box"></i>
        </div>
        <div>
            <div class="st-stat-num">{{ $stats['total_products'] }}</div>
            <div class="st-stat-lbl">Produkte</div>
        </div>
    </div>
    <div class="st-stat">
        <div class="st-stat-icon" style="background:rgba(0,229,160,0.1);color:var(--accent3);">
            <i class="fa-solid fa-swatchbook"></i>
        </div>
        <div>
            <div class="st-stat-num">{{ $stats['total_variants'] }}</div>
            <div class="st-stat-lbl">Variante</div>
        </div>
    </div>
    <div class="st-stat">
        <div class="st-stat-icon" style="background:rgba(255,149,0,0.1);color:#ff9500;">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <div>
            <div class="st-stat-num" style="color:#ff9500;">{{ $stats['low_stock'] }}</div>
            <div class="st-stat-lbl">Stok i ulët (≤3)</div>
        </div>
    </div>
    <div class="st-stat">
        <div class="st-stat-icon" style="background:rgba(248,113,113,0.1);color:var(--danger);">
            <i class="fa-solid fa-ban"></i>
        </div>
        <div>
            <div class="st-stat-num" style="color:var(--danger);">{{ $stats['out_of_stock'] }}</div>
            <div class="st-stat-lbl">Jashtë stoku</div>
        </div>
    </div>
</div>

{{-- ── TOOLBAR ── --}}
<div class="st-toolbar">
    <div class="st-filters">
        <a href="{{ route('admin.stock.index') }}"
           class="st-filter {{ !$filter ? 'active' : '' }}">
            Të gjitha
        </a>
        <a href="{{ route('admin.stock.index', ['filter'=>'low']) }}"
           class="st-filter warn {{ $filter==='low' ? 'active' : '' }}">
            <i class="fa-solid fa-triangle-exclamation"></i> Stok i ulët
        </a>
        <a href="{{ route('admin.stock.index', ['filter'=>'out']) }}"
           class="st-filter danger {{ $filter==='out' ? 'active' : '' }}">
            <i class="fa-solid fa-ban"></i> Jashtë stoku
        </a>
    </div>
    <form method="GET" action="{{ route('admin.stock.index') }}" class="st-search">
        @if($filter)<input type="hidden" name="filter" value="{{ $filter }}">@endif
        <input type="text" name="search" value="{{ $search }}" placeholder="Kërko produkt...">
        <button type="submit" class="btn btn-primary" style="padding:6px 12px;font-size:13px;">
            <i class="fa-solid fa-magnifying-glass"></i>
        </button>
    </form>
</div>

{{-- ── ACCORDION CARDS ── --}}
<div class="st-cards">

@forelse($products as $product)
@php
    $productImg  = $product->images?->firstWhere('is_primary', true) ?? $product->images?->first();
    $imgSrc      = $productImg ? asset('storage/'.$productImg->image_path) : null;
    $hasVariants = $product->variants->count() > 0;

    // Total stok
    $totalStock = $hasVariants
        ? $product->variants->sum('stock')
        : ($product->stock ?? 0);

    // Badge ngjyra per total
    $totalColor = $totalStock <= 0
        ? 'var(--danger)'
        : ($totalStock <= 3 ? '#ff9500' : 'var(--accent3)');

    // Mini badges për header
    $hasOut = $hasVariants
        ? $product->variants->contains(fn($v) => $v->stock <= 0)
        : ($product->stock ?? 0) <= 0;
    $hasLow = $hasVariants
        ? $product->variants->contains(fn($v) => $v->stock > 0 && $v->stock <= 3)
        : (($product->stock ?? 0) > 0 && ($product->stock ?? 0) <= 3);

    // Auto-hap nëse ka problem stoku
    $autoOpen = $hasOut || $hasLow;
@endphp

<div class="st-card" id="stcard_{{ $product->id }}">

    {{-- ── HEADER (klikueshëm) ── --}}
    <div class="st-card-row" onclick="toggleCard({{ $product->id }})">

        {{-- Foto --}}
        <div class="st-card-img">
            @if($imgSrc)
                <img src="{{ $imgSrc }}" alt="">
            @else
                <i class="fa-solid fa-box"></i>
            @endif
        </div>

        {{-- Emri + meta --}}
        <div>
            <div class="st-card-name">{{ $product->name }}</div>
            <div class="st-card-sub">
                {{ $product->category?->name }}
                @if($product->brand) · {{ $product->brand->name }} @endif
                @if($hasVariants)
                    · {{ $product->variants->count() }} variante
                @endif
            </div>
        </div>

        {{-- Mini badges --}}
        <div class="st-mini-badges">
            @if($hasOut)
                <span class="st-mini-badge out">Jashtë stoku</span>
            @endif
            @if($hasLow)
                <span class="st-mini-badge low">Stok i ulët</span>
            @endif
            @if(!$hasOut && !$hasLow)
                <span class="st-mini-badge ok">Në stok</span>
            @endif
        </div>

        {{-- Total stoku --}}
        <div class="st-card-total" style="color:{{ $totalColor }};">
            {{ $totalStock }}
            <span style="font-size:11px;font-weight:400;color:var(--text-muted);">copë</span>
        </div>

        {{-- Chevron --}}
        <a href="{{ route('admin.stock.history', $product->id) }}"
   style="color:var(--text-muted);font-size:13px;padding:6px 10px;
          border-radius:8px;border:1px solid var(--border);
          text-decoration:none;display:flex;align-items:center;gap:5px;
          background:var(--surface2);transition:all 0.15s;white-space:nowrap;"
   onmouseover="this.style.borderColor='var(--accent)';this.style.color='var(--accent)'"
   onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text-muted)'"
   onclick="event.stopPropagation()">
    <i class="fa-solid fa-clock-rotate-left"></i>
    Historia
</a>

<i class="fa-solid fa-chevron-down st-chevron"></i>
    </div>

    {{-- ── DROPDOWN — variantet ── --}}
    <div class="st-dropdown">

        @if($hasVariants)

        {{-- Header kolonave --}}
        <div class="st-drop-head">
            <span></span>
            <span>Ngjyra / Storage</span>
            <span>Çmimi</span>
            <span>Statusi</span>
            <span>Stoku</span>
            <span></span>
        </div>

        {{-- Rreshtat e varianteve --}}
        @foreach($product->variants->sortBy(['color_name','storage']) as $variant)
        @php
            $badge    = $variant->stock <= 0 ? 'out' : ($variant->stock <= 3 ? 'low' : 'ok');
            $badgeTxt = $variant->stock <= 0 ? 'Jashtë stoku' : ($variant->stock <= 3 ? 'Stok i ulët' : 'Në stok');
            $price    = ($variant->sale_price && $variant->sale_price < $variant->price)
                        ? $variant->sale_price : $variant->price;
        @endphp
        <div class="st-var-row">

            {{-- Ngjyra dot --}}
            @if($variant->color_hex)
                <div class="st-dot" style="background:{{ $variant->color_hex }};"></div>
            @else
                <div></div>
            @endif

            {{-- Emri variantit --}}
            <div style="font-size:13px;font-weight:500;">
                {{ $variant->color_name ?? '' }}
                @if($variant->storage)
                    <span style="color:var(--text-muted);margin-left:3px;font-weight:400;">
                        {{ $variant->storage }}
                    </span>
                @endif
            </div>

            {{-- Çmimi --}}
            <div style="font-weight:600;font-size:13px;">
                {{ number_format($price, 2) }} €
            </div>

            {{-- Statusi --}}
            <span class="st-badge {{ $badge }}">{{ $badgeTxt }}</span>

            {{-- Controls --}}
            <div class="st-ctrl">
                <button class="st-ctrl-btn" onclick="ch('v{{ $variant->id }}',-1)">
                    <i class="fa-solid fa-minus"></i>
                </button>
                <input class="st-ctrl-inp" id="input_v{{ $variant->id }}"
                       type="number" value="{{ $variant->stock }}" min="0">
                <button class="st-ctrl-btn" onclick="ch('v{{ $variant->id }}',1)">
                    <i class="fa-solid fa-plus"></i>
                </button>
            </div>

            {{-- Ruaj --}}
            <button class="st-save" id="btn_v{{ $variant->id }}"
                    onclick="saveVariant({{ $variant->id }})">
                Ruaj
            </button>

        </div>
        @endforeach

        @else

        {{-- Produkt pa variante --}}
        @php
            $st       = $product->stock ?? 0;
            $badge    = $st <= 0 ? 'out' : ($st <= 3 ? 'low' : 'ok');
            $badgeTxt = $st <= 0 ? 'Jashtë stoku' : ($st <= 3 ? 'Stok i ulët' : 'Në stok');
            $price    = ($product->sale_price && $product->sale_price < $product->price)
                        ? $product->sale_price : $product->price;
        @endphp
        <div class="st-simple-row">
            <div style="font-size:13px;color:var(--text-muted);">Pa variante</div>
            <div style="font-weight:600;">{{ number_format($price, 2) }} €</div>
            <span class="st-badge {{ $badge }}">{{ $badgeTxt }}</span>
            <div class="st-ctrl">
                <button class="st-ctrl-btn" onclick="ch('p{{ $product->id }}',-1)">
                    <i class="fa-solid fa-minus"></i>
                </button>
                <input class="st-ctrl-inp" id="input_p{{ $product->id }}"
                       type="number" value="{{ $st }}" min="0">
                <button class="st-ctrl-btn" onclick="ch('p{{ $product->id }}',1)">
                    <i class="fa-solid fa-plus"></i>
                </button>
            </div>
            <button class="st-save" id="btn_p{{ $product->id }}"
                    onclick="saveProduct({{ $product->id }})">
                Ruaj
            </button>
        </div>

        @endif
    </div>{{-- /dropdown --}}

</div>{{-- /card --}}

@empty
<div style="text-align:center;padding:60px;color:var(--text-muted);
            background:var(--surface);border:1px solid var(--border);border-radius:14px;">
    <i class="fa-solid fa-box" style="font-size:32px;opacity:0.3;display:block;margin-bottom:14px;"></i>
    Nuk u gjet asnjë produkt.
</div>
@endforelse

</div>{{-- /cards --}}

@endsection

@push('scripts')
<script>
const CSRF = document.querySelector('meta[name="csrf-token"]').content;

function toggleCard(id) {
    document.getElementById(`stcard_${id}`).classList.toggle('open');
}

function ch(key, d) {
    const inp = document.getElementById(`input_${key}`);
    inp.value = Math.max(0, parseInt(inp.value || 0) + d);
}

async function saveVariant(id) {
    const stock = parseInt(document.getElementById(`input_v${id}`).value);
    await doSave(`/admin/stock/variant/${id}`, { stock }, `btn_v${id}`);
}

async function saveProduct(id) {
    const stock = parseInt(document.getElementById(`input_p${id}`).value);
    await doSave(`/admin/stock/product/${id}`, { stock }, `btn_p${id}`);
}

async function doSave(url, body, btnId) {
    const btn = document.getElementById(btnId);
    const orig = btn.textContent;
    btn.textContent = '...';
    btn.disabled = true;
    try {
        const res  = await fetch(url, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN':  CSRF,
                'Accept':        'application/json',
            },
            body: JSON.stringify(body),
        });
        const data = await res.json();
        if (data.success) {
            btn.textContent = '✓ Ruajtur';
            btn.classList.add('saved');
            setTimeout(() => {
                btn.textContent = orig;
                btn.classList.remove('saved');
                btn.disabled = false;
            }, 2000);
        }
    } catch(e) {
        btn.textContent = 'Gabim';
        btn.disabled = false;
    }
}
</script>
@endpush
