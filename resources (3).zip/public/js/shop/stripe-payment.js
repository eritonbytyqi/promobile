const stripeKey = "{{ config('services.stripe.key') }}";
    console.log('Stripe key:', stripeKey);

    const stripe = Stripe(stripeKey);

    // KRIJO ELEMENTS (KJO TË MUNGONTE)
    const elements = stripe.elements();

    const cardElement = elements.create('card', {
        style: {
            base: {
                fontSize: '15px',
                color: '#1a1c1d',
                fontFamily: 'Inter, sans-serif',
                '::placeholder': { color: '#717785' },
            },
            invalid: { color: '#ba1a1a' },
        }
    });

    cardElement.mount('#card-element');

    cardElement.on('change', function(e) {
        const errorDiv = document.getElementById('card-errors');
        if (e.error) {
            errorDiv.innerHTML =
                '<span class="material-symbols-outlined" style="font-size:14px;">error</span>' + e.error.message;
        } else {
            errorDiv.innerHTML = '';
        }
    });

    async function handlePayment() {
        const btn = document.getElementById('payBtn');
        const spinner = document.getElementById('paySpinner');
        const btnText = document.getElementById('payBtnText');

        btn.disabled = true;
        spinner.style.display = 'block';
        btnText.textContent = 'Duke procesuar...';

        try {
            const intentRes = await fetch('/payment/intent', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ order_id: {{ $order->id }} })
            });

            const { client_secret } = await intentRes.json();

            const { paymentIntent, error } = await stripe.confirmCardPayment(client_secret, {
                payment_method: { card: cardElement }
            });

            if (error) {
                document.getElementById('card-errors').innerHTML =
                    '<span class="material-symbols-outlined" style="font-size:14px;">error</span>' + error.message;
                btn.disabled = false;
                spinner.style.display = 'none';
                btnText.textContent = 'Paguaj {{ number_format($order->total_amount, 2) }} €';
                return;
            }

            const confirmRes = await fetch('/payment/confirm', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({
                    order_id: {{ $order->id }},
                    payment_intent_id: paymentIntent.id
                })
            });

            const result = await confirmRes.json();

            if (result.success) {
                window.location.href = '/orders/success/{{ $order->id }}';
            }

        } catch (err) {
            console.error(err);
            btn.disabled = false;
            spinner.style.display = 'none';
            btnText.textContent = 'Paguaj {{ number_format($order->total_amount, 2) }} €';
        }
    }