<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Offer;

class BannerController extends Controller
{
   public function index()
{
    $products = Product::latest()->get();
    $banners = Banner::latest()->get();
    $offers = Offer::with('product')->orderBy('sort_order')->latest()->get();

    return view('admin.banners', compact('products', 'banners', 'offers'));
}

    public function store(Request $request)
    {
        $request->validate([
            'banner_title'              => 'nullable|string|max:255',
            'banner_subtitle'           => 'nullable|string|max:255',
            'banner_badge'              => 'nullable|string|max:255',
            'banner_bg_color'           => 'nullable|string|max:20',
            'banner_btn_primary_text'   => 'nullable|string|max:255',
            'banner_btn_secondary_text' => 'nullable|string|max:255',
            'banner_sort'               => 'nullable|integer|min:0',
            'banner_image'              => 'nullable|image|mimes:jpeg,png,jpg,webp,avif|max:6144',
            'product_id'                => 'nullable|exists:products,id',
        ]);

        $bannerImage = null;

        if ($request->hasFile('banner_image')) {
            $bannerImage = $request->file('banner_image')->store('banners', 'public');
        }

        $primaryText = $request->banner_btn_primary_text ?: 'Buy Now';
        $secondaryText = $request->banner_btn_secondary_text ?: 'Shiko detajet';

        if ($request->filled('product_id')) {
            $primaryUrl = '/checkout?product_id=' . $request->product_id;
            $secondaryUrl = '/shop/' . $request->product_id;
        } else {
            $primaryUrl = '/checkout';
            $secondaryUrl = '/shop';
        }

        Banner::create([
            'title'              => $request->banner_title,
            'subtitle'           => $request->banner_subtitle,
            'badge_text'         => $request->banner_badge,
            'image'              => $bannerImage,
            'bg_color'           => $request->banner_bg_color ?? '#0a0a1a',
            'btn_primary_text'   => $primaryText,
            'btn_primary_url'    => $primaryUrl,
            'btn_secondary_text' => $secondaryText,
            'btn_secondary_url'  => $secondaryUrl,
            'sort_order'         => $request->banner_sort ?? 0,
            'active'             => 1,
        ]);

        return redirect()
            ->route('admin.banners.create')
            ->with('success', 'Banneri u krijua me sukses!');
    }

    public function destroy($id)
    {
        $banner = Banner::findOrFail($id);

        if ($banner->image) {
            Storage::disk('public')->delete($banner->image);
        }

        $banner->delete();

        return redirect()->back()->with('success', 'Banneri u fshi!');
    }
public function create()
{
    $products = \App\Models\Product::where('is_active', true)
        ->orderBy('name')
        ->get();

    $banners = \App\Models\Banner::orderBy('sort_order')
        ->orderByDesc('created_at')
        ->get();

    $offers = \App\Models\Offer::with('product')
        ->orderBy('sort_order')
        ->orderByDesc('created_at')
        ->get();

    return view('Banners.create', compact('products', 'banners', 'offers'));
}
public function saveOffer(Request $request)
{
    cache()->forever('offer_title',     $request->offer_title);
    cache()->forever('offer_subtitle',  $request->offer_subtitle);
    cache()->forever('offer_link_text', $request->offer_link_text);
    cache()->forever('offer_url',       $request->offer_url ?: '/shop?featured=1');

    return back()->with('success', 'Oferta u ruajt me sukses!');
}

public function storeOffer(Request $request)
{
    $request->validate([
        'offer_title' => ['nullable', 'string', 'max:255'],
        'offer_subtitle' => ['nullable', 'string', 'max:255'],
        'offer_badge' => ['nullable', 'string', 'max:100'],
        'offer_link_text' => ['nullable', 'string', 'max:100'],
        'offer_url' => ['nullable', 'string', 'max:255'],
        'offer_bg_color' => ['nullable', 'string', 'max:20'],
        'offer_text_color' => ['nullable', 'string', 'max:20'],
        'offer_sort' => ['nullable', 'integer'],
        'offer_product_id' => ['nullable', 'exists:products,id'],
        'offer_image' => ['nullable', 'image', 'max:4096'],
        'offer_active' => ['nullable', 'boolean'],
    ]);

    $data = [
        'title' => $request->offer_title,
        'subtitle' => $request->offer_subtitle,
        'badge' => $request->offer_badge,
        'link_text' => $request->offer_link_text ?: 'Shiko ofertën →',
        'url' => $request->offer_url,
        'bg_color' => $request->offer_bg_color ?: '#0071e3',
        'text_color' => $request->offer_text_color ?: '#ffffff',
        'sort_order' => $request->offer_sort ?? 0,
        'product_id' => $request->offer_product_id,
        'is_active' => $request->boolean('offer_active', true),
    ];

    if ($request->hasFile('offer_image')) {
        $data['image'] = $request->file('offer_image')->store('offers', 'public');
    }

    Offer::create($data);

    return back()->with('success', 'Oferta u ruajt me sukses.');
}
public function destroyOffer($id)
{
    $offer = Offer::findOrFail($id);

    if ($offer->image && Storage::disk('public')->exists($offer->image)) {
        Storage::disk('public')->delete($offer->image);
    }

    $offer->delete();

    return back()->with('success', 'Oferta u fshi me sukses.');
}
}