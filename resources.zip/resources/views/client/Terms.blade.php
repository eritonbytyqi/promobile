@extends('client.layout')

@section('title', 'Kushtet e Përdorimit — ProMobile')

@push('styles')
<style>
.legal-wrap {
    max-width: 820px;
    margin: 0 auto;
    padding: 60px 24px 80px;
}
.legal-header {
    margin-bottom: 48px;
}
.legal-header h1 {
    font-size: 36px;
    font-weight: 800;
    color: var(--text);
    letter-spacing: -0.8px;
    margin-bottom: 8px;
}
.legal-header p {
    font-size: 14px;
    color: var(--text-muted);
}
.legal-content p {
    font-size: 14px;
    color: var(--text-soft);
    line-height: 1.8;
    margin-bottom: 12px;
}
.legal-content h2 {
    font-size: 18px;
    font-weight: 700;
    color: var(--text);
    margin-bottom: 14px;
    margin-top: 32px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-solid);
}
.legal-content ul {
    padding-left: 20px;
    margin-bottom: 12px;
}
.legal-content ul li {
    font-size: 14px;
    color: var(--text-soft);
    line-height: 1.8;
    margin-bottom: 6px;
}
.legal-empty {
    text-align: center;
    padding: 80px 0;
    color: var(--text-muted);
    font-size: 14px;
}
.legal-empty span {
    display: block;
    font-size: 48px;
    margin-bottom: 12px;
}
@media (max-width: 580px) {
    .legal-header h1 { font-size: 26px; }
}
</style>
@endpush

@section('content')
<div class="legal-wrap">

    <div class="legal-header">
        <h1>Kushtet e Përdorimit</h1>
        <p>
            @if(setting('terms_updated'))
                Përditësuar: {{ setting('terms_updated') }} &nbsp;·&nbsp; ProMobile
            @else
                ProMobile
            @endif
        </p>
    </div>

    @if(setting('terms_content'))
        <div class="legal-content">
            {!! setting('terms_content') !!}
        </div>
    @else
        <div class="legal-empty">
            <span class="material-symbols-outlined" style="font-size:48px;color:var(--text-muted);">article</span>
            Kushtet e përdorimit nuk janë vendosur ende.<br>
            <a href="/admin/settings" style="color:var(--primary);font-size:13px;margin-top:8px;display:inline-block;">
                Shto nga paneli admin →
            </a>
        </div>
    @endif

</div>
@endsection