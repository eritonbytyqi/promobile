<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Services\StockService;  // ← SHTO
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    // ← SHTO constructor
    public function __construct(protected StockService $stock) {}

    public function index()
{
    $orders = Order::latest()->paginate(20);

    return view('orders.index', compact('orders'));
}
public function show($id)
{
    $order = Order::with('items.product')->findOrFail($id);

    return view('orders.show', compact('order'));
}
    // ... index(), create(), show(), edit() mbeten njëlloj ...
public function create()
{
    return view('client.OrderCreate'); // ← emri i saktë i view-it
}
   public function store(Request $request)
{
    $request->validate([
        'customer_name'    => 'required|string|max:255',
        'customer_phone'   => 'required|string|max:255',
        'customer_email'   => 'nullable|email',
        'shipping_address' => 'required|string|max:255',
        'city'             => 'required|string|max:255',
        'product_id'       => 'required|exists:products,id',
        'quantity'         => 'nullable|integer|min:1',
    ]);

    $quantity  = $request->quantity ?? 1;
    $price     = $request->price;
    $total     = $price * $quantity;

    $order = Order::create([
        'customer_name'    => $request->customer_name,
        'customer_email'   => $request->customer_email,
        'customer_phone'   => $request->customer_phone,
        'shipping_address' => $request->shipping_address,
        'city'             => $request->city,
        'notes'            => $request->notes,
        'total_amount'     => $total,
        'status'           => 'pending',
        'order_number'     => 'ORD-' . strtoupper(uniqid()),
    ]);

    // Shto item
    $order->items()->create([
        'product_id' => $request->product_id,
        'variant_id' => $request->variant_id ?? null,
        'quantity'   => $quantity,
        'unit_price' => $price,
        'subtotal'   => $total,
    ]);

    // Zbrit stokun
    if ($request->variant_id) {
        $this->stock->deductForOrder(
            variantId: $request->variant_id,
            quantity:  $quantity,
            orderId:   $order->id
        );
    } else {
        $this->stock->deductProductForOrder(
            productId: $request->product_id,
            quantity:  $quantity,
            orderId:   $order->id
        );
    }

    // ← RIDREJTO TE SUCCESS
    return redirect()->route('orders.success')
                     ->with('order', $order);
}

public function update(Request $request, $id)
{
    // HIQ validation e vjetër dhe shto këtë
    $request->validate([
        'status' => 'required|string',
    ]);
 
    $order     = Order::with('items.product.variants')->findOrFail($id);
      // Blloko nëse është anuluar
    if (in_array($order->status, ['cancelled', 'payment_failed'])) {
        return redirect()->back()->with('error', 'Porosia e anuluar nuk mund të ndryshohet!');
    }
    $oldStatus = $order->status;
    $newStatus = $request->status;
 
     $order->update(array_filter($request->only([
        'customer_name', 'customer_email', 'customer_phone',
        'shipping_address', 'status', 'notes', 'payment_method'
    ])));
    // Nëse anulohet → refund automatik + email
    if ($newStatus === 'cancelled' && $oldStatus !== 'cancelled') {
        if ($order->payment_intent_id) {
            try {
                \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
                \Stripe\Refund::create([
                    'payment_intent' => $order->payment_intent_id,
                ]);
            } catch (\Exception $e) {
                return redirect()->back()
                    ->with('error', 'Statusi u ndryshua por refund dështoi: ' . $e->getMessage());
            }
        }
 
        // Email anulimi
        try {
            \Mail::to($order->customer_email)
                ->send(new \App\Mail\OrderCancelled($order->load('items.product')));
        } catch (\Exception $e) {
            // Email dështoi por vazhdo
        }
    }
 
    // Nëse konfirmohet → email konfirmimi
  if ($newStatus === 'confirmed' && $oldStatus !== 'confirmed') {
    \Log::info('Duke dërguar email konfirmimi te: ' . $order->customer_email);
    try {
        \Mail::to($order->customer_email)
            ->send(new \App\Mail\OrderConfirmed($order->load('items.product')));
        \Log::info('Email u dërgua me sukses!');
    } catch (\Exception $e) {
        \Log::error('Email dështoi: ' . $e->getMessage());
    }
}$messages = [
    'pending'   => 'Porosia u vendos në pritje!',
    'confirmed' => 'Porosia u konfirmua me sukses! ✓',
    'shipped'   => 'Porosia u shënua si e dërguar!',
    'delivered' => 'Porosia u dorëzua me sukses! ✓',
    'cancelled' => 'Porosia u anulua dhe pagesa u kthye te klienti!',
];

$message = $messages[$newStatus] ?? 'Porosia u përditësua!';
   return redirect()->route('admin.orders.index')
    ->with('success', $message);
}
    public function destroy($id)
    {
        $order = Order::with('items.product.variants')->findOrFail($id);

        // Kthe stokun para fshirjes
        foreach ($order->items as $item) {
            $product = $item->product;
            if (!$product) continue;

            if ($product->variants->count() > 0) {
                $variant = $product->variants->first();
                if ($variant) {
                    $this->stock->returnFromOrder(
                        variantId: $variant->id,
                        quantity:  $item->quantity,
                        orderId:   $order->id
                    );
                }
            } else {
                $this->stock->updateProduct(
                    product:  $product,
                    newStock: ($product->stock ?? 0) + $item->quantity,
                    type:     'return',
                    note:     "Kthim nga fshirje porosi #{$order->id}"
                );
            }
        }

        $order->items()->delete();
        $order->delete();

        return redirect()->route('admin.orders.index')
                         ->with('success', 'Porosia u fshi!');
    }

    public function success()
{
    return view('client.order-success');
}
public function bulkDelete(Request $request)
{
    $ids = $request->input('ids', []);
    
    if (empty($ids)) {
        return redirect()->back()->with('error', 'Nuk u zgjodhën porosi!');
    }
 
    $orders = Order::with('items.product.variants')->whereIn('id', $ids)->get();
 
    foreach ($orders as $order) {
        $order->items()->delete();
        $order->delete();
    }
 
    return redirect()->route('admin.orders.index')
        ->with('success', count($ids) . ' porosi u fshinë me sukses!');
}
}