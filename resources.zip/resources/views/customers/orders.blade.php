@extends('layouts.app')

@section('title', 'Porositë e Klientit')
@section('page-title', 'Porositë')

@section('content')
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Porositë e {{ $customer->name }}</div>
            <div style="font-size:13px;color:#777;margin-top:4px;">
                Email: {{ $customer->email }}
            </div>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nr. Porosisë</th>
                    <th>Totali</th>
                    <th>Statusi</th>
                    <th>Pagesa</th>
                    <th>Data</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $o)
                    <tr>
                        <td>#{{ $o->id }}</td>
                        <td>{{ $o->order_number }}</td>
                        <td>{{ number_format($o->total_amount, 2) }} €</td>
                        <td>
                            <span class="badge badge-success">
                                {{ $o->status }}
                            </span>
                        </td>
                        <td>{{ $o->payment_method }}</td>
                        <td>{{ $o->created_at?->format('d.m.Y H:i') }}</td>
                        <td>
                            <a href="{{ route('admin.orders.show', $o->id) }}"
                               class="btn btn-sm btn-ghost">
                                Shiko
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" style="text-align:center;padding:30px;color:#777;">
                            Ky klient nuk ka porosi ende.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination-wrap">
        {{ $orders->links() }}
    </div>
</div>
@endsection