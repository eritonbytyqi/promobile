<?php
namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\ProductStockLog;
use App\Services\StockService;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function __construct(protected StockService $stock) {}

    // ── Lista e stokut ──
    public function index(Request $request)
    {
        $search = $request->input('search');
        $filter = $request->input('filter');

        $products = Product::with(['category', 'brand', 'images', 'variants'])
            ->when($search, fn($q) => $q->where('name', 'like', "%{$search}%"))
            ->latest()
            ->get();

        $stats = [
            'total_products' => $products->count(),
            'out_of_stock'   => 0,
            'low_stock'      => 0,
            'total_variants' => 0,
        ];

        foreach ($products as $product) {
            if ($product->variants->count() > 0) {
                foreach ($product->variants as $v) {
                    $stats['total_variants']++;
                    if ($v->stock <= 0)      $stats['out_of_stock']++;
                    elseif ($v->stock <= 3)  $stats['low_stock']++;
                }
            } else {
                if (($product->stock ?? 0) <= 0)     $stats['out_of_stock']++;
                elseif (($product->stock ?? 0) <= 3) $stats['low_stock']++;
            }
        }

        if ($filter === 'out') {
            $products = $products->filter(function ($p) {
                return $p->variants->count() > 0
                    ? $p->variants->contains(fn($v) => $v->stock <= 0)
                    : ($p->stock ?? 0) <= 0;
            });
        } elseif ($filter === 'low') {
            $products = $products->filter(function ($p) {
                return $p->variants->count() > 0
                    ? $p->variants->contains(fn($v) => $v->stock > 0 && $v->stock <= 3)
                    : (($p->stock ?? 0) > 0 && ($p->stock ?? 0) <= 3);
            });
        }

        return view('stock.index', compact('products', 'stats', 'search', 'filter'));
    }

    // ── Historia e stokut për një produkt ──
    public function history($productId)
    {
        $product = Product::with(['variants', 'images'])->findOrFail($productId);

        $logs = ProductStockLog::with(['variant', 'creator'])
            ->where('product_id', $productId)
            ->orderByDesc('created_at')
            ->paginate(30);

        return view('stock.history', compact('product', 'logs'));
    }

    // ── Përditëso stokun e variantit (AJAX) ──
    public function updateVariantStock(Request $request, $id)
    {
        $request->validate([
            'stock' => 'required|integer|min:0',
            'note'  => 'nullable|string|max:255',
        ]);

        $variant = ProductVariant::findOrFail($id);
        $type    = $request->stock > $variant->stock ? 'in' : 'out';
        $note    = $request->note ?? '';

        $variant = $this->stock->updateVariant($variant, $request->stock, $type, $note);

        return response()->json([
            'success' => true,
            'stock'   => $variant->stock,
        ]);
    }

    // ── Përditëso stokun e produktit pa variante (AJAX) ──
    public function updateProductStock(Request $request, $id)
    {
        $request->validate([
            'stock' => 'required|integer|min:0',
            'note'  => 'nullable|string|max:255',
        ]);

        $product = Product::findOrFail($id);
        $type    = $request->stock > ($product->stock ?? 0) ? 'in' : 'out';
        $note    = $request->note ?? '';

        $product = $this->stock->updateProduct($product, $request->stock, $type, $note);

        return response()->json([
            'success' => true,
            'stock'   => $product->stock,
        ]);
    }

    // ── Stock i ulët për dashboard ──
    public function lowStock()
    {
        $lowVariants = ProductVariant::with(['product.images'])
            ->where('stock', '>', 0)->where('stock', '<=', 3)
            ->orderBy('stock')->get();

        $outVariants = ProductVariant::with(['product.images'])
            ->where('stock', '<=', 0)->get();

        return response()->json([
            'low' => $lowVariants,
            'out' => $outVariants,
        ]);
    }
}