/* Shop Pages JS — logjike specifike
   resources/js/shop/pages.js
*/

/* === client/home.blade.php === */
document.addEventListener('DOMContentLoaded', () => {
    renderWishlist();
});

/* === client/Products.blade.php === */
function addToCart(id, btn, variantId) {
    variantId = variantId || null;
    var icon = btn.querySelector('i');
    if (icon) icon.className = 'fa-solid fa-spinner fa-spin';

    var payload = { product_id: id, quantity: 1 };
    if (variantId) payload.variant_id = variantId;

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (!data.success) return;
        refreshCartUI(data);
        if (icon) icon.className = 'fa-solid fa-check';
        btn.style.background = '#34c759';
        openCartUIOnly();
        setTimeout(function() {
            if (icon) icon.className = 'fa-solid fa-plus';
            btn.style.background = '';
        }, 1800);
    })
    .catch(function(err) {
        console.error('Cart error:', err);
        if (icon) icon.className = 'fa-solid fa-plus';
    });
}
document.addEventListener('DOMContentLoaded', function() {
    renderWishlist();

    const wish  = getWish();
    const items = Object.values(wish);
    const isFavoritetPage = window.location.search.includes('featured=1');

    if (isFavoritetPage) {
        var mainGrid = document.getElementById('mainProductsGrid');
        if (mainGrid) mainGrid.remove();

        var pagination = document.querySelector('.pagination-wrap');
        if (pagination) pagination.remove();

        var shopHeader = document.querySelector('.shop-header p');
        if (shopHeader) shopHeader.remove();

        var shopWrap = document.querySelector('.shop-wrap');
        if (shopWrap) {
            shopWrap.style.paddingBottom = '0';
            shopWrap.style.marginBottom = '0';
        }

        if (items.length === 0) {
            var section = document.getElementById('wishlistSection');
            if (section) {
                section.style.display = 'block';
                section.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#6e6e73;">'
                    + '<i class="fa-regular fa-heart" style="font-size:48px;display:block;margin-bottom:12px;opacity:0.3;"></i>'
                    + '<h3 style="font-size:18px;font-weight:700;margin-bottom:6px;color:#1a1c1d;">Nuk ke favoritet ende</h3>'
                    + '<p style="font-size:14px;">Kliko zemrën te produktet për t\'i shtuar këtu.</p>'
                    + '</div>';
            }
        }
    } else {
        var empty = document.getElementById('emptyState');
        if (empty && items.length > 0) {
            empty.style.display = 'none';
        }
    }
});

/* === client/product-detail.blade.php === */
const colorGroups = @json($colorGroups);
const PRODUCT_ID = {{ $product->id }};
const BASE_PRICE = {{ (float) $basePrice }};
const BASE_OLD   = {!! $baseOldPrice ? (float)$baseOldPrice : 'null' !!};
const BASE_STOCK = {{ (int)($product->stock ?? 0) }};

let selColorName = null;
let selVariantId = null;

function getGroup(colorName) {
    if (!colorName) return null;
    return colorGroups.find(g => g.color_name === colorName) || null;
}

function getStorage(group, variantId) {
    if (!group || !variantId) return null;
    return group.storages.find(s => s.id == variantId) || null;
}

function selectColor(el, name) {
    if (selColorName === name && el.classList.contains('active')) {
        selColorName = null;
        selVariantId = null;
        el.classList.remove('active');
        renderStorages(null);
        renderColorGallery(null);
        refreshUI();
        return;
    }

    selColorName = name;
    selVariantId = null;

    const orderBtn = document.getElementById('orderBtn');
    orderBtn.classList.remove('success');
    document.getElementById('orderBtnText').textContent = 'Shto në shportë';

    document.querySelectorAll('.pm-color').forEach(c => c.classList.remove('active'));
    el.classList.add('active');

    const lbl = document.getElementById('colorLabel');
    if (lbl) lbl.textContent = name;

    const group = getGroup(name);
    const firstAvail = group?.storages?.find(s => s.stock > 0) || group?.storages?.[0] || null;
    if (firstAvail) selVariantId = firstAvail.id;

    renderStorages(group);
    renderColorGallery(group);

    document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));

    if (group && group.images.length > 0) switchMainImgDirect(group.images[0]);

    refreshUI();
}

function selectStorage(el) {
    const variantId = parseInt(el.dataset.variantId);
    if (!variantId) return;

    selVariantId = variantId;

    const orderBtn = document.getElementById('orderBtn');
    orderBtn.classList.remove('success');
    document.getElementById('orderBtnText').textContent = 'Shto në shportë';

    document.querySelectorAll('.pm-storage').forEach(s => s.classList.remove('active'));
    el.classList.add('active');

    const group = getGroup(selColorName);
    const storage = group?.storages?.find(s => s.id === variantId);
    const lbl = document.getElementById('storageLabel');
    if (lbl && storage) lbl.textContent = storage.storage || '';

    refreshUI();
}

function renderStorages(group) {
    const grid    = document.getElementById('storageGrid');
    const section = document.getElementById('storageSection');
    if (!grid || !section) return;

    const storages = (group?.storages || []).filter(s => s.storage && s.storage.trim() !== '');

    if (!group || !storages.length) {
        section.style.display = 'none';
        grid.innerHTML = '';
        return;
    }

    section.style.display = '';
    grid.innerHTML = '';

    storages.forEach((sv, i) => {
        const totalPrice = sv.sale_price ?? sv.price;
        const extra      = sv.extra_price ?? 0;
        const isOut      = sv.stock <= 0;
        const isActive   = sv.id === selVariantId || (!selVariantId && i === 0);

        const btn = document.createElement('div');
        btn.className = 'pm-storage' + (isActive ? ' active' : '') + (isOut ? ' out' : '');
        btn.dataset.storage   = sv.storage;
        btn.dataset.variantId = sv.id;

        btn.innerHTML = `
            <span class="pm-storage-name">${sv.storage}</span>
            <span class="pm-storage-price">${
                isOut ? 'Jashtë stoku' : (extra > 0 ? '+' + extra.toFixed(2) + ' €' : 'Bazë')
            }</span>
        `;

        if (!isOut) btn.addEventListener('click', () => selectStorage(btn));

        grid.appendChild(btn);
    });
}

function renderColorGallery(group) {
    const section = document.getElementById('colorGallerySection');
    const gallery = document.getElementById('colorGallery');
    if (!section || !gallery) return;

    gallery.innerHTML = '';
    const imgs = group?.images || [];

    if (!group || imgs.length === 0) {
        section.style.display = 'none';
        return;
    }

    section.style.display = '';

    imgs.forEach((src, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pm-thumb' + (i === 0 ? ' active' : '');
        btn.innerHTML = `<img src="${src}" alt="foto ${i + 1}" loading="lazy">`;

        btn.addEventListener('click', () => {
            document.querySelectorAll('#colorGallery .pm-thumb').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            switchMainImgDirect(src);
        });

        gallery.appendChild(btn);
    });
}

function switchImage(btn, src) {
    document.querySelectorAll('#colorGallery .pm-thumb').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('#productThumbs .pm-thumb').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    switchMainImgDirect(src);
    currentIdx = allProductSrcs.indexOf(src);
    if (currentIdx < 0) currentIdx = 0;
}

function switchMainImgDirect(src) {
    const img = document.getElementById('mainImg');
    if (!img) return;
    img.classList.add('switching');
    setTimeout(() => {
        img.src = src;
        img.onload = () => img.classList.remove('switching');
        setTimeout(() => img.classList.remove('switching'), 400);
    }, 150);
}

const allProductSrcs = [
    @foreach($productImages as $img)
        '{{ asset('storage/'.$img->image_path) }}',
    @endforeach
    @foreach($colorGroups as $cg)
        @foreach($cg['images'] as $imgSrc)
            '{{ $imgSrc }}',
        @endforeach
    @endforeach
];
let currentIdx = 0;

function refreshUI() {
    const group   = getGroup(selColorName);
    const storage = getStorage(group, selVariantId);
        const basePrice  = group?.storages?.[0]?.base_price ?? BASE_PRICE;

     const extraPrice = storage?.extra_price ?? 0;
    const finalPrice = storage
        ? (storage.sale_price ?? (basePrice + extraPrice))
        : BASE_PRICE;
    const stock = storage ? storage.stock : BASE_STOCK;

    const priceEl = document.getElementById('priceMain');
    priceEl.style.opacity = '0';
    const hasSelection = storage !== null;
 setTimeout(() => {
    const hasVariants = colorGroups.length > 0;
    if (hasSelection) {
        priceEl.innerHTML = finalPrice.toFixed(2) + ' €';
    } else if (hasVariants) {
        priceEl.innerHTML = '<span style="font-size:16px;font-weight:500;color:#6e6e73;letter-spacing:0;margin-right:4px;">nga</span>' + finalPrice.toFixed(2) + ' €';
    } else {
        priceEl.innerHTML = finalPrice.toFixed(2) + ' €';
    }
    priceEl.style.opacity = '1';
}, 150);

   const oldEl   = document.getElementById('priceOld');
const badgeEl = document.getElementById('priceBadge');
if (BASE_OLD) {
    const pct = Math.round(((BASE_OLD - finalPrice) / BASE_OLD) * 100);
    oldEl.textContent = BASE_OLD.toFixed(2) + ' €';
    oldEl.style.display = '';
    badgeEl.textContent = '-' + pct + '%';
    badgeEl.style.display = '';
} else {
    oldEl.style.display = 'none';
    badgeEl.style.display = 'none';
}

    const dot = document.getElementById('stockDot');
    const txt = document.getElementById('stockText');
    dot.className = 'pm-stock-dot';
    if (stock > 10) {
        dot.classList.add('in');
        txt.textContent = 'Në stok — ' + stock + ' të mbetur';
    } else if (stock > 0) {
        dot.classList.add('low');
        txt.textContent = 'Vetëm ' + stock + ' të mbetur!';
    } else {
        dot.classList.add('out');
        txt.textContent = 'Jashtë stoku';
    }

    const btn    = document.getElementById('orderBtn');
    const btnTxt = document.getElementById('orderBtnText');
    if (stock <= 0) {
        btn.classList.add('disabled');
        btnTxt.textContent = 'Jashtë Stoku';
    } else {
        btn.classList.remove('disabled');
        btnTxt.textContent = 'Shto në shportë';
    }

    const toast    = document.getElementById('variantToast');
    const toastTxt = document.getElementById('variantToastText');
    if (!toast) return;

    if (!group) {
        toast.classList.remove('ok');
        toastTxt.innerHTML = 'Zgjedh ngjyrën për të parë fotot, storage dhe çmimin e variantit';
        return;
    }

    if (storage) {
        toast.classList.add('ok');
        const parts = [];
        if (group?.color_name) parts.push(group.color_name);
        if (storage.storage)   parts.push(storage.storage);
        toastTxt.innerHTML = '✓ ' + parts.join(' · ') + ' — <strong>' + finalPrice.toFixed(2) + ' €</strong>';
    } else {
        toast.classList.remove('ok');
        toastTxt.innerHTML = '✓ ' + (group?.color_name || 'Ngjyra') + ' — zgjidh storage';
    }
}

const lb    = document.getElementById('lightbox');
const lbImg = document.getElementById('lbImg');

document.getElementById('mainImgWrap')?.addEventListener('click', () => {
    const src = document.getElementById('mainImg')?.src;
    if (!src) return;
    lbImg.src = src;
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
    const many = allProductSrcs.length > 1;
    document.getElementById('lbPrev').style.display = many ? 'flex' : 'none';
    document.getElementById('lbNext').style.display = many ? 'flex' : 'none';
});

function closeLightbox() {
    lb.classList.remove('open');
    document.body.style.overflow = '';
}

function lbNav(dir) {
    currentIdx = (currentIdx + dir + allProductSrcs.length) % allProductSrcs.length;
    lbImg.style.opacity = '0';
    setTimeout(() => {
        lbImg.src = allProductSrcs[currentIdx];
        lbImg.style.opacity = '1';
    }, 150);
}

lb?.addEventListener('click', e => { if (e.target === lb) closeLightbox(); });

document.addEventListener('keydown', e => {
    if (!lb?.classList.contains('open')) return;
    if (e.key === 'Escape')     closeLightbox();
    if (e.key === 'ArrowRight') lbNav(1);
    if (e.key === 'ArrowLeft')  lbNav(-1);
});

function addCurrentProductToCart(button) {
    const group   = getGroup(selColorName);
    const storage = getStorage(group, selVariantId);
    const payload = { product_id: PRODUCT_ID, quantity: 1 };
    if (storage) payload.variant_id = storage.id;

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            document.getElementById('cartPopup').classList.add('open');
            document.body.style.overflow = 'hidden';
            button.classList.add('success');
            document.getElementById('orderBtnText').textContent = 'U shtua ✓';

            if (typeof openCart === 'function') openCart();
            if (data.cart_html && document.getElementById('csBody'))
                document.getElementById('csBody').innerHTML = data.cart_html;
            if (typeof data.cart_count !== 'undefined') {
                const badge = document.getElementById('csCountBadge');
                if (badge) {
                    badge.textContent = data.cart_count;
                    badge.style.display = data.cart_count > 0 ? '' : 'none';
                }
            }
            if (typeof data.cart_total !== 'undefined') {
                const total = document.getElementById('csTotal');
                if (total) total.textContent = data.cart_total + ' €';
            }
        }
    })
    .catch(console.error);
}

function closeCartPopup() {
    document.getElementById('cartPopup').classList.remove('open');
    document.body.style.overflow = '';
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('priceMain').style.transition = 'opacity 0.15s';
    refreshUI();
    document.getElementById('cartPopup')?.addEventListener('click', function(e) {
        if (e.target === this) closeCartPopup();
    });

    // Inicializo zemrën
    const btn = document.getElementById('detailWishBtn');
    if (!btn) return;
    const wish = getWish();
    const id   = btn.dataset.id;
    if (wish[id]) {
        btn.querySelector('i').className = 'fa-solid fa-heart';
        btn.style.color = '#ff3b30';
        btn.style.background = 'rgba(255,59,48,0.08)';
        btn.style.borderColor = 'rgba(255,59,48,0.2)';
    }
});
(function() {
    const btn = document.getElementById('detailWishBtn');
    if (!btn) return;
    const wish = getWish();
    const id   = btn.dataset.id;
    if (wish[id]) {
        btn.querySelector('i').className = 'fa-solid fa-heart';
        btn.style.color = '#ff3b30';
        btn.style.background = 'rgba(255,59,48,0.08)';
        btn.style.borderColor = 'rgba(255,59,48,0.2)';
    }
})();

/* === client/partials/hero-carousel.blade.php === */
(function () {
    const slides     = document.querySelectorAll('.hero-slide');
    const dots       = document.querySelectorAll('.hero-dot');
    const progressEl = document.getElementById('heroProgress');
    const prevBtn    = document.getElementById('heroPrev');
    const nextBtn    = document.getElementById('heroNext');

    if (!slides.length) return;

    let current = 0;
    let autoTimer, progTimer;
    const INTERVAL = 5000; // ms ndërmjet slides

    function goTo(n) {
        slides[current].classList.remove('active');
        slides[current].classList.add('exit');

        const exitIndex = current;
        setTimeout(() => slides[exitIndex].classList.remove('exit'), 600);

        current = (n + slides.length) % slides.length;
        slides[current].classList.add('active');

        dots.forEach((d, i) => d.classList.toggle('active', i === current));
        resetProgress();
    }

    function resetProgress() {
        clearTimeout(autoTimer);
        clearTimeout(progTimer);

        if (progressEl) {
            progressEl.style.transition = 'none';
            progressEl.style.width = '0%';
        }

        progTimer = setTimeout(() => {
            if (progressEl) {
                progressEl.style.transition = 'width ' + INTERVAL + 'ms linear';
                progressEl.style.width = '100%';
            }
        }, 60);

        autoTimer = setTimeout(() => goTo(current + 1), INTERVAL + 100);
    }

    // Dot clicks
    dots.forEach((dot, i) => dot.addEventListener('click', () => goTo(i)));

    // Arrow clicks
    if (prevBtn) prevBtn.addEventListener('click', () => goTo(current - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => goTo(current + 1));

    // Swipe support (mobile)
    let touchStartX = 0;
    const carousel = document.getElementById('heroCarousel');
    if (carousel) {
        carousel.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
        carousel.addEventListener('touchend',   e => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
        });
    }

    // Start
    if (slides.length > 1) resetProgress();
})();

/* === client/Order/stripe-payment.blade.php === */
const stripeKey = "{{ config('services.stripe.key') }}";
    console.log('Stripe key:', stripeKey);

    const stripe = Stripe(stripeKey);

    // KRIJO ELEMENTS (KJO TË MUNGONTE)
    const elements = stripe.elements();

    const cardElement = elements.create('card', {
        style: {
            base: {
                fontSize: '15px',
                color: '#1a1c1d',
                fontFamily: 'Inter, sans-serif',
                '::placeholder': { color: '#717785' },
            },
            invalid: { color: '#ba1a1a' },
        }
    });

    cardElement.mount('#card-element');

    cardElement.on('change', function(e) {
        const errorDiv = document.getElementById('card-errors');
        if (e.error) {
            errorDiv.innerHTML =
                '<span class="material-symbols-outlined" style="font-size:14px;">error</span>' + e.error.message;
        } else {
            errorDiv.innerHTML = '';
        }
    });

    async function handlePayment() {
        const btn = document.getElementById('payBtn');
        const spinner = document.getElementById('paySpinner');
        const btnText = document.getElementById('payBtnText');

        btn.disabled = true;
        spinner.style.display = 'block';
        btnText.textContent = 'Duke procesuar...';

        try {
            const intentRes = await fetch('/payment/intent', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ order_id: {{ $order->id }} })
            });

            const { client_secret } = await intentRes.json();

            const { paymentIntent, error } = await stripe.confirmCardPayment(client_secret, {
                payment_method: { card: cardElement }
            });

            if (error) {
                document.getElementById('card-errors').innerHTML =
                    '<span class="material-symbols-outlined" style="font-size:14px;">error</span>' + error.message;
                btn.disabled = false;
                spinner.style.display = 'none';
                btnText.textContent = 'Paguaj {{ number_format($order->total_amount, 2) }} €';
                return;
            }

            const confirmRes = await fetch('/payment/confirm', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({
                    order_id: {{ $order->id }},
                    payment_intent_id: paymentIntent.id
                })
            });

            const result = await confirmRes.json();

            if (result.success) {
                window.location.href = '/orders/success/{{ $order->id }}';
            }

        } catch (err) {
            console.error(err);
            btn.disabled = false;
            spinner.style.display = 'none';
            btnText.textContent = 'Paguaj {{ number_format($order->total_amount, 2) }} €';
        }
    }
