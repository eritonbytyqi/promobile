document.addEventListener('DOMContentLoaded', () => {
    renderWishlist();
});