@extends('client.layout')

@section('title', 'Kontakto — ProMobile')

@push('styles')
<style>
:root{
    --aqua-50: #effcfb;
    --aqua-100:#d8f7f4;
    --aqua-200:#b4efea;
    --aqua-300:#84e3db;
    --aqua-400:#4fd1c8;
    --aqua-500:#22b8b0;
    --aqua-600:#14928d;
    --aqua-700:#0f6f6c;

    --ink: #142325;
    --muted: #6d8184;
    --line: #dcebea;
    --surface: #ffffff;
    --surface-soft: #f8fdfd;
    --shadow: 0 10px 30px rgba(20, 146, 141, 0.08);
    --radius-lg: 20px;
    --radius-md: 16px;
    --radius-sm: 12px;
}

.contact-page {
    max-width: 1180px;
    margin: 0 auto;
    padding: 42px 22px 80px;
}

/* HERO */
.contact-hero {
    background:
        linear-gradient(135deg, rgba(34,184,176,.10), rgba(79,209,200,.05)),
        #ffffff;
    border: 1px solid var(--line);
    border-radius: 28px;
    padding: 42px 38px;
    box-shadow: var(--shadow);
    margin-bottom: 28px;
}

.contact-hero-grid {
    display: grid;
    grid-template-columns: 1.25fr .75fr;
    gap: 28px;
    align-items: center;
}

.contact-kicker {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    border-radius: 999px;
    background: var(--aqua-50);
    color: var(--aqua-700);
    font-size: 12px;
    font-weight: 800;
    letter-spacing: .4px;
    text-transform: uppercase;
    margin-bottom: 16px;
}

.contact-hero h1 {
    margin: 0 0 14px;
    font-size: 40px;
    line-height: 1.08;
    letter-spacing: -1.2px;
    color: var(--ink);
    font-weight: 800;
}

.contact-hero p {
    margin: 0;
    max-width: 650px;
    color: var(--muted);
    font-size: 15px;
    line-height: 1.8;
}

.contact-hero-side {
    display: grid;
    gap: 12px;
}

.hero-mini-card {
    background: linear-gradient(180deg, #ffffff, #f8fdfd);
    border: 1px solid var(--line);
    border-radius: 18px;
    padding: 16px 18px;
}

.hero-mini-label {
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .8px;
    color: var(--aqua-700);
    margin-bottom: 6px;
}

.hero-mini-value {
    color: var(--ink);
    font-size: 14px;
    font-weight: 600;
    line-height: 1.6;
}

/* MAIN GRID */
.contact-main {
    display: grid;
    grid-template-columns: 1.18fr .82fr;
    gap: 24px;
    align-items: start;
}

/* SECTION CARD */
.section-card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 24px;
    box-shadow: var(--shadow);
    overflow: hidden;
}

.section-head {
    padding: 22px 24px 18px;
    border-bottom: 1px solid #edf5f5;
    background: linear-gradient(180deg, #fcffff 0%, #f6fdfc 100%);
}

.section-kicker {
    color: var(--aqua-700);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .9px;
    margin-bottom: 7px;
}

.section-title {
    margin: 0;
    font-size: 24px;
    font-weight: 800;
    color: var(--ink);
    letter-spacing: -.6px;
}

.section-sub {
    margin: 8px 0 0;
    color: var(--muted);
    font-size: 14px;
    line-height: 1.7;
}

.section-body {
    padding: 22px 24px 24px;
}

/* LOCATIONS */
.location-list {
    display: grid;
    gap: 18px;
}

.location-card {
    border: 1px solid var(--line);
    border-radius: 20px;
    overflow: hidden;
    background: linear-gradient(180deg, #ffffff 0%, #fbfefe 100%);
}

.location-top {
    padding: 18px 18px 16px;
    display: flex;
    gap: 14px;
    align-items: flex-start;
}

.location-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    background: var(--aqua-50);
    color: var(--aqua-700);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.location-name {
    font-size: 17px;
    font-weight: 800;
    color: var(--ink);
    margin: 0 0 6px;
}

.location-address {
    color: var(--muted);
    font-size: 14px;
    line-height: 1.7;
    margin: 0;
}

.location-phone {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 10px;
    color: var(--aqua-700);
    font-size: 14px;
    font-weight: 700;
    text-decoration: none;
}

.location-phone:hover {
    opacity: .85;
}

.location-map {
    border-top: 1px solid #edf5f5;
    background: #f7fcfc;
}

.location-map iframe {
    width: 100%;
    height: 220px;
    border: 0;
    display: block;
}

/* CONTACT SIDE */
.contact-side-grid {
    display: grid;
    gap: 18px;
}

.contact-methods {
    display: grid;
    gap: 12px;
}

.contact-method {
    display: flex;
    align-items: flex-start;
    gap: 14px;
    padding: 16px;
    border: 1px solid var(--line);
    border-radius: 18px;
    background: linear-gradient(180deg, #ffffff, #fbfefe);
    text-decoration: none;
    transition: .18s ease;
}

.contact-method:hover {
    border-color: var(--aqua-300);
    transform: translateY(-1px);
}

.contact-method-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    background: var(--aqua-50);
    color: var(--aqua-700);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.contact-method-label {
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .7px;
    color: var(--aqua-700);
    margin-bottom: 4px;
}

.contact-method-value {
    color: var(--ink);
    font-size: 15px;
    font-weight: 700;
    line-height: 1.5;
}

.contact-method-desc {
    margin-top: 4px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.6;
}

/* HOURS */
.hours-box {
    display: grid;
    gap: 10px;
}

.hours-row {
    display: flex;
    justify-content: space-between;
    gap: 18px;
    padding: 13px 14px;
    border-radius: 14px;
    background: var(--surface-soft);
    border: 1px solid #e7f3f2;
}

.hours-day {
    color: var(--ink);
    font-size: 14px;
    font-weight: 700;
}

.hours-time {
    color: var(--muted);
    font-size: 14px;
    font-weight: 600;
    text-align: right;
}

/* SOCIAL */
.social-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.social-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    min-height: 44px;
    padding: 0 16px;
    border-radius: 999px;
    border: 1px solid var(--line);
    background: #fff;
    text-decoration: none;
    color: var(--ink);
    font-size: 13px;
    font-weight: 700;
    transition: .18s ease;
}

.social-pill:hover {
    border-color: var(--aqua-300);
    color: var(--aqua-700);
    background: var(--aqua-50);
}

/* EMPTY STATE */
.empty-note {
    padding: 18px;
    border: 1px dashed #cfe8e6;
    border-radius: 16px;
    background: #fbfefe;
    color: var(--muted);
    font-size: 14px;
    line-height: 1.7;
}

/* SUCCESS */
.alert-success {
    margin-bottom: 18px;
    border: 1px solid #bfe9e4;
    background: #eefcf9;
    color: #0f6f6c;
    padding: 14px 16px;
    border-radius: 16px;
    font-size: 14px;
    font-weight: 700;
    display: flex;
    gap: 10px;
    align-items: center;
}

@media (max-width: 980px) {
    .contact-hero-grid,
    .contact-main {
        grid-template-columns: 1fr;
    }

    .contact-hero h1 {
        font-size: 32px;
    }
}

@media (max-width: 640px) {
    .contact-page {
        padding: 24px 14px 60px;
    }

    .contact-hero {
        padding: 24px 18px;
        border-radius: 22px;
    }

    .section-head,
    .section-body {
        padding-left: 18px;
        padding-right: 18px;
    }

    .contact-hero h1 {
        font-size: 28px;
    }

    .section-title {
        font-size: 21px;
    }

    .location-top,
    .contact-method {
        padding: 14px;
    }

    .hours-row {
        flex-direction: column;
        align-items: flex-start;
    }

    .hours-time {
        text-align: left;
    }
}
</style>
@endpush

@section('content')
@php
    $locations = setting('company_locations');
    $locations = $locations ? json_decode($locations, true) : [];
@endphp

<div class="contact-page">

    <div class="contact-hero">
        <div class="contact-hero-grid">
            <div>
                <div class="contact-kicker">
                    <span class="material-symbols-outlined" style="font-size:16px;">support_agent</span>
                    Kontakt & Mbështetje
                </div>

                <h1>Na kontaktoni lehtë dhe shpejt</h1>
                <p>
                    Këtu i gjeni të gjitha mënyrat për të na kontaktuar: lokacionet, telefonat,
                    email-at, orarin e punës dhe rrjetet sociale. Dizajni është mbajtur i pastër
                    që vizitori ta kuptojë menjëherë ku duhet të klikojë.
                </p>
            </div>

            <div class="contact-hero-side">
                @if(setting('company_phone'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Telefoni Kryesor</div>
                        <div class="hero-mini-value">{{ setting('company_phone') }}</div>
                    </div>
                @endif

                @if(setting('company_email'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Email Kryesor</div>
                        <div class="hero-mini-value">{{ setting('company_email') }}</div>
                    </div>
                @endif

                @if(setting('hours_weekdays'))
                    <div class="hero-mini-card">
                        <div class="hero-mini-label">Orari</div>
                        <div class="hero-mini-value">
                            E Hënë — E Premte: {{ setting('hours_weekdays') }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    @if(session('contact_success'))
        <div class="alert-success">
            <span class="material-symbols-outlined" style="font-size:20px;">check_circle</span>
            Mesazhi u dërgua me sukses.
        </div>
    @endif

    <div class="contact-main">

        {{-- MAJTAS: LOKACIONET --}}
        <div class="section-card">
            <div class="section-head">
                <div class="section-kicker">Lokacionet</div>
                <h2 class="section-title">Ku na gjeni</h2>
                <p class="section-sub">
                    Zgjidhni lokacionin që ju përshtatet. Poshtë secilit lokacion shfaqet edhe harta.
                </p>
            </div>

            <div class="section-body">
                @if(count($locations))
                    <div class="location-list">
                        @foreach($locations as $loc)
                            <div class="location-card">
                                <div class="location-top">
                                    <div class="location-icon">
                                        <span class="material-symbols-outlined">location_on</span>
                                    </div>

                                    <div>
                                        <h3 class="location-name">
                                            {{ $loc['name'] ?? 'Lokacioni' }}
                                        </h3>

                                        <p class="location-address">
                                            {{ $loc['address_full'] ?? '' }}
                                        </p>

                                        @if(!empty($loc['phone']))
                                            <a class="location-phone" href="tel:{{ preg_replace('/\s+/', '', $loc['phone']) }}">
                                                <span class="material-symbols-outlined" style="font-size:18px;">call</span>
                                                {{ $loc['phone'] }}
                                            </a>
                                        @endif
                                    </div>
                                </div>

                                @if(!empty($loc['address_full']))
                                    <div class="location-map">
                                        <iframe
                                            src="https://maps.google.com/maps?q={{ urlencode($loc['address_full']) }}&output=embed"
                                            loading="lazy"
                                            allowfullscreen>
                                        </iframe>
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="empty-note">
                        Ende nuk janë shtuar lokacione. Sapo t’i shtoni nga paneli admin,
                        këtu do të shfaqen automatikisht.
                    </div>
                @endif
            </div>
        </div>

        {{-- DJATHTAS: KONTAKTI --}}
        <div class="contact-side-grid">

            <div class="section-card">
                <div class="section-head">
                    <div class="section-kicker">Kontakt i drejtpërdrejtë</div>
                    <h2 class="section-title">Na kontaktoni</h2>
                    <p class="section-sub">
                        Mënyrat kryesore për porosi, pyetje ose mbështetje.
                    </p>
                </div>

                <div class="section-body">
                    <div class="contact-methods">

                        @if(setting('social_whatsapp'))
                            <a class="contact-method" href="https://wa.me/{{ preg_replace('/\s+/', '', setting('social_whatsapp')) }}" target="_blank">
                                <div class="contact-method-icon">
                                    <i class="fa-brands fa-whatsapp" style="font-size:20px;"></i>
                                </div>
                                <div>
                                    <div class="contact-method-label">WhatsApp</div>
                                    <div class="contact-method-value">{{ setting('social_whatsapp') }}</div>
                                    <div class="contact-method-desc">Na shkruani direkt për përgjigje më të shpejtë.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_phone'))
                            <a class="contact-method" href="tel:{{ preg_replace('/\s+/', '', setting('company_phone')) }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">call</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Telefoni</div>
                                    <div class="contact-method-value">{{ setting('company_phone') }}</div>
                                    <div class="contact-method-desc">Na telefononi për informata të shpejta.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_phone2'))
                            <a class="contact-method" href="tel:{{ preg_replace('/\s+/', '', setting('company_phone2')) }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">phone_in_talk</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Numri Shtesë</div>
                                    <div class="contact-method-value">{{ setting('company_phone2') }}</div>
                                    <div class="contact-method-desc">Alternativë shtesë për kontakt.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_email'))
                            <a class="contact-method" href="mailto:{{ setting('company_email') }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">mail</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Email</div>
                                    <div class="contact-method-value">{{ setting('company_email') }}</div>
                                    <div class="contact-method-desc">Për kërkesa më të detajuara ose bashkëpunime.</div>
                                </div>
                            </a>
                        @endif

                        @if(setting('company_email2'))
                            <a class="contact-method" href="mailto:{{ setting('company_email2') }}">
                                <div class="contact-method-icon">
                                    <span class="material-symbols-outlined">alternate_email</span>
                                </div>
                                <div>
                                    <div class="contact-method-label">Email Shtesë</div>
                                    <div class="contact-method-value">{{ setting('company_email2') }}</div>
                                    <div class="contact-method-desc">Email alternativ për support ose pyetje tjera.</div>
                                </div>
                            </a>
                        @endif

                    </div>
                </div>
            </div>

            @if(setting('hours_weekdays') || setting('hours_saturday') || setting('hours_sunday'))
                <div class="section-card">
                    <div class="section-head">
                        <div class="section-kicker">Orari</div>
                        <h2 class="section-title">Orët e punës</h2>
                    </div>

                    <div class="section-body">
                        <div class="hours-box">
                            @if(setting('hours_weekdays'))
                                <div class="hours-row">
                                    <div class="hours-day">E Hënë — E Premte</div>
                                    <div class="hours-time">{{ setting('hours_weekdays') }}</div>
                                </div>
                            @endif

                            @if(setting('hours_saturday'))
                                <div class="hours-row">
                                    <div class="hours-day">E Shtunë</div>
                                    <div class="hours-time">{{ setting('hours_saturday') }}</div>
                                </div>
                            @endif

                            @if(setting('hours_sunday'))
                                <div class="hours-row">
                                    <div class="hours-day">E Diel</div>
                                    <div class="hours-time">{{ setting('hours_sunday') }}</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

            @if(setting('social_instagram') || setting('social_facebook'))
                <div class="section-card">
                    <div class="section-head">
                        <div class="section-kicker">Rrjetet sociale</div>
                        <h2 class="section-title">Na ndiqni online</h2>
                    </div>

                    <div class="section-body">
                        <div class="social-row">
                            @if(setting('social_instagram'))
                                <a href="{{ setting('social_instagram') }}" target="_blank" class="social-pill">
                                    <i class="fa-brands fa-instagram"></i>
                                    Instagram
                                </a>
                            @endif

                            @if(setting('social_facebook'))
                                <a href="{{ setting('social_facebook') }}" target="_blank" class="social-pill">
                                    <i class="fa-brands fa-facebook-f"></i>
                                    Facebook
                                </a>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

        </div>
    </div>
</div>
@endsection