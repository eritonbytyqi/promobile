@extends('client.layout')

@section('title', 'Porosia u bë — ProMobile')

@push('styles')
<style>
.success-wrap {
    max-width: 560px;
    margin: 0 auto;
    padding: 80px 24px 80px;
    text-align: center;
}
.success-icon {
    width: 80px; height: 80px;
    border-radius: 50%;
    background: rgba(52,199,89,0.12);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 28px;
    font-size: 36px; color: #34c759;
}
.success-icon.pending {
    background: rgba(0,89,181,0.1);
    color: var(--primary);
}
.success-title {
    font-size: clamp(24px, 4vw, 36px);
    font-weight: 800; letter-spacing: -1px;
    color: var(--text); margin-bottom: 12px;
}
.success-sub {
    font-size: 15px; color: var(--text-muted);
    line-height: 1.7; margin-bottom: 32px;
}

/* Order details card */
.success-card {
    background: var(--surface);
    border: 1px solid var(--border-solid);
    border-radius: var(--radius-2xl);
    padding: 1.5rem;
    margin-bottom: 24px;
    text-align: left;
}
.success-card-title {
    font-size: 12px; font-weight: 700;
    color: var(--text-muted); letter-spacing: 1px;
    text-transform: uppercase; margin-bottom: 14px;
}
.success-card-row {
    display: flex; justify-content: space-between;
    align-items: center; padding: 8px 0;
    border-bottom: 1px solid var(--border-solid);
    font-size: 13px;
}
.success-card-row:last-child { border-bottom: none; }
.success-card-row span:first-child { color: var(--text-muted); }
.success-card-row span:last-child { font-weight: 600; color: var(--text); }

/* Bank info */
.bank-info {
    background: var(--primary-fixed);
    border: 1px solid var(--primary-dim);
    border-radius: 16px;
    padding: 1.25rem 1.5rem;
    margin-bottom: 24px;
    text-align: left;
}
.bank-info-title {
    font-size: 13px; font-weight: 700;
    color: var(--primary); margin-bottom: 10px;
    display: flex; align-items: center; gap: 6px;
}
.bank-info-row {
    display: flex; justify-content: space-between;
    font-size: 13px; padding: 5px 0;
    color: var(--primary);
}
.bank-info-row span:last-child { font-weight: 700; }

/* Status badge */
.status-badge {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 16px; border-radius: 999px;
    font-size: 13px; font-weight: 700; margin-bottom: 20px;
}
.status-pending  { background: #faeeda; color: #854f0b; }
.status-awaiting { background: var(--primary-fixed); color: var(--primary); }
.status-confirmed { background: var(--success-bg); color: var(--success); }

.success-btn {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 13px 28px; border-radius: 980px;
    background: var(--text); color: white;
    text-decoration: none; font-size: 14px; font-weight: 700;
    transition: all 0.2s; font-family: 'Inter', sans-serif;
}
.success-btn:hover { opacity: 0.85; transform: translateY(-1px); color: white; }

.success-secondary {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 13px 28px; border-radius: 980px;
    background: var(--surface-low); color: var(--text);
    text-decoration: none; font-size: 14px; font-weight: 700;
    margin-left: 10px; transition: all 0.2s;
    border: 1px solid var(--border-solid);
}
.success-secondary:hover { background: var(--surface-high); color: var(--text); }

@media (max-width: 480px) {
    .success-btn, .success-secondary { width: 100%; justify-content: center; margin: 6px 0; }
}
</style>
@endpush

@section('content')
<div class="success-wrap">

    @if(isset($order) && $order->payment_method === 'bank')
        {{-- Stripe/Bank payment --}}
        <div class="success-icon pending">
            <i class="fa-solid fa-clock"></i>
        </div>
        <h1 class="success-title">Pagesa u krye!</h1>
        <div class="status-badge status-awaiting">
            <i class="fa-solid fa-hourglass-half"></i>
            Në pritje të konfirmimit
        </div>
        <p class="success-sub">
            Pagesa juaj u pranua nga Stripe.<br>
            Porosia do të konfirmohet nga ekipi ynë brenda 24 orëve.<br>
            Do të njoftoheni me email sapo të konfirmohet.
        </p>
    @else
        {{-- Cash on delivery --}}
        <div class="success-icon">
            <i class="fa-solid fa-check"></i>
        </div>
        <h1 class="success-title">Faleminderit!</h1>
        <div class="status-badge status-pending">
            <i class="fa-solid fa-truck"></i>
            Cash në dorëzim
        </div>
        <p class="success-sub">
            Porosia juaj u regjistrua me sukses.<br>
            Do t'ju kontaktojmë së shpejti për konfirmim dhe dorëzim.
        </p>
    @endif

    {{-- Order details --}}
    @isset($order)
    <div class="success-card">
        <div class="success-card-title">Detajet e porosisë</div>
        <div class="success-card-row">
            <span>Numri i porosisë</span>
            <span>#{{ $order->order_number }}</span>
        </div>
        <div class="success-card-row">
            <span>Emri</span>
            <span>{{ $order->customer_name }}</span>
        </div>
        <div class="success-card-row">
            <span>Email</span>
            <span>{{ $order->customer_email }}</span>
        </div>
        <div class="success-card-row">
            <span>Metoda e pagesës</span>
            <span>{{ $order->payment_method === 'bank' ? 'Kartë krediti (Stripe)' : 'Cash në dorëzim' }}</span>
        </div>
        @foreach($order->items as $item)
        <div class="success-card-row">
            <span>{{ $item->product->name ?? 'Produkt' }} × {{ $item->quantity }}</span>
            <span>{{ number_format($item->subtotal, 2) }} €</span>
        </div>
        @endforeach
        <div class="success-card-row" style="font-size:15px;">
            <span><strong>Totali</strong></span>
            <span style="color:var(--primary);font-size:16px;"><strong>{{ number_format($order->total_amount, 2) }} €</strong></span>
        </div>
    </div>
    @endisset

    <div>
        <a href="{{ url('/shop') }}" class="success-btn">
            <i class="fa-solid fa-bag-shopping"></i>
            Vazhdo blerjen
        </a>
        @auth
        <a href="{{ route('profile.index') }}" class="success-secondary">
            <i class="fa-solid fa-receipt"></i>
            Porositë e mia
        </a>
        @endauth
    </div>

</div>
@endsection