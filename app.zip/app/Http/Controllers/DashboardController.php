<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Category;

class DashboardController extends Controller
{
    public function index()
    {
        $ordersCount = Order::count();
        $revenue = Order::sum('total_amount');
        $productsCount = Product::count();
        $categoriesCount = Category::count();
        $outOfStock = Product::where('stock', 0)->count();
        $latestOrders = Order::latest()->take(5)->get();
        $latestProducts = Product::latest()->take(5)->get();

        return view('dashboard', compact(
            'ordersCount',
            'revenue',
            'productsCount',
            'categoriesCount',
            'outOfStock',
            'latestOrders',
            'latestProducts'
        ));
    }
}